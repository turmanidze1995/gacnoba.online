/// Values come from `--dart-define` (GitHub Actions secrets), so no key is stored in the code.
class Config {
  static const String siteUrl =
      String.fromEnvironment('SITE_URL', defaultValue: 'https://gacnoba.online');
  static const String serverKey = String.fromEnvironment('SERVER_KEY', defaultValue: '');
  static const String oneSignalAppId =
      String.fromEnvironment('ONESIGNAL_APP_ID', defaultValue: '');
  static const String appName = 'Gacnoba';
}
