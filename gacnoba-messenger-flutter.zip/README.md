# Gacnoba Messenger (Flutter)

მესენჯერი საიტისთვის https://gacnoba.online (WoWonder API v2).
ფუნქციები: შესვლა, ჩატების სია, ტექსტი და სურათები, ძიება, push შეტყობინებები (OneSignal), აუდიო და ვიდეო ზარი (Agora).

## 1. საიტის მხარე (admin-cp)
1. **Mobile & API Settings → Manage API Server Keys** → დააკოპირეთ **Server Key (API v2)**.
2. **OneSignal:** შექმენით აპი onesignal.com-ზე (Android, Firebase FCM-ით).
   - App ID და REST API Key ჩაწერეთ admin-cp-ის Push Notifications პარამეტრებში, ველებში **Android Messenger** (App ID / Key), და ჩართეთ push.
3. **Agora:** agora.io-ზე შექმენით პროექტი. App ID და Certificate ჩაწერეთ admin-cp-ში (Agora Video/Audio Chat), ჩართეთ ზარები.

## 2. GitHub
1. შექმენით **Private** repository და ატვირთეთ ამ პროექტის ფაილები.
2. Settings → Secrets and variables → Actions → New repository secret:
   - `SERVER_KEY` = Server Key (API v2)
   - `ONESIGNAL_APP_ID` = OneSignal App ID
3. Actions → **Build APK** → Run workflow.
4. დასრულების შემდეგ გახსენით run → Artifacts → `gacnoba-messenger-apk` (შიგნით app-release.apk).

## 3. შენიშვნები
- `android/` საქაღალდეს workflow თვითონ ქმნის, ამიტომ repository-ში არ არის.
- თუ build ჩავარდა, გახსენით ჩავარდნილი ნაბიჯის ლოგი და გამომიგზავნეთ.
- ზარების ზარის ხმა (ringtone) და ლოკ-სქრინის ზარის ეკრანი ჯერ არ არის. ზარი გამოჩნდება, როცა აპი ღიაა ან როცა push-ზე დააჭერთ.
