import 'package:flutter/material.dart';
import 'api.dart';
import 'app_lock.dart';
import 'config.dart';
import 'i18n.dart';
import 'nav.dart';
import 'prefs.dart';
import 'push.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.loadSession();
  await I18n.load();
  await AppPrefs.load();
  await AppLockService.load();
  await Push.init();
  runApp(LangScope(notifier: I18n.current, child: const GacnobaApp()));
}

const Color _seed = Color(0xFFA52729);

ThemeData _lightTheme() => ThemeData(colorSchemeSeed: _seed, useMaterial3: true);

/// Black "night" theme (pure black background, good for OLED screens).
ThemeData _darkTheme() {
  final base = ThemeData(colorSchemeSeed: _seed, brightness: Brightness.dark, useMaterial3: true);
  final scheme = base.colorScheme.copyWith(
    surface: Colors.black,
    surfaceContainerLowest: Colors.black,
    surfaceContainerLow: const Color(0xFF0D0D0D),
    surfaceContainer: const Color(0xFF111111),
    surfaceContainerHigh: const Color(0xFF181818),
    surfaceContainerHighest: const Color(0xFF262626),
  );
  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.black,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.black,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
    ),
  );
}

class GacnobaApp extends StatelessWidget {
  const GacnobaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final Widget home = Api.accessToken == null ? const LoginScreen() : const HomeScreen();
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: AppPrefs.themeMode,
      builder: (context, mode, _) => MaterialApp(
        navigatorKey: navigatorKey,
        title: Config.appName,
        debugShowCheckedModeBanner: false,
        theme: _lightTheme(),
        darkTheme: _darkTheme(),
        themeMode: mode,
        builder: (context, child) {
          final code = LangScope.codeOf(context);
          return Directionality(
            textDirection: I18n.isRtl(code) ? TextDirection.rtl : TextDirection.ltr,
            child: LockGate(child: child ?? const SizedBox.shrink()),
          );
        },
        home: home,
      ),
    );
  }
}
