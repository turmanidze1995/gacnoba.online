import 'package:flutter/material.dart';
import 'api.dart';
import 'config.dart';
import 'i18n.dart';
import 'nav.dart';
import 'push.dart';
import 'screens/chats_screen.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.loadSession();
  await I18n.load();
  await Push.init();
  runApp(LangScope(notifier: I18n.current, child: const GacnobaApp()));
}

class GacnobaApp extends StatelessWidget {
  const GacnobaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final Widget home = Api.accessToken == null ? const LoginScreen() : const ChatsScreen();
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: Config.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFFA52729), useMaterial3: true),
      builder: (context, child) {
        final code = LangScope.codeOf(context);
        return Directionality(
          textDirection: I18n.isRtl(code) ? TextDirection.rtl : TextDirection.ltr,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: home,
    );
  }
}
