import 'package:flutter/material.dart';
import 'api.dart';
import 'config.dart';
import 'push.dart';
import 'screens/chats_screen.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.loadSession();
  await Push.init();
  runApp(const GacnobaApp());
}

class GacnobaApp extends StatelessWidget {
  const GacnobaApp({super.key});

  @override
  Widget build(BuildContext context) {
    Widget home;
    if (Config.serverKey.isEmpty) {
      home = const _MissingKey();
    } else if (Api.accessToken == null) {
      home = const LoginScreen();
    } else {
      home = const ChatsScreen();
    }
    return MaterialApp(
      title: Config.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFFE53935), useMaterial3: true),
      home: home,
    );
  }
}

class _MissingKey extends StatelessWidget {
  const _MissingKey();
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'SERVER_KEY is not set.\nAdd it as a GitHub secret and rebuild the app.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
