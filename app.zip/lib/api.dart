import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';
import 'crypto.dart';
import 'prefs.dart';

class ApiException implements Exception {
  final String message;
  final bool unauthorized;
  ApiException(this.message, {this.unauthorized = false});
  @override
  String toString() => message;
}

/// Thin client for the WoWonder API v2:
///   POST {site}/api/{endpoint}?access_token=...   body: server_key + fields
class Api {
  static String? accessToken;
  static String? userId;
  static bool isAdmin = false;
  static Map<String, dynamic> me = {};
  static String? _agoraAppId;

  static Future<void> loadSession() async {
    final p = await SharedPreferences.getInstance();
    accessToken = p.getString('access_token');
    userId = p.getString('user_id');
  }

  static Future<void> saveSession(String token, String uid) async {
    accessToken = token;
    userId = uid;
    final p = await SharedPreferences.getInstance();
    await p.setString('access_token', token);
    await p.setString('user_id', uid);
  }

  static Future<void> clearSession() async {
    accessToken = null;
    userId = null;
    isAdmin = false;
    me = {};
    final p = await SharedPreferences.getInstance();
    await p.remove('access_token');
    await p.remove('user_id');
  }

  static Uri _uri(String endpoint) {
    final uri = Uri.parse('${Config.siteUrl}/api/$endpoint');
    if (accessToken == null) return uri;
    return uri.replace(queryParameters: {'access_token': accessToken!});
  }

  static Map<String, dynamic> _decode(http.Response res) {
    dynamic json;
    try {
      json = jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      throw ApiException(
          'Server error (${res.statusCode}). Check the site URL, .htaccess and server key.');
    }
    if (json is! Map) throw ApiException('Unexpected server response');
    final data = Map<String, dynamic>.from(json);
    if (data['api_status'].toString() != '200') {
      var msg = 'Request failed';
      final err = data['errors'];
      if (err is Map && err['error_text'] != null) msg = err['error_text'].toString();
      final low = msg.toLowerCase();
      throw ApiException(msg,
          unauthorized: low.contains('access_token') || low.contains('access token'));
    }
    return data;
  }

  static Future<Map<String, dynamic>> post(String endpoint,
      [Map<String, String> body = const {}]) async {
    final res = await http
        .post(_uri(endpoint), body: {'server_key': Config.serverKey, ...body})
        .timeout(const Duration(seconds: 30));
    return _decode(res);
  }

  static Future<Map<String, dynamic>> upload(
      String endpoint, Map<String, String> fields, String fileField, String path) async {
    final req = http.MultipartRequest('POST', _uri(endpoint));
    req.fields['server_key'] = Config.serverKey;
    req.fields.addAll(fields);
    req.files.add(await http.MultipartFile.fromPath(fileField, path));
    final streamed = await req.send().timeout(const Duration(minutes: 3));
    final res = await http.Response.fromStream(streamed);
    return _decode(res);
  }

  // ---------- auth ----------
  static Future<void> login(String username, String password, String? pushId) async {
    final res = await post('auth', {
      'username': username,
      'password': password,
      'device_type': 'phone',
      if (pushId != null && pushId.isNotEmpty) 'android_m_device_id': pushId,
    });
    final token = res['access_token'];
    if (token == null) {
      throw ApiException(
          'This account requires a confirmation code (two-factor). Disable it on the site first.');
    }
    await saveSession(token.toString(), res['user_id'].toString());
    await rememberPush(pushId);
  }

  static Future<void> rememberPush(String? pushId) async {
    if (pushId == null || pushId.isEmpty) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('registered_push_id', pushId);
  }

  static Future<String?> registeredPush() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('registered_push_id');
  }

  static Future<void> googleLogin(String idToken, String? pushId) async {
    final res = await post('social-login', {
      'provider': 'google',
      'access_token': idToken,
      'device_type': 'phone',
      if (pushId != null && pushId.isNotEmpty) 'android_m_device_id': pushId,
    });
    final token = res['access_token'];
    if (token == null) throw ApiException('Google login failed');
    await saveSession(token.toString(), res['user_id'].toString());
    await rememberPush(pushId);
  }

  static Future<Map<String, dynamic>> register({
    required String username,
    required String email,
    required String password,
    required String confirm,
    String first = '',
    String last = '',
    String? pushId,
  }) {
    return post('create-account', {
      'username': username,
      'email': email,
      'password': password,
      'confirm_password': confirm,
      'first_name': first,
      'last_name': last,
      'device_type': 'phone',
      if (pushId != null && pushId.isNotEmpty) 'android_m_device_id': pushId,
    });
  }

  static Map<String, dynamic>? _cfg;

  /// Site settings. The API sends them AES-encrypted with the site's encrypt key.
  static Future<Map<String, dynamic>> getSiteConfig({bool refresh = false}) async {
    if (_cfg != null && !refresh) return _cfg!;
    final res = await post('get-site-settings');
    final raw = res['config'];
    Map<String, dynamic>? out;
    if (raw is Map) {
      out = Map<String, dynamic>.from(raw);
    } else if (raw is String) {
      final plain = tryDecryptWithKey(raw, Config.siteEncryptKey);
      if (plain != null) {
        try {
          final j = jsonDecode(plain);
          if (j is Map) out = Map<String, dynamic>.from(j);
        } catch (_) {}
      }
    }
    if (out == null) {
      throw ApiException(
          'Could not read the site settings. Check siteEncryptKey (config.php) in the app.');
    }
    _cfg = out;
    return out;
  }

  static Future<String> giphyKey() async {
    if (!Config.giphyApiKey.startsWith('PASTE')) return Config.giphyApiKey;
    try {
      final cfg = await getSiteConfig();
      return (cfg['giphy_api'] ?? '').toString();
    } catch (_) {
      return '';
    }
  }

  static Future<void> logout() async {
    try {
      await post('delete-access-token');
    } catch (_) {}
    await clearSession();
  }

  // ---------- chats ----------
  static Future<Map<String, dynamic>> getChats({String limit = '50'}) =>
      post('get_chats', {
        'data_type': 'users',
        'user_limit': limit,
        'SetOnline': AppPrefs.hideOnline ? '0' : '1',
      });

  static Future<List<dynamic>> getMessages(String recipientId,
      {String? afterId, int limit = 40}) async {
    final res = await post('get_user_messages', {
      'recipient_id': recipientId,
      'limit': '$limit',
      if (afterId != null) 'after_message_id': afterId,
    });
    return (res['messages'] as List?) ?? [];
  }

  static Future<void> sendText(String userId, String text, {String? replyId}) async {
    await post('send-message', {
      'user_id': userId,
      'text': text,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
      if (replyId != null && replyId.isNotEmpty) 'reply_id': replyId,
    });
  }

  static Future<void> sendFile(String userId, String path) async {
    await upload(
        'send-message',
        {
          'user_id': userId,
          'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
        },
        'file',
        path);
  }

  static Future<List<dynamic>> searchUsers(String query) async {
    final res = await post('search', {'search_key': query, 'limit': '30'});
    return (res['users'] as List?) ?? [];
  }

  // ---------- calls (Twilio, same as the website) ----------
  static Future<Map<String, dynamic>> twilioCreate(String recipientId, String callType) =>
      post('twilio', {'type': 'create', 'recipient_id': recipientId, 'call_type': callType});

  static Future<String> twilioCheck(String callId, String callType) async {
    final res = await post('twilio', {'type': 'check', 'call_id': callId, 'call_type': callType});
    return (res['call_status'] ?? '').toString();
  }

  static Future<void> twilioAction(String callId, String callType, String action) async {
    await post('twilio',
        {'type': 'action', 'call_id': callId, 'call_type': callType, 'action': action});
  }

  // ---------- calls (Agora, unused) ----------
  static Future<String?> getAgoraAppId() async {
    if (_agoraAppId != null && _agoraAppId!.isNotEmpty) return _agoraAppId;
    try {
      final cfg = await getSiteConfig();
      final id = cfg['agora_chat_app_id'];
      if (id != null && id.toString().isNotEmpty) _agoraAppId = id.toString();
    } catch (_) {}
    if (_agoraAppId == null || _agoraAppId!.isEmpty) _agoraAppId = Config.agoraAppId;
    return _agoraAppId;
  }

  static Future<Map<String, dynamic>> agoraCreate(String recipientId, String callType) =>
      post('agora', {'type': 'create', 'recipient_id': recipientId, 'call_type': callType});

  static Future<String> agoraCheck(String callId) async {
    final res = await post('agora', {'type': 'check', 'call_id': callId});
    return (res['call_status'] ?? '').toString();
  }

  static Future<void> agoraAction(String callId, String action) async {
    await post('agora', {'type': 'action', 'call_id': callId, 'action': action});
  }

  // ---------- chat extras ----------
  static Future<Map<String, dynamic>> getMessagesRaw(String recipientId,
      {String? beforeId, int limit = 40}) {
    return post('get_user_messages', {
      'recipient_id': recipientId,
      'limit': '$limit',
      if (beforeId != null) 'before_message_id': beforeId,
    });
  }

  /// status: typing | recording | stop
  static Future<void> setTyping(String userId, String status) async {
    await post('set-chat-typing-status', {'user_id': userId, 'status': status});
  }

  static Future<void> deleteMessage(String messageId) async {
    await post('delete_message', {'message_id': messageId});
  }

  static Future<void> deleteConversation(String userId) async {
    await post('delete-conversation', {'user_id': userId});
  }

  static Future<void> blockUser(String userId, bool block) async {
    await post('block-user', {'user_id': userId, 'block_action': block ? 'block' : 'un-block'});
  }

  static Future<void> sendGif(String userId, String gifUrl) async {
    await post('send-message', {
      'user_id': userId,
      'gif': gifUrl,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
    });
  }

  static String _stripQuery(String u) {
    final i = u.indexOf('?');
    return i < 0 ? u : u.substring(0, i);
  }

  /// Giphy GIFs (stickers: false) or Giphy stickers (stickers: true).
  static Future<List<Map<String, String>>> searchGiphy(String query,
      {bool stickers = false}) async {
    final q = query.trim();
    final key = await giphyKey();
    if (key.isEmpty) throw ApiException('Giphy key is missing');
    final kind = stickers ? 'stickers' : 'gifs';
    final uri = Uri.parse('https://api.giphy.com/v1/$kind/${q.isEmpty ? 'trending' : 'search'}')
        .replace(queryParameters: {
      'api_key': key,
      'limit': '30',
      'rating': 'g',
      if (q.isNotEmpty) 'q': q,
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 20));
    final json = jsonDecode(utf8.decode(res.bodyBytes));
    final out = <Map<String, String>>[];
    if (json is Map && json['data'] is List) {
      for (final d in json['data'] as List) {
        if (d is! Map) continue;
        final images = d['images'];
        if (images is! Map) continue;
        final fixed = images['fixed_height'];
        final small = images['fixed_height_small'];
        final send = fixed is Map ? _stripQuery((fixed['url'] ?? '').toString()) : '';
        final preview = small is Map ? _stripQuery((small['url'] ?? '').toString()) : send;
        if (send.contains('.gif')) {
          out.add({
            'send': send,
            'preview': preview.isEmpty ? send : preview,
            'id': (d['id'] ?? '').toString(),
          });
        }
      }
    }
    return out;
  }

  static Future<void> sendSticker(String userId, String url, String stickerId) async {
    await post('send-message', {
      'user_id': userId,
      'image_url': url,
      'sticker_id': stickerId,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
    });
  }

  /// notify: yes|no (mute), pin: yes|no
  static Future<void> muteChat(String chatId,
      {String? notify, String? pin, String? archive, String type = 'user'}) async {
    await post('mute', {
      'chat_id': chatId,
      'type': type,
      if (notify != null) 'notify': notify,
      if (pin != null) 'pin': pin,
      if (archive != null) 'archive': archive,
    });
  }

  static Future<void> forwardMessage(String messageId, String recipientId) async {
    await post('forward_message', {'id': messageId, 'recipient_id': recipientId});
  }

  // ---------- profile ----------
  static Future<Map<String, dynamic>> getUserData(String userId) async {
    final res = await post('get-user-data', {'user_id': userId, 'fetch': 'user_data'});
    final u = res['user_data'];
    return u is Map ? Map<String, dynamic>.from(u) : <String, dynamic>{};
  }

  /// Reads (and caches) whether the logged-in user is a site administrator.
  static Future<void> loadAdmin() async {
    final p = await SharedPreferences.getInstance();
    isAdmin = p.getBool('is_admin') ?? false;
    if (userId == null) return;
    try {
      final u = await getUserData(userId!);
      me = u;
      isAdmin = (u['admin'] ?? '').toString() == '1';
      await p.setBool('is_admin', isAdmin);
    } catch (_) {}
  }

  static Future<void> updateProfile({String? first, String? last, String? about}) async {
    await post('update-user-data', {
      if (first != null) 'first_name': first,
      if (last != null) 'last_name': last,
      if (about != null) 'about': about,
    });
  }

  static Future<void> updateAvatar(String path) async {
    await upload('update-user-data', {}, 'avatar', path);
  }

  static Future<List<Map<String, dynamic>>> getBlockedUsers() async {
    final res = await post('get-blocked-users');
    final l = res['blocked_users'];
    if (l is! List) return [];
    return l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  // ---------- stories ----------
  /// Users that have stories (each with a `stories` list).
  static Future<List<Map<String, dynamic>>> getStoryUsers() async {
    final res = await post('get-user-stories', {'limit': '50'});
    final l = res['stories'];
    if (l is! List) return [];
    return l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<void> createStory(String path, {required bool video, String title = ''}) async {
    await upload(
        'create-story',
        {
          'file_type': video ? 'video' : 'image',
          if (title.isNotEmpty) 'story_title': title,
        },
        'file',
        path);
  }

  static Future<void> deleteStory(String id) async {
    await post('delete-story', {'story_id': id});
  }

  // ---------- group chats ----------
  static Future<List<Map<String, dynamic>>> groupList() async {
    final res = await post('group_chat', {'type': 'get_list', 'limit': '50'});
    final l = res['data'];
    if (l is! List) return [];
    return l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<Map<String, dynamic>> groupMessagesRaw(String id,
      {String? beforeId, int limit = 40}) {
    return post('group_chat', {
      'type': 'fetch_messages',
      'id': id,
      'limit': '$limit',
      if (beforeId != null) 'before_message_id': beforeId,
    });
  }

  static Future<void> groupSendText(String id, String text, {String? replyId}) async {
    await post('group_chat', {
      'type': 'send',
      'id': id,
      'text': text,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
      if (replyId != null && replyId.isNotEmpty) 'reply_id': replyId,
    });
  }

  static Future<void> groupSendFile(String id, String path) async {
    await upload(
        'group_chat',
        {
          'type': 'send',
          'id': id,
          'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
        },
        'file',
        path);
  }

  static Future<void> groupSendSticker(String id, String url, String stickerId) async {
    await post('group_chat', {
      'type': 'send',
      'id': id,
      'image_url': url,
      'sticker_id': stickerId,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
    });
  }

  static Future<void> groupCreate(String name, List<String> userIds) async {
    await post('group_chat', {
      'type': 'create',
      'group_name': name,
      'parts': userIds.join(','),
    });
  }

  static Future<void> groupAddUsers(String id, List<String> userIds) async {
    await post('group_chat', {'type': 'add_user', 'id': id, 'parts': userIds.join(',')});
  }

  static Future<void> groupLeave(String id) async {
    await post('group_chat', {'type': 'leave', 'id': id});
  }

  /// Site notifications (likes, reactions, comments, follows...) and friend requests.
  static Future<Map<String, dynamic>> getNotifications() => post('get-general-data', {
        'fetch': 'notifications,friend_requests',
      });

  /// Privacy fields of the user (WoWonder): showlastseen = 1|0 (online status),
  /// message_privacy = 0 everyone | 1 people I follow (friends) | 2 nobody.
  static Future<void> updatePrivacy(Map<String, String> fields) async {
    await post('update-user-data', fields);
  }

  /// Sends a map location (the site shows it in the chat).
  static Future<void> sendLocation(String userId, double lat, double lng) async {
    await post('send-message', {
      'user_id': userId,
      'lat': lat.toString(),
      'lng': lng.toString(),
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
    });
  }

  static Future<void> changePassword(String current, String next) async {
    await post('update-user-data', {'current_password': current, 'new_password': next});
  }

  static Future<void> markStorySeen(String id) async {
    try {
      await post('get_story_by_id', {'id': id});
    } catch (_) {}
  }

  static Future<void> groupDelete(String id) async {
    await post('group_chat', {'type': 'delete', 'id': id});
  }

  static Future<void> groupRemoveUser(String id, String userId) async {
    await post('group_chat', {'type': 'remove_user', 'id': id, 'parts': userId});
  }

  static List<Map<String, dynamic>> _maps(dynamic l) =>
      l is List ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];

  static Future<List<Map<String, dynamic>>> archivedChats() async {
    final res = await post('get_archived_chats', {'type': 'user'});
    return _maps(res['data']);
  }

  static Future<void> favMessage(String messageId, String chatId, bool fav) async {
    await post('fav_message', {
      'message_id': messageId,
      'chat_id': chatId,
      'type': 'user',
      'fav': fav ? 'yes' : 'no',
    });
  }

  static Future<List<Map<String, dynamic>>> favMessages(String chatId) async {
    final res = await post('get_fav_messages', {'chat_id': chatId});
    return _maps(res['data']);
  }

  // ---------- people (everyone on the site) ----------
  /// Everybody on the site, online people first. Needs gacnoba_people.php in
  /// api/v2/endpoints/ on the site. Throws if the file is missing.
  static Future<Map<String, dynamic>> gacnobaPeople({String q = '', int offset = 0}) =>
      post('gacnoba_people', {
        'limit': '100',
        'offset': '$offset',
        if (q.isNotEmpty) 'q': q,
      });

  // ---------- music (iTunes search, 30 second previews, no key needed) ----------
  static Future<List<Map<String, String>>> searchMusic(String query) async {
    final q = query.trim();
    if (q.isEmpty) return [];
    final uri = Uri.parse('https://itunes.apple.com/search').replace(queryParameters: {
      'term': q,
      'media': 'music',
      'entity': 'song',
      'limit': '25',
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 20));
    final json = jsonDecode(utf8.decode(res.bodyBytes));
    final out = <Map<String, String>>[];
    if (json is Map && json['results'] is List) {
      for (final d in json['results'] as List) {
        if (d is! Map) continue;
        final prev = (d['previewUrl'] ?? '').toString();
        if (prev.isEmpty) continue;
        out.add({
          'title': (d['trackName'] ?? '').toString(),
          'artist': (d['artistName'] ?? '').toString(),
          'art': (d['artworkUrl100'] ?? '').toString(),
          'preview': prev,
        });
      }
    }
    return out;
  }
}
