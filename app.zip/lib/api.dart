import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

class ApiException implements Exception {
  final String message;
  final bool unauthorized;
  ApiException(this.message, {this.unauthorized = false});
  @override
  String toString() => message;
}

/// Thin client for the WoWonder API v2:
///   POST {site}/api/{endpoint}?access_token=...   body: server_key + fields
class Api {
  static String? accessToken;
  static String? userId;
  static String? _agoraAppId;

  static Future<void> loadSession() async {
    final p = await SharedPreferences.getInstance();
    accessToken = p.getString('access_token');
    userId = p.getString('user_id');
  }

  static Future<void> saveSession(String token, String uid) async {
    accessToken = token;
    userId = uid;
    final p = await SharedPreferences.getInstance();
    await p.setString('access_token', token);
    await p.setString('user_id', uid);
  }

  static Future<void> clearSession() async {
    accessToken = null;
    userId = null;
    final p = await SharedPreferences.getInstance();
    await p.remove('access_token');
    await p.remove('user_id');
  }

  static Uri _uri(String endpoint) {
    final uri = Uri.parse('${Config.siteUrl}/api/$endpoint');
    if (accessToken == null) return uri;
    return uri.replace(queryParameters: {'access_token': accessToken!});
  }

  static Map<String, dynamic> _decode(http.Response res) {
    dynamic json;
    try {
      json = jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      throw ApiException(
          'Server error (${res.statusCode}). Check the site URL, .htaccess and server key.');
    }
    if (json is! Map) throw ApiException('Unexpected server response');
    final data = Map<String, dynamic>.from(json);
    if (data['api_status'].toString() != '200') {
      var msg = 'Request failed';
      final err = data['errors'];
      if (err is Map && err['error_text'] != null) msg = err['error_text'].toString();
      final low = msg.toLowerCase();
      throw ApiException(msg,
          unauthorized: low.contains('access_token') || low.contains('access token'));
    }
    return data;
  }

  static Future<Map<String, dynamic>> post(String endpoint,
      [Map<String, String> body = const {}]) async {
    final res = await http
        .post(_uri(endpoint), body: {'server_key': Config.serverKey, ...body})
        .timeout(const Duration(seconds: 30));
    return _decode(res);
  }

  static Future<Map<String, dynamic>> upload(
      String endpoint, Map<String, String> fields, String fileField, String path) async {
    final req = http.MultipartRequest('POST', _uri(endpoint));
    req.fields['server_key'] = Config.serverKey;
    req.fields.addAll(fields);
    req.files.add(await http.MultipartFile.fromPath(fileField, path));
    final streamed = await req.send().timeout(const Duration(minutes: 3));
    final res = await http.Response.fromStream(streamed);
    return _decode(res);
  }

  // ---------- auth ----------
  static Future<void> login(String username, String password, String? pushId) async {
    final res = await post('auth', {
      'username': username,
      'password': password,
      'device_type': 'phone',
      if (pushId != null && pushId.isNotEmpty) 'android_m_device_id': pushId,
    });
    final token = res['access_token'];
    if (token == null) {
      throw ApiException(
          'This account requires a confirmation code (two-factor). Disable it on the site first.');
    }
    await saveSession(token.toString(), res['user_id'].toString());
    await rememberPush(pushId);
  }

  static Future<void> rememberPush(String? pushId) async {
    if (pushId == null || pushId.isEmpty) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('registered_push_id', pushId);
  }

  static Future<String?> registeredPush() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('registered_push_id');
  }

  static Future<void> googleLogin(String idToken, String? pushId) async {
    final res = await post('social-login', {
      'provider': 'google',
      'access_token': idToken,
      'device_type': 'phone',
      if (pushId != null && pushId.isNotEmpty) 'android_m_device_id': pushId,
    });
    final token = res['access_token'];
    if (token == null) throw ApiException('Google login failed');
    await saveSession(token.toString(), res['user_id'].toString());
    await rememberPush(pushId);
  }

  static Future<Map<String, dynamic>> register({
    required String username,
    required String email,
    required String password,
    required String confirm,
    String first = '',
    String last = '',
    String? pushId,
  }) {
    return post('create-account', {
      'username': username,
      'email': email,
      'password': password,
      'confirm_password': confirm,
      'first_name': first,
      'last_name': last,
      'device_type': 'phone',
      if (pushId != null && pushId.isNotEmpty) 'android_m_device_id': pushId,
    });
  }

  static Future<Map<String, dynamic>> getSiteConfig() async {
    final res = await post('get-site-settings');
    final cfg = res['config'];
    return cfg is Map ? Map<String, dynamic>.from(cfg) : <String, dynamic>{};
  }

  static Future<void> logout() async {
    try {
      await post('delete-access-token');
    } catch (_) {}
    await clearSession();
  }

  // ---------- chats ----------
  static Future<Map<String, dynamic>> getChats() =>
      post('get_chats', {'data_type': 'users', 'user_limit': '50', 'SetOnline': '1'});

  static Future<List<dynamic>> getMessages(String recipientId,
      {String? afterId, int limit = 40}) async {
    final res = await post('get_user_messages', {
      'recipient_id': recipientId,
      'limit': '$limit',
      if (afterId != null) 'after_message_id': afterId,
    });
    return (res['messages'] as List?) ?? [];
  }

  static Future<void> sendText(String userId, String text) async {
    await post('send-message', {
      'user_id': userId,
      'text': text,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
    });
  }

  static Future<void> sendFile(String userId, String path) async {
    await upload(
        'send-message',
        {
          'user_id': userId,
          'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
        },
        'file',
        path);
  }

  static Future<List<dynamic>> searchUsers(String query) async {
    final res = await post('search', {'search_key': query, 'limit': '30'});
    return (res['users'] as List?) ?? [];
  }

  // ---------- calls (Agora) ----------
  static Future<String?> getAgoraAppId() async {
    if (_agoraAppId != null && _agoraAppId!.isNotEmpty) return _agoraAppId;
    final res = await post('get-site-settings');
    final cfg = res['config'];
    if (cfg is Map && cfg['agora_chat_app_id'] != null) {
      _agoraAppId = cfg['agora_chat_app_id'].toString();
    }
    return _agoraAppId;
  }

  static Future<Map<String, dynamic>> agoraCreate(String recipientId, String callType) =>
      post('agora', {'type': 'create', 'recipient_id': recipientId, 'call_type': callType});

  static Future<String> agoraCheck(String callId) async {
    final res = await post('agora', {'type': 'check', 'call_id': callId});
    return (res['call_status'] ?? '').toString();
  }

  static Future<void> agoraAction(String callId, String action) async {
    await post('agora', {'type': 'action', 'call_id': callId, 'action': action});
  }

  // ---------- chat extras ----------
  static Future<Map<String, dynamic>> getMessagesRaw(String recipientId,
      {String? beforeId, int limit = 40}) {
    return post('get_user_messages', {
      'recipient_id': recipientId,
      'limit': '$limit',
      if (beforeId != null) 'before_message_id': beforeId,
    });
  }

  /// status: typing | recording | stop
  static Future<void> setTyping(String userId, String status) async {
    await post('set-chat-typing-status', {'user_id': userId, 'status': status});
  }

  static Future<void> deleteMessage(String messageId) async {
    await post('delete_message', {'message_id': messageId});
  }

  static Future<void> deleteConversation(String userId) async {
    await post('delete-conversation', {'user_id': userId});
  }

  static Future<void> blockUser(String userId, bool block) async {
    await post('block-user', {'user_id': userId, 'block_action': block ? 'block' : 'un-block'});
  }

  static Future<void> sendGif(String userId, String gifUrl) async {
    await post('send-message', {
      'user_id': userId,
      'gif': gifUrl,
      'message_hash_id': DateTime.now().microsecondsSinceEpoch.toString(),
    });
  }

  static Future<List<Map<String, String>>> searchGifs(String query) async {
    final q = query.trim();
    final uri = Uri.parse('https://api.giphy.com/v1/gifs/${q.isEmpty ? 'trending' : 'search'}')
        .replace(queryParameters: {
      'api_key': Config.giphyApiKey,
      'limit': '30',
      'rating': 'g',
      if (q.isNotEmpty) 'q': q,
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 20));
    final json = jsonDecode(utf8.decode(res.bodyBytes));
    final out = <Map<String, String>>[];
    if (json is Map && json['data'] is List) {
      for (final d in json['data'] as List) {
        if (d is! Map) continue;
        final images = d['images'];
        if (images is! Map) continue;
        final fixed = images['fixed_height'];
        final small = images['fixed_height_small'];
        final send = fixed is Map ? (fixed['url'] ?? '').toString() : '';
        final preview = small is Map ? (small['url'] ?? '').toString() : send;
        if (send.contains('.gif')) {
          out.add({'send': send, 'preview': preview.isEmpty ? send : preview});
        }
      }
    }
    return out;
  }
}
