import 'dart:async';
import 'package:flutter/material.dart';
import 'api.dart';
import 'call_native.dart';
import 'nav.dart';
import 'notify_watcher.dart';
import 'push.dart';
import 'screens/call_screens.dart';
import 'utils.dart';

class _LifecycleHook with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      CallWatcher.showPending();
      CallWatcher.pollNow();
      Push.openPendingChat();
    }
  }
}

/// Polls the site every 2 seconds for an incoming call and shows the ringing
/// screen on top of whatever screen is open.
class CallWatcher {
  static Timer? _timer;
  static bool _busy = false;
  static bool _incomingOpen = false;
  static final Set<String> _handled = {};
  static final _LifecycleHook _hook = _LifecycleHook();
  static String lastStatus = 'not polled yet';
  static Map<String, dynamic>? _pending;
  static DateTime _pendingAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// A call that came while the app was minimized / the phone locked: it rang
  /// through the full screen notification, the call screen opens when the app does.
  static void showPending() {
    final d = _pending;
    _pending = null;
    if (d == null || _incomingOpen) return;
    CallNative.stopRing();
    if (DateTime.now().difference(_pendingAt).inSeconds > 40) return;
    _show(d);
  }

  static void start() {
    if (_timer != null) return;
    WidgetsBinding.instance.addObserver(_hook);
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => pollNow());
    pollNow();
    NotifyWatcher.start();
    Future.delayed(const Duration(milliseconds: 800), Push.openPendingChat);
  }

  static void stop() {
    _timer?.cancel();
    _timer = null;
    NotifyWatcher.stop();
    WidgetsBinding.instance.removeObserver(_hook);
    _handled.clear();
    _incomingOpen = false;
  }

  static Future<void> pollNow() async {
    if (_busy || Api.accessToken == null) return;
    _busy = true;
    try {
      final res = await Api.getChats(limit: '1');
      lastStatus = 'video_call=${res['video_call']}, audio_call=${res['audio_call']}';
      if (_incomingOpen) return;
      for (final kind in const ['video', 'audio']) {
        if (res['${kind}_call'] != true) continue;
        final d = res['${kind}_call_user'];
        if (d is! Map) continue;
        final data = Map<String, dynamic>.from(d);
        final call = data['data'];
        if (call is! Map) continue;
        final id = str(call['id']);
        final key = '$kind:$id';
        if (id.isEmpty || str(call['access_token']).isEmpty || _handled.contains(key)) continue;
        _handled.add(key);
        data['type'] = kind;
        final st = WidgetsBinding.instance.lifecycleState;
        if (st != null && st != AppLifecycleState.resumed) {
          _pending = data;
          _pendingAt = DateTime.now();
          final who = str(data['name']);
          await CallNative.ring(who.isEmpty ? 'GACNOBA' : who,
              kind == 'video' ? 'შემომავალი ვიდეო ზარი' : 'შემომავალი ზარი');
          return;
        }
        _show(data);
        return;
      }
    } catch (e) {
      lastStatus = 'error: $e';
    } finally {
      _busy = false;
    }
  }

  static Future<void> _show(Map<String, dynamic> data) async {
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    _incomingOpen = true;
    try {
      await nav.push(MaterialPageRoute<void>(
          fullscreenDialog: true, builder: (_) => IncomingCallScreen(data: data)));
    } finally {
      _incomingOpen = false;
    }
  }
}
