import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'call_native.dart';
import 'config.dart';
import 'utils.dart';

class UpdateInfo {
  final int code;
  final String name;
  final String url;
  final String notes;
  UpdateInfo(this.code, this.name, this.url, this.notes);
}

/// In-app updates: looks for a newer version, downloads the APK inside the app
/// (with a progress bar) and opens the Android installer.
class Updater {
  static bool _checkedThisSession = false;

  /// Looks for gacnoba_update.json: first in the latest GitHub release, then on the site.
  static Future<UpdateInfo?> fetch() async {
    final urls = <String>[];
    if (Config.githubRepo.isNotEmpty && !Config.githubRepo.startsWith('PASTE')) {
      urls.add('https://github.com/${Config.githubRepo}/releases/latest/download/gacnoba_update.json');
    }
    urls.add('${Config.siteUrl}/gacnoba_update.json');
    for (final u in urls) {
      try {
        final r = await http.get(Uri.parse(u)).timeout(const Duration(seconds: 12));
        if (r.statusCode != 200) continue;
        final j = jsonDecode(utf8.decode(r.bodyBytes));
        if (j is! Map) continue;
        final code = int.tryParse(str(j['version_code'])) ?? 0;
        final url = str(j['apk_url']);
        if (code <= 0 || url.isEmpty) continue;
        return UpdateInfo(code, str(j['version_name']), url, str(j['notes']));
      } catch (_) {}
    }
    return null;
  }

  static void _snack(BuildContext c, String ka, String en) {
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t2(c, ka, en))));
  }

  static Future<void> check(BuildContext context, {bool manual = false}) async {
    if (!manual) {
      if (_checkedThisSession) return;
      _checkedThisSession = true;
    }
    final current = await CallNative.versionCode();
    final info = await fetch();
    if (!context.mounted) return;
    if (info == null) {
      if (manual) _snack(context, 'განახლების შემოწმება ვერ მოხერხდა', 'Could not check for updates');
      return;
    }
    if (info.code <= current) {
      if (manual) _snack(context, 'უახლესი ვერსია გაქვს', 'You have the latest version');
      return;
    }
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t2(ctx, 'ახალი ვერსია', 'New version')),
        content: Text([
          if (info.name.isNotEmpty) info.name,
          if (info.notes.isNotEmpty) info.notes,
          t2(ctx, 'განახლება აპშივე ჩამოიტვირთება და დაინსტალირდება.',
              'The update is downloaded and installed inside the app.'),
        ].join('\n\n')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false), child: Text(t2(ctx, 'მოგვიანებით', 'Later'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true), child: Text(t2(ctx, 'განახლება', 'Update'))),
        ],
      ),
    );
    if (go == true && context.mounted) await _download(context, info);
  }

  static Future<void> _download(BuildContext context, UpdateInfo info) async {
    final progress = ValueNotifier<double>(0);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: Text(t2(ctx, 'იტვირთება...', 'Downloading...')),
          content: ValueListenableBuilder<double>(
            valueListenable: progress,
            builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, children: [
              LinearProgressIndicator(value: v > 0 ? v : null),
              const SizedBox(height: 10),
              Text(v > 0 ? '${(v * 100).toStringAsFixed(0)}%' : ''),
            ]),
          ),
        ),
      ),
    );
    final path = '${Directory.systemTemp.path}/gacnoba_update.apk';
    String? error;
    final client = http.Client();
    try {
      final resp = await client.send(http.Request('GET', Uri.parse(info.url)));
      if (resp.statusCode != 200) throw Exception('HTTP ${resp.statusCode}');
      final total = resp.contentLength ?? 0;
      var got = 0;
      final sink = File(path).openWrite();
      await for (final chunk in resp.stream) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) progress.value = got / total;
      }
      await sink.close();
    } catch (e) {
      error = '$e';
    } finally {
      client.close();
    }
    if (!context.mounted) return;
    Navigator.of(context, rootNavigator: true).pop();
    if (error != null) {
      _snack(context, 'ჩამოტვირთვა ვერ მოხერხდა: $error', 'Download failed: $error');
      return;
    }
    final res = await CallNative.installApk(path);
    if (!context.mounted) return;
    if (res == 'need_permission') {
      _snack(context, 'ჩართე „ამ აპიდან ინსტალაცია“ და თავიდან დააჭირე განახლებას',
          'Allow installing from this app, then tap update again');
    } else if (res.startsWith('error')) {
      _snack(context, 'ინსტალაცია ვერ დაიწყო: $res', 'Could not start install: $res');
    }
  }
}
