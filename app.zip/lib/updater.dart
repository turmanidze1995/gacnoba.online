import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'call_native.dart';
import 'config.dart';
import 'utils.dart';

class UpdateInfo {
  final int code;
  final String name;
  final String url;
  final String notes;
  final bool force;
  UpdateInfo(this.code, this.name, this.url, this.notes, this.force);
}

/// In-app updates: looks for a newer version, downloads the APK inside the app
/// (with a progress bar) and opens the Android installer.
class Updater {
  static bool _checkedThisSession = false;

  /// Why the last check failed (shown to the user, so it is clear what to fix).
  static String lastError = '';

  static final _digits = RegExp(r'\d+');

  /// Latest GitHub release: the .apk asset is the update, the number in the
  /// tag (for example build-41 or v41) is the version code (= build number).
  static Future<UpdateInfo?> _fromGithub() async {
    final repo = Config.githubRepo;
    if (repo.isEmpty || repo.startsWith('PASTE')) {
      lastError = 'GitHub repo not set in the build';
      return null;
    }
    final r = await http.get(Uri.parse('https://api.github.com/repos/$repo/releases/latest'),
        headers: {'Accept': 'application/vnd.github+json'}).timeout(const Duration(seconds: 15));
    if (r.statusCode == 404) {
      lastError = 'no release found (is the repository private?)';
      return null;
    }
    if (r.statusCode != 200) {
      lastError = 'GitHub HTTP ${r.statusCode}';
      return null;
    }
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    if (j is! Map) return null;
    String apk = '';
    final assets = j['assets'];
    if (assets is List) {
      for (final a in assets) {
        if (a is Map && str(a['name']).toLowerCase().endsWith('.apk')) {
          apk = str(a['browser_download_url']);
          break;
        }
      }
    }
    if (apk.isEmpty) {
      lastError = 'the release has no .apk file';
      return null;
    }
    var code = 0;
    for (final src in [str(j['tag_name']), str(j['name'])]) {
      final m = _digits.allMatches(src).toList();
      if (m.isNotEmpty) {
        code = int.tryParse(m.last.group(0)!) ?? 0;
        if (code > 0) break;
      }
    }
    if (code <= 0) {
      lastError = 'release tag has no build number';
      return null;
    }
    final body = str(j['body']);
    return UpdateInfo(code, str(j['name']).isNotEmpty ? str(j['name']) : str(j['tag_name']), apk,
        body.replaceAll('[force]', '').trim(), body.contains('[force]'));
  }

  /// Looks for the newest version: first in the latest GitHub release, then in
  /// gacnoba_update.json on the site.
  static Future<UpdateInfo?> fetch() async {
    lastError = '';
    try {
      final g = await _fromGithub();
      if (g != null) return g;
    } catch (e) {
      lastError = 'GitHub: $e';
    }
    final urls = <String>['${Config.siteUrl}/gacnoba_update.json'];
    for (final u in urls) {
      try {
        final r = await http.get(Uri.parse(u)).timeout(const Duration(seconds: 12));
        if (r.statusCode != 200) continue;
        final j = jsonDecode(utf8.decode(r.bodyBytes));
        if (j is! Map) continue;
        final code = int.tryParse(str(j['version_code'])) ?? 0;
        final url = str(j['apk_url']);
        if (code <= 0 || url.isEmpty) continue;
        final f = str(j['force']).toLowerCase();
        lastError = '';
        return UpdateInfo(code, str(j['version_name']), url, str(j['notes']),
            f == 'true' || f == '1');
      } catch (_) {}
    }
    return null;
  }

  static void _snack(BuildContext c, String ka, String en) {
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t2(c, ka, en))));
  }

  static Future<void> check(BuildContext context, {bool manual = false}) async {
    if (!manual) {
      if (_checkedThisSession) return;
      _checkedThisSession = true;
    }
    final current = await CallNative.versionCode();
    final info = await fetch();
    if (!context.mounted) return;
    if (info == null) {
      if (manual) {
        final why = lastError.isEmpty ? '' : ' ($lastError)';
        _snack(context, 'განახლების შემოწმება ვერ მოხერხდა$why', 'Could not check for updates$why');
      }
      return;
    }
    if (info.code <= current) {
      if (manual) _snack(context, 'უახლესი ვერსია გაქვს', 'You have the latest version');
      return;
    }
    if (info.force) {
      // forced update: the dialog cannot be closed, the app is usable only after updating
      while (context.mounted) {
        await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => PopScope(
            canPop: false,
            child: AlertDialog(
              title: Text(t2(ctx, 'საჭიროა განახლება', 'Update required')),
              content: Text([
                if (info.name.isNotEmpty) info.name,
                if (info.notes.isNotEmpty) info.notes,
                t2(ctx, 'აპის გასაგრძელებლად განაახლე ახალ ვერსიაზე.',
                    'Please update to the new version to continue.'),
              ].join('\n\n')),
              actions: [
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: Text(t2(ctx, 'განახლება', 'Update'))),
              ],
            ),
          ),
        );
        if (!context.mounted) return;
        await _download(context, info);
      }
      return;
    }
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t2(ctx, 'ახალი ვერსია', 'New version')),
        content: Text([
          if (info.name.isNotEmpty) info.name,
          if (info.notes.isNotEmpty) info.notes,
          t2(ctx, 'განახლება აპშივე ჩამოიტვირთება და დაინსტალირდება.',
              'The update is downloaded and installed inside the app.'),
        ].join('\n\n')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false), child: Text(t2(ctx, 'მოგვიანებით', 'Later'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true), child: Text(t2(ctx, 'განახლება', 'Update'))),
        ],
      ),
    );
    if (go == true && context.mounted) await _download(context, info);
  }

  static Future<void> _download(BuildContext context, UpdateInfo info) async {
    final progress = ValueNotifier<double>(0);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: Text(t2(ctx, 'იტვირთება...', 'Downloading...')),
          content: ValueListenableBuilder<double>(
            valueListenable: progress,
            builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, children: [
              LinearProgressIndicator(value: v > 0 ? v : null),
              const SizedBox(height: 10),
              Text(v > 0 ? '${(v * 100).toStringAsFixed(0)}%' : ''),
            ]),
          ),
        ),
      ),
    );
    final path = '${Directory.systemTemp.path}/gacnoba_update.apk';
    String? error;
    final client = http.Client();
    try {
      final resp = await client.send(http.Request('GET', Uri.parse(info.url)));
      if (resp.statusCode != 200) throw Exception('HTTP ${resp.statusCode}');
      final total = resp.contentLength ?? 0;
      var got = 0;
      final sink = File(path).openWrite();
      await for (final chunk in resp.stream) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) progress.value = got / total;
      }
      await sink.close();
    } catch (e) {
      error = '$e';
    } finally {
      client.close();
    }
    if (!context.mounted) return;
    Navigator.of(context, rootNavigator: true).pop();
    if (error != null) {
      _snack(context, 'ჩამოტვირთვა ვერ მოხერხდა: $error', 'Download failed: $error');
      return;
    }
    final res = await CallNative.installApk(path);
    if (!context.mounted) return;
    if (res == 'need_permission') {
      _snack(context, 'ჩართე „ამ აპიდან ინსტალაცია“ და თავიდან დააჭირე განახლებას',
          'Allow installing from this app, then tap update again');
    } else if (res.startsWith('error')) {
      _snack(context, 'ინსტალაცია ვერ დაიწყო: $res', 'Could not start install: $res');
    }
  }
}
