import 'package:flutter/material.dart';
import '../api.dart';
import '../i18n.dart';
import '../lang_picker.dart';
import '../push.dart';
import '../utils.dart';
import 'home_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _user = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  bool _busy = false;
  bool _needNames = false; // site setting "auto_username"
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadConfig();
  }

  Future<void> _loadConfig() async {
    try {
      final cfg = await Api.getSiteConfig();
      if (!mounted) return;
      setState(() => _needNames = str(cfg['auto_username']) == '1');
    } catch (_) {}
  }

  Future<void> _register() async {
    final missing = _email.text.trim().isEmpty ||
        _pass.text.isEmpty ||
        _pass2.text.isEmpty ||
        (!_needNames && _user.text.trim().isEmpty) ||
        (_needNames && (_first.text.trim().isEmpty || _last.text.trim().isEmpty));
    if (missing) {
      setState(() => _error = context.tr('fill_all'));
      return;
    }
    if (_pass.text != _pass2.text) {
      setState(() => _error = context.tr('pass_mismatch'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final pid = await Push.playerId();
      final res = await Api.register(
        username: _user.text.trim(),
        email: _email.text.trim(),
        password: _pass.text,
        confirm: _pass2.text,
        first: _first.text.trim(),
        last: _last.text.trim(),
        pushId: pid,
      );
      if (!mounted) return;
      if (res['access_token'] != null) {
        await Api.saveSession(res['access_token'].toString(), str(res['user_id']));
        await Api.rememberPush(pid);
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const HomeScreen()), (r) => false);
      } else {
        final msg = str(res['message']).isNotEmpty ? str(res['message']) : 'OK';
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 8)));
        Navigator.of(context).pop();
      }
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Connection error: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _field(TextEditingController c, String label,
      {bool obscure = false, TextInputType? type}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: obscure,
        keyboardType: type,
        autocorrect: false,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('register')),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () => showLanguagePicker(context),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Image.asset('assets/logo.png', width: 240),
              const SizedBox(height: 20),
              if (_needNames) ...[
                _field(_first, context.tr('first_name')),
                _field(_last, context.tr('last_name')),
              ] else
                _field(_user, context.tr('username')),
              _field(_email, context.tr('email'), type: TextInputType.emailAddress),
              _field(_pass, context.tr('password'), obscure: true),
              _field(_pass2, context.tr('confirm_password'), obscure: true),
              if (_error != null) ...[
                Text(_error!, style: const TextStyle(color: Colors.red)),
                const SizedBox(height: 12),
              ],
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton(
                  onPressed: _busy ? null : _register,
                  child: _busy
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(context.tr('register')),
                ),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('${context.tr('have_account')} ${context.tr('login')}'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
