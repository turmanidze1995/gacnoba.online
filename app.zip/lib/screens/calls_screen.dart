import 'package:flutter/material.dart';
import '../api.dart';
import '../call_log.dart';
import '../i18n.dart';
import '../utils.dart';
import 'call_screens.dart';

class CallsScreen extends StatefulWidget {
  const CallsScreen({super.key});
  @override
  State<CallsScreen> createState() => _CallsScreenState();
}

class _CallsScreenState extends State<CallsScreen> {
  List<CallEntry> _items = [];

  @override
  void initState() {
    super.initState();
    CallLog.changes.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    CallLog.changes.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final l = await CallLog.load();
    if (mounted) setState(() => _items = l);
  }

  String _when(int t) {
    final d = DateTime.fromMillisecondsSinceEpoch(t * 1000);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}.${two(d.month)}.${d.year} ${two(d.hour)}:${two(d.minute)}';
  }

  Future<void> _callBack(CallEntry e) async {
    if (e.userId.isEmpty) return;
    final video = e.type == 'video';
    try {
      final res = await Api.agoraCreate(e.userId, video ? 'video' : 'audio');
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => CallScreen(
                channel: str(res['room_name']),
                token: str(res['token']),
                video: video,
                peerName: e.name,
                peerAvatar: e.avatar,
                peerUserId: e.userId,
                callId: str(res['id']),
                outgoing: true,
              )));
    } catch (err) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$err')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('calls')),
        actions: [
          if (_items.isNotEmpty)
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: CallLog.clear),
        ],
      ),
      body: _items.isEmpty
          ? Center(child: Text(context.tr('no_calls')))
          : ListView.separated(
              itemCount: _items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final e = _items[i];
                final missed = e.direction == 'missed';
                final icon = missed
                    ? Icons.call_missed
                    : (e.direction == 'out' ? Icons.call_made : Icons.call_received);
                final label = missed
                    ? context.tr('missed_call')
                    : (e.direction == 'out'
                        ? context.tr('outgoing_call')
                        : context.tr('incoming_call'));
                return ListTile(
                  leading: Avatar(url: e.avatar, name: e.name),
                  title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Row(children: [
                    Icon(icon, size: 16, color: missed ? Colors.red : Colors.green),
                    const SizedBox(width: 4),
                    Flexible(child: Text('$label · ${_when(e.time)}', overflow: TextOverflow.ellipsis)),
                  ]),
                  trailing: IconButton(
                    icon: Icon(e.type == 'video' ? Icons.videocam : Icons.call),
                    onPressed: () => _callBack(e),
                  ),
                );
              },
            ),
    );
  }
}
