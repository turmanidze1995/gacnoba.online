import 'package:flutter/material.dart';
import '../api.dart';
import '../utils.dart';
import 'chat_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _q = TextEditingController();
  List<dynamic> _users = [];
  bool _busy = false;
  String? _error;

  Future<void> _search() async {
    final q = _q.text.trim();
    if (q.isEmpty) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final users = await Api.searchUsers(q);
      setState(() => _users = users);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _q,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Search people', border: InputBorder.none),
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _search(),
        ),
        actions: [IconButton(icon: const Icon(Icons.search), onPressed: _search)],
      ),
      body: _busy
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : ListView.builder(
                  itemCount: _users.length,
                  itemBuilder: (_, i) {
                    final u = Map<String, dynamic>.from(_users[i] as Map);
                    final name = displayName(u);
                    return ListTile(
                      leading: Avatar(url: str(u['avatar']), name: name),
                      title: Text(name),
                      subtitle: Text('@${str(u['username'])}'),
                      onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (_) => ChatScreen(
                              userId: str(u['user_id']),
                              name: name,
                              avatar: str(u['avatar'])))),
                    );
                  },
                ),
    );
  }
}
