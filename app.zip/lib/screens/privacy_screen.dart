import 'package:flutter/material.dart';
import '../api.dart';
import '../prefs.dart';
import '../utils.dart';

/// Online status, who can message me, typing indicator.
class PrivacyScreen extends StatefulWidget {
  const PrivacyScreen({super.key});
  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  String _who = str(Api.me['message_privacy']).isEmpty ? '0' : str(Api.me['message_privacy']);
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Api.loadAdmin().then((_) {
      if (!mounted) return;
      final v = str(Api.me['message_privacy']);
      final shown = str(Api.me['showlastseen']);
      setState(() {
        if (v.isNotEmpty) _who = v;
        if (shown.isNotEmpty) AppPrefs.hideOnline = shown == '0';
      });
    });
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _setOnline(bool show) async {
    setState(() => _busy = true);
    final before = AppPrefs.hideOnline;
    await AppPrefs.setHideOnline(!show);
    try {
      await Api.updatePrivacy({'showlastseen': show ? '1' : '0'});
      _snack(t2(context, 'შენახულია', 'Saved'));
    } on ApiException catch (e) {
      await AppPrefs.setHideOnline(before);
      _snack(e.message);
    } catch (e) {
      await AppPrefs.setHideOnline(before);
      _snack('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _setWho(String v) async {
    final before = _who;
    setState(() {
      _who = v;
      _busy = true;
    });
    try {
      await Api.updatePrivacy({'message_privacy': v});
      Api.me['message_privacy'] = v;
      _snack(t2(context, 'შენახულია', 'Saved'));
    } on ApiException catch (e) {
      if (mounted) setState(() => _who = before);
      _snack(e.message);
    } catch (e) {
      if (mounted) setState(() => _who = before);
      _snack('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget who(String v, IconData icon, String label, String sub) => ListTile(
          leading: Icon(icon),
          title: Text(label),
          subtitle: Text(sub),
          trailing: _who == v ? const Icon(Icons.check_circle) : null,
          onTap: _busy ? null : () => _setWho(v),
        );
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'კონფიდენციალურობა', 'Privacy'))),
      body: ListView(children: [
        SwitchListTile(
          secondary: const Icon(Icons.circle, color: Colors.green, size: 20),
          title: Text(t2(context, 'ონლაინ სტატუსი', 'Online status')),
          subtitle: Text(AppPrefs.hideOnline
              ? t2(context, 'დამალულია: სხვები ვერ ხედავენ, როცა ონლაინ ხართ',
                  'Hidden: others cannot see when you are online')
              : t2(context, 'ჩანს: სხვები ხედავენ, როცა ონლაინ ხართ', 'Visible: others see when you are online')),
          value: !AppPrefs.hideOnline,
          onChanged: _busy ? null : _setOnline,
        ),
        SwitchListTile(
          secondary: const Icon(Icons.more_horiz),
          title: Text(t2(context, 'ბეჭდვის ინდიკატორი', 'Typing indicator')),
          subtitle: Text(t2(context, 'სხვა ხედავს, რომ წერთ', 'Others see when you type')),
          value: AppPrefs.typingIndicator,
          onChanged: (v) async {
            await AppPrefs.setTypingIndicator(v);
            if (mounted) setState(() {});
          },
        ),
        const Divider(),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text(t2(context, 'ვის შეუძლია მომწეროს', 'Who can message me'),
              style: Theme.of(context).textTheme.titleSmall),
        ),
        who('0', Icons.public, t2(context, 'ყველას', 'Everyone'),
            t2(context, 'ნებისმიერ მომხმარებელს', 'Any user')),
        who('1', Icons.people_outline, t2(context, 'მხოლოდ მეგობრებს', 'Friends only'),
            t2(context, 'ვისაც მე ვადევნებ თვალს', 'People I follow')),
        who('2', Icons.lock_outline, t2(context, 'არავის', 'Nobody'),
            t2(context, 'პროფილი დახურულია შეტყობინებებისთვის', 'Messages are closed')),
      ]),
    );
  }
}
