import 'dart:async';
import 'package:flutter/material.dart';
import '../api.dart';
import '../utils.dart';
import 'chat_screen.dart';
import 'stories_screen.dart';

/// "People" tab (like Messenger): story cards on top, then everyone who is
/// online on the site, with a search field for all users.
class PeopleScreen extends StatefulWidget {
  const PeopleScreen({super.key});
  @override
  State<PeopleScreen> createState() => _PeopleScreenState();
}

class _PeopleScreenState extends State<PeopleScreen> {
  List<Map<String, dynamic>> _stories = [];
  List<Map<String, dynamic>> _online = [];
  List<Map<String, dynamic>>? _results;
  final _q = TextEditingController();
  Timer? _timer;
  bool _loading = true;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _q.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _storiesOf(Map<String, dynamic> u) {
    final l = u['stories'];
    if (l is! List) return [];
    return l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> _onlineFromChats() async {
    try {
      final res = await Api.getChats(limit: '100');
      final data = (res['data'] as List?) ?? [];
      return data
          .whereType<Map>()
          .where((c) =>
              str(c['lastseen_status']) == 'on' &&
              (str(c['chat_type']).isEmpty || c['chat_type'] == 'user'))
          .map((c) => Map<String, dynamic>.from(c))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _load() async {
    try {
      final s = await Api.getStoryUsers();
      if (mounted) setState(() => _stories = s);
    } catch (_) {}
    try {
      var l = await Api.getOnlineUsers();
      if (l.isEmpty) l = await _onlineFromChats();
      l = l.where((u) => str(u['user_id']) != Api.userId).toList();
      if (mounted) setState(() => _online = l);
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _search(String q) async {
    final t = q.trim();
    if (t.isEmpty) {
      setState(() => _results = null);
      return;
    }
    setState(() => _searching = true);
    try {
      final l = await Api.searchUsers(t);
      if (mounted) {
        setState(() => _results =
            l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList());
      }
    } catch (_) {
      if (mounted) setState(() => _results = []);
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Widget _card({
    required String bg,
    required String avatar,
    required String name,
    required VoidCallback onTap,
    bool plus = false,
    bool ring = false,
  }) {
    final primary = Theme.of(context).colorScheme.primary;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 112,
        margin: const EdgeInsets.only(right: 8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Stack(fit: StackFit.expand, children: [
            bg.isNotEmpty
                ? Image.network(bg,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade400))
                : Container(color: Colors.grey.shade400),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black54],
                  stops: [0.55, 1],
                ),
              ),
            ),
            if (plus)
              Center(
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: primary,
                  child: const Icon(Icons.add, color: Colors.white),
                ),
              )
            else
              Positioned(
                left: 8,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: ring ? primary : Colors.white, width: 2.5),
                  ),
                  child: Avatar(url: avatar, name: name, radius: 16),
                ),
              ),
            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: Text(name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _openStories(Map<String, dynamic> u, List<Map<String, dynamic>> l) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => StoryViewerScreen(user: u, stories: l)));
    _load();
  }

  Widget _storyCard(Map<String, dynamic> u, List<Map<String, dynamic>> l, {bool you = false}) {
    final m = storyMedia(l.first, str(u['avatar']));
    final bg = (m != null && m['video'] != true) ? str(m['url']) : '';
    final unseen = l.any((s) => str(s['is_viewed']) == '0' || s['is_viewed'] == false);
    return _card(
      bg: bg,
      avatar: str(u['avatar']),
      name: you ? t2(context, 'შენი სთორი', 'Your story') : displayName(u),
      ring: you || unseen,
      onTap: () => _openStories(u, l),
    );
  }

  List<Widget> _storyCards() {
    final mine = _stories.where((u) => str(u['user_id']) == Api.userId).toList();
    final others = _stories.where((u) => str(u['user_id']) != Api.userId).toList();
    final cards = <Widget>[
      _card(
        bg: str(Api.me['avatar']),
        avatar: '',
        name: t2(context, 'სთორის დამატება', 'Create story'),
        plus: true,
        onTap: () async {
          await Navigator.of(context)
              .push(MaterialPageRoute<void>(builder: (_) => const StoriesScreen()));
          _load();
        },
      ),
    ];
    if (mine.isNotEmpty) {
      final l = _storiesOf(mine.first);
      if (l.isNotEmpty) cards.add(_storyCard(mine.first, l, you: true));
    }
    for (final u in others) {
      final l = _storiesOf(u);
      if (l.isNotEmpty) cards.add(_storyCard(u, l));
    }
    return cards;
  }

  Widget _userTile(Map<String, dynamic> u) {
    final name = displayName(u);
    final on = str(u['lastseen_status']) == 'on' || _results == null;
    return ListTile(
      leading: Stack(children: [
        Avatar(url: str(u['avatar']), name: name),
        if (on)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: 13,
              height: 13,
              decoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
      ]),
      title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: str(u['username']).isEmpty ? null : Text('@${str(u['username'])}'),
      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => ChatScreen(
              userId: str(u['user_id']), name: name, avatar: str(u['avatar'])))),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = _results ?? _online;
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'ხალხი', 'People'))),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(children: [
          SizedBox(
            height: 210,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
              children: _storyCards(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
            child: TextField(
              controller: _q,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: t2(context, 'მოძებნე ხალხი', 'Search people'),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _q.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _q.clear();
                          _search('');
                        }),
                border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24))),
                isDense: true,
              ),
              onChanged: (_) => setState(() {}),
              onSubmitted: _search,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 4),
            child: Row(children: [
              if (_results == null)
                Container(
                  width: 10,
                  height: 10,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle),
                ),
              Text(
                _results == null
                    ? '${t2(context, 'ონლაინ', 'Online')} (${_online.length})'
                    : t2(context, 'ძებნის შედეგი', 'Search results'),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ]),
          ),
          if (_loading || _searching)
            const Padding(
                padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          if (!_loading && !_searching && list.isEmpty)
            Padding(
              padding: const EdgeInsets.all(32),
              child: Center(
                child: Text(
                  _results == null
                      ? t2(context, 'ახლა არავინ არის ონლაინ', 'Nobody is online right now')
                      : t2(context, 'ვერაფერი მოიძებნა', 'Nothing found'),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          for (final u in list) _userTile(u),
        ]),
      ),
    );
  }
}
