import 'dart:async';
import 'package:flutter/material.dart';
import '../api.dart';
import '../utils.dart';
import 'chat_screen.dart';
import 'story_strip.dart';

/// "People" tab (like Messenger): story cards on top, then everybody on the
/// site (online people first) with a search field.
class PeopleScreen extends StatefulWidget {
  const PeopleScreen({super.key});
  @override
  State<PeopleScreen> createState() => _PeopleScreenState();
}

class _PeopleScreenState extends State<PeopleScreen> {
  List<Map<String, dynamic>> _users = [];
  int _onlineCount = 0;
  bool _serverFile = true;
  final _q = TextEditingController();
  Timer? _timer;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) {
      if (_q.text.trim().isEmpty) _load();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _q.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _maps(dynamic l) =>
      l is List ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];

  Future<void> _load() async {
    final q = _q.text.trim();
    try {
      final res = await Api.gacnobaPeople(q: q);
      final l = _maps(res['users']).where((u) => str(u['user_id']) != Api.userId).toList();
      if (mounted) {
        setState(() {
          _users = l;
          _onlineCount = int.tryParse(str(res['online_count'])) ?? 0;
          _serverFile = true;
          _loading = false;
        });
      }
      return;
    } catch (_) {}
    // Fallback when gacnoba_people.php is not on the site yet.
    try {
      List<Map<String, dynamic>> l;
      if (q.isNotEmpty) {
        l = _maps(await Api.searchUsers(q));
      } else {
        final res = await Api.getChats(limit: '100');
        l = _maps(res['data'])
            .where((c) => str(c['chat_type']).isEmpty || c['chat_type'] == 'user')
            .toList();
        l.sort((a, b) => (str(b['lastseen_status']) == 'on' ? 1 : 0)
            .compareTo(str(a['lastseen_status']) == 'on' ? 1 : 0));
      }
      l = l.where((u) => str(u['user_id']) != Api.userId).toList();
      if (mounted) {
        setState(() {
          _users = l;
          _onlineCount = l.where((u) => str(u['lastseen_status']) == 'on').length;
          _serverFile = false;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Widget _userTile(Map<String, dynamic> u) {
    final name = displayName(u);
    final on = str(u['lastseen_status']) == 'on';
    final seen = str(u['lastseen_time_text']);
    return ListTile(
      leading: Stack(children: [
        Avatar(url: str(u['avatar']), name: name),
        if (on)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: 13,
              height: 13,
              decoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
      ]),
      title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        on ? t2(context, 'ონლაინ', 'Online') : seen,
        style: TextStyle(color: on ? Colors.green : null),
      ),
      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => ChatScreen(
              userId: str(u['user_id']), name: name, avatar: str(u['avatar'])))),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'ხალხი', 'People'))),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(children: [
          const StoryStrip(height: 210),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
            child: TextField(
              controller: _q,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: t2(context, 'მოძებნე ხალხი', 'Search people'),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _q.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _q.clear();
                          setState(() => _loading = true);
                          _load();
                        }),
                border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24))),
                isDense: true,
              ),
              onChanged: (_) => setState(() {}),
              onSubmitted: (_) {
                setState(() => _loading = true);
                _load();
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 4),
            child: Row(children: [
              Text(t2(context, 'ხალხი', 'People'),
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const Spacer(),
              Container(
                width: 9,
                height: 9,
                margin: const EdgeInsets.only(right: 6),
                decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle),
              ),
              Text('$_onlineCount ${t2(context, 'ონლაინ', 'online')}',
                  style: const TextStyle(fontSize: 13)),
            ]),
          ),
          if (!_serverFile)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
              child: Text(
                t2(context, 'მთელი სიისთვის საიტზე ატვირთე gacnoba_people.php (api/v2/endpoints/)',
                    'For the full list upload gacnoba_people.php to the site (api/v2/endpoints/)'),
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
          if (_loading)
            const Padding(
                padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          if (!_loading && _users.isEmpty)
            Padding(
              padding: const EdgeInsets.all(32),
              child: Center(child: Text(t2(context, 'ვერაფერი მოიძებნა', 'Nothing found'))),
            ),
          for (final u in _users) _userTile(u),
        ]),
      ),
    );
  }
}
