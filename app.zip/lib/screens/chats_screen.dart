import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api.dart';
import '../crypto.dart';
import '../i18n.dart';
import '../lang_picker.dart';
import '../push.dart';
import '../utils.dart';
import 'call_screens.dart';
import 'chat_screen.dart';
import 'login_screen.dart';
import 'diagnostics_screen.dart';
import 'search_screen.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});
  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  List<dynamic> _chats = [];
  bool _loading = true;
  String? _error;
  Timer? _timer;
  bool _callOpen = false;
  bool _needsRelogin = false;
  final Set<String> _handledCalls = {};

  @override
  void initState() {
    super.initState();
    _load();
    _checkPush();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    try {
      final res = await Api.getChats();
      if (!mounted) return;
      final list = (res['data'] as List?) ?? [];
      setState(() {
        final users = list
            .where((c) => c is Map && (str(c['chat_type']).isEmpty || c['chat_type'] == 'user'))
            .toList();
        bool isPinned(dynamic c) =>
            c is Map && c['mute'] is Map && str((c['mute'] as Map)['pin']) == 'yes';
        _chats = [...users.where(isPinned), ...users.where((c) => !isPinned(c))];
        _loading = false;
        _error = null;
      });
      if (res['agora_call'] == true && !_callOpen) {
        final d = res['agora_call_data'];
        if (d is Map) {
          final data = Map<String, dynamic>.from(d);
          final call = data['data'];
          final id = call is Map ? str(call['id']) : '';
          if (id.isNotEmpty && !_handledCalls.contains(id)) {
            _handledCalls.add(id);
            _showIncoming(data);
          }
        }
      }
    } on ApiException catch (e) {
      if (e.unauthorized) {
        await Api.clearSession();
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
        return;
      }
      if (!silent && mounted) setState(() {
        _loading = false;
        _error = e.message;
      });
    } catch (e) {
      if (!silent && mounted) setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  /// The site only knows our OneSignal id after a login, so if the id of this
  /// device is not the registered one, ask the user to log in again.
  Future<void> _checkPush() async {
    final pid = await Push.playerId();
    if (pid == null) return;
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString('registered_push_id') != pid && mounted) {
      setState(() => _needsRelogin = true);
    }
  }

  void _chatMenu(Map<String, dynamic> c) {
    final mute = c['mute'] is Map ? Map<String, dynamic>.from(c['mute'] as Map) : <String, dynamic>{};
    final pinned = str(mute['pin']) == 'yes';
    final muted = str(mute['notify']) == 'no';
    final chatId = str(c['chat_id']);
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: Icon(pinned ? Icons.push_pin_outlined : Icons.push_pin),
            title: Text(ctx.tr(pinned ? 'unpin_chat' : 'pin_chat')),
            onTap: () async {
              Navigator.pop(ctx);
              try {
                await Api.muteChat(chatId, pin: pinned ? 'no' : 'yes');
                _load();
              } catch (_) {}
            },
          ),
          ListTile(
            leading: Icon(muted ? Icons.notifications_active : Icons.notifications_off),
            title: Text(ctx.tr(muted ? 'unmute_chat' : 'mute_chat')),
            onTap: () async {
              Navigator.pop(ctx);
              try {
                await Api.muteChat(chatId, notify: muted ? 'yes' : 'no');
                _load();
              } catch (_) {}
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.red),
            title: Text(ctx.tr('clear_chat'), style: const TextStyle(color: Colors.red)),
            onTap: () async {
              Navigator.pop(ctx);
              final ok = await showDialog<bool>(
                context: context,
                builder: (dctx) => AlertDialog(
                  content: Text(dctx.tr('clear_confirm')),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(dctx, false),
                        child: Text(dctx.tr('cancel'))),
                    TextButton(
                        onPressed: () => Navigator.pop(dctx, true),
                        child: Text(dctx.tr('delete'))),
                  ],
                ),
              );
              if (ok == true) {
                try {
                  await Api.deleteConversation(str(c['user_id']));
                  _load();
                } catch (_) {}
              }
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _showIncoming(Map<String, dynamic> data) async {
    _callOpen = true;
    await Navigator.of(context).push(MaterialPageRoute(
        fullscreenDialog: true, builder: (_) => IncomingCallScreen(data: data)));
    _callOpen = false;
  }

  Future<void> _logout() async {
    await Api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
  }

  String _preview(BuildContext context, Map c) {
    final lm = c['last_message'];
    if (lm is! Map) return '';
    final text = cleanText(decryptText(lm['text'], lm['time']));
    if (text.isNotEmpty) return text;
    if (str(lm['media']).isNotEmpty) return '📎 ${context.tr('attachment')}';
    if (str(lm['stickers']).isNotEmpty) return '🙂 ${context.tr('sticker')}';
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        title: Image.asset('assets/logo.png', height: 34),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            tooltip: context.tr('language'),
            onPressed: () => showLanguagePicker(context),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'logout') _logout();
              if (v == 'diag') {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const DiagnosticsScreen()));
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'diag', child: Text(context.tr('diagnostics'))),
              PopupMenuItem(value: 'logout', child: Text(context.tr('logout'))),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const SearchScreen()));
          _load();
        },
        child: const Icon(Icons.edit),
      ),
      body: Column(children: [
        if (_needsRelogin)
          Material(
            color: const Color(0xFFFFF3CD),
            child: ListTile(
              dense: true,
              leading: const Icon(Icons.notifications_active),
              title: Text(context.tr('relogin_for_push')),
              trailing: TextButton(onPressed: _logout, child: Text(context.tr('logout'))),
            ),
          ),
        Expanded(child: _body()),
      ]),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _chats.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => _load(), child: Text(context.tr('retry'))),
          ]),
        ),
      );
    }
    if (_chats.isEmpty) {
      return Center(child: Text(context.tr('no_chats'), textAlign: TextAlign.center));
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        itemCount: _chats.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final c = Map<String, dynamic>.from(_chats[i] as Map);
          final name = displayName(c);
          final unread = int.tryParse(str(c['message_count'])) ?? 0;
          final lm = c['last_message'];
          final timeText = lm is Map ? str(lm['time_text']) : '';
          return ListTile(
            leading: Stack(children: [
              Avatar(url: str(c['avatar']), name: name),
              if (str(c['lastseen_status']) == 'on')
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                  ),
                ),
            ]),
            title: Row(children: [
              Expanded(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis)),
              if (c['mute'] is Map && str((c['mute'] as Map)['pin']) == 'yes')
                const Icon(Icons.push_pin, size: 14, color: Colors.black45),
              if (c['mute'] is Map && str((c['mute'] as Map)['notify']) == 'no')
                const Icon(Icons.notifications_off, size: 14, color: Colors.black45),
            ]),
            subtitle: Text(_preview(context, c), maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(timeText, style: const TextStyle(fontSize: 12)),
                if (unread > 0)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary,
                        borderRadius: BorderRadius.circular(10)),
                    child: Text('$unread',
                        style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ),
              ],
            ),
            onLongPress: () => _chatMenu(c),
            onTap: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ChatScreen(
                      userId: str(c['user_id']), name: name, avatar: str(c['avatar']))));
              _load();
            },
          );
        },
      ),
    );
  }
}
