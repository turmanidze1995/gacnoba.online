import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api.dart';
import '../call_log.dart';
import '../call_watcher.dart';
import '../chat_theme.dart';
import '../crypto.dart';
import '../i18n.dart';
import '../lang_picker.dart';
import '../prefs.dart';
import '../push.dart';
import '../utils.dart';
import 'call_screens.dart';
import 'chat_screen.dart';
import 'login_screen.dart';
import 'calls_screen.dart';
import 'archived_screen.dart';
import 'admin_screen.dart';
import 'new_group_screen.dart';
import 'search_screen.dart';
import 'stories_screen.dart';
import 'story_strip.dart';
import 'live_screens.dart';
import '../updater.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});
  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  List<dynamic> _chats = [];
  bool _loading = true;
  String? _error;
  Timer? _timer;
  bool _callOpen = false;
  bool _needsRelogin = false;
  List<Map<String, dynamic>> _storyUsers = [];
  Timer? _storyTimer;
  final Set<String> _handledCalls = {};
  Map<String, CallEntry> _lastCall = {};

  @override
  void initState() {
    super.initState();
    CallWatcher.start();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) Updater.check(context);
    });
    CallLog.changes.addListener(_loadCalls);
    AppPrefs.callSeenChanges.addListener(_refreshSeen);
    _loadCalls();
    _loadStories();
    _storyTimer = Timer.periodic(const Duration(seconds: 20), (_) => _loadStories());
    Api.loadAdmin().then((_) {
      if (mounted) setState(() {});
    });
    _load();
    _checkPush();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    CallLog.changes.removeListener(_loadCalls);
    AppPrefs.callSeenChanges.removeListener(_refreshSeen);
    _timer?.cancel();
    _storyTimer?.cancel();
    super.dispose();
  }

  void _refreshSeen() {
    if (mounted) setState(() {});
  }

  /// Newest call per person (the call log is stored newest first).
  Future<void> _loadCalls() async {
    final l = await CallLog.load();
    final m = <String, CallEntry>{};
    for (final e in l) {
      if (e.userId.isNotEmpty && !m.containsKey(e.userId)) m[e.userId] = e;
    }
    if (mounted) setState(() => _lastCall = m);
  }

  Future<void> _load({bool silent = false}) async {
    try {
      final res = await Api.getChats();
      List<Map<String, dynamic>> groups = [];
      try {
        groups = await Api.groupList();
      } catch (_) {}
      if (!mounted) return;
      final list = (res['data'] as List?) ?? [];
      setState(() {
        final users = list
            .where((c) =>
                c is Map &&
                (str(c['chat_type']).isEmpty || c['chat_type'] == 'user') &&
                !(c['mute'] is Map && str((c['mute'] as Map)['archive']) == 'yes'))
            .toList();
        bool isPinned(dynamic c) =>
            c is Map && c['mute'] is Map && str((c['mute'] as Map)['pin']) == 'yes';
        int tOf(dynamic c) {
          if (c is Map) {
            final lm = c['last_message'];
            if (lm is Map) {
              final t = int.tryParse(str(lm['time']));
              if (t != null) return t;
            }
            return int.tryParse(str(c['time'])) ?? 0;
          }
          return 0;
        }

        final rest = <dynamic>[
          ...users.where((c) => !isPinned(c)),
          ...groups.map((g) => <String, dynamic>{...g, '_group': true}),
        ];
        rest.sort((a, b) => tOf(b).compareTo(tOf(a)));
        _chats = [...users.where(isPinned), ...rest];
        _loading = false;
        _error = null;
      });
    } on ApiException catch (e) {
      if (e.unauthorized) {
        await Api.clearSession();
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
        return;
      }
      if (!silent && mounted) setState(() {
        _loading = false;
        _error = e.message;
      });
    } catch (e) {
      if (!silent && mounted) setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  /// The site only knows our OneSignal id after a login, so if the id of this
  /// device is not the registered one, ask the user to log in again.
  Future<void> _checkPush() async {
    final pid = await Push.playerId();
    if (pid == null) return;
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString('registered_push_id') != pid && mounted) {
      setState(() => _needsRelogin = true);
    }
  }

  void _chatMenu(Map<String, dynamic> c) {
    final mute = c['mute'] is Map ? Map<String, dynamic>.from(c['mute'] as Map) : <String, dynamic>{};
    final pinned = str(mute['pin']) == 'yes';
    final muted = str(mute['notify']) == 'no';
    final chatId = str(c['chat_id']);
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: Icon(pinned ? Icons.push_pin_outlined : Icons.push_pin),
            title: Text(ctx.tr(pinned ? 'unpin_chat' : 'pin_chat')),
            onTap: () async {
              Navigator.pop(ctx);
              try {
                await Api.muteChat(chatId, pin: pinned ? 'no' : 'yes');
                _load();
              } catch (_) {}
            },
          ),
          ListTile(
            leading: const Icon(Icons.archive_outlined),
            title: Text(ctx.tr('archive_chat')),
            onTap: () async {
              Navigator.pop(ctx);
              try {
                await Api.muteChat(chatId, archive: 'yes');
                _load();
              } catch (_) {}
            },
          ),
          ListTile(
            leading: Icon(muted ? Icons.notifications_active : Icons.notifications_off),
            title: Text(ctx.tr(muted ? 'unmute_chat' : 'mute_chat')),
            onTap: () async {
              Navigator.pop(ctx);
              try {
                await Api.muteChat(chatId, notify: muted ? 'yes' : 'no');
                _load();
              } catch (_) {}
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.red),
            title: Text(ctx.tr('clear_chat'), style: const TextStyle(color: Colors.red)),
            onTap: () async {
              Navigator.pop(ctx);
              final ok = await showDialog<bool>(
                context: context,
                builder: (dctx) => AlertDialog(
                  content: Text(dctx.tr('clear_confirm')),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(dctx, false),
                        child: Text(dctx.tr('cancel'))),
                    TextButton(
                        onPressed: () => Navigator.pop(dctx, true),
                        child: Text(dctx.tr('delete'))),
                  ],
                ),
              );
              if (ok == true) {
                try {
                  await Api.deleteConversation(str(c['user_id']));
                  _load();
                } catch (_) {}
              }
            },
          ),
        ]),
      ),
    );
  }

  String _groupId(Map<String, dynamic> g) =>
      str(g['group_id']).isNotEmpty ? str(g['group_id']) : str(g['id']);

  Widget _groupTile(Map<String, dynamic> g) {
    final name = str(g['group_name']);
    final lm = g['last_message'];
    var preview = '';
    var timeText = '';
    if (lm is Map) {
      final text = stripHidden(cleanText(decryptText(lm['text'], lm['time'])));
      final ud = lm['user_data'];
      final who = ud is Map ? displayName(ud) : '';
      preview = text.isNotEmpty
          ? (who.isNotEmpty ? '$who: $text' : text)
          : (str(lm['media']).isNotEmpty ? '📎' : '');
      timeText = str(lm['time_text']);
    }
    final parts = g['parts'] is List ? g['parts'] as List : <dynamic>[];
    final owner = g['owner'] == true || str(g['owner']) == '1' || str(g['user_id']) == Api.userId;
    return ListTile(
      leading: Stack(children: [
        Avatar(url: str(g['avatar']), name: name),
        const Positioned(
          right: 0,
          bottom: 0,
          child: CircleAvatar(
              radius: 8,
              backgroundColor: Colors.white,
              child: Icon(Icons.groups, size: 12)),
        ),
      ]),
      title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(preview, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Text(timeText, style: const TextStyle(fontSize: 12)),
      onLongPress: () => _groupMenu(g, owner),
      onTap: () async {
        await Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => ChatScreen(
                  userId: _groupId(g),
                  name: name,
                  avatar: str(g['avatar']),
                  isGroup: true,
                  isOwner: owner,
                  members: parts,
                )));
        _load();
      },
    );
  }

  void _groupMenu(Map<String, dynamic> g, bool owner) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.exit_to_app, color: Colors.red),
            title: Text(ctx.tr('leave_group'), style: const TextStyle(color: Colors.red)),
            onTap: () async {
              Navigator.pop(ctx);
              try {
                await Api.groupLeave(_groupId(g));
                _load();
              } catch (_) {}
            },
          ),
          if (owner)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: Text(ctx.tr('delete_group'), style: const TextStyle(color: Colors.red)),
              onTap: () async {
                Navigator.pop(ctx);
                try {
                  await Api.groupDelete(_groupId(g));
                  _load();
                } catch (_) {}
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _showIncoming(Map<String, dynamic> data) async {
    _callOpen = true;
    await Navigator.of(context).push(MaterialPageRoute(
        fullscreenDialog: true, builder: (_) => IncomingCallScreen(data: data)));
    _callOpen = false;
  }

  Future<void> _logout() async {
    CallWatcher.stop();
    await Api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
  }

  String _preview(BuildContext context, Map c) {
    final lm = c['last_message'];
    if (lm is! Map) return '';
    final text = stripHidden(cleanText(decryptText(lm['text'], lm['time'])));
    if (text.isNotEmpty) return text;
    if (str(lm['media']).isNotEmpty) return '📎 ${context.tr('attachment')}';
    if (str(lm['stickers']).isNotEmpty) return '🙂 ${context.tr('sticker')}';
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : null,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Image.asset('assets/logo.png', height: 30),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            tooltip: context.tr('language'),
            onPressed: () => showLanguagePicker(context),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'logout') _logout();
              if (v == 'diag') {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const AdminScreen()));
              }
              if (v == 'archived') {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const ArchivedScreen()));
              }
              if (v == 'calls') {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const CallsScreen()));
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'archived', child: Text(context.tr('archived_chats'))),
              PopupMenuItem(value: 'calls', child: Text(context.tr('calls'))),
              if (Api.isAdmin)
                PopupMenuItem(value: 'diag', child: Text(t2(context, 'საადმინო', 'Admin'))),
              PopupMenuItem(value: 'logout', child: Text(context.tr('logout'))),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final choice = await showModalBottomSheet<String>(
            context: context,
            builder: (ctx) => SafeArea(
              child: Wrap(children: [
                ListTile(
                  leading: const Icon(Icons.person_add),
                  title: Text(ctx.tr('search_people')),
                  onTap: () => Navigator.pop(ctx, 'chat'),
                ),
                ListTile(
                  leading: const Icon(Icons.group_add),
                  title: Text(ctx.tr('new_group')),
                  onTap: () => Navigator.pop(ctx, 'group'),
                ),
              ]),
            ),
          );
          if (!mounted) return;
          if (choice == 'chat') {
            await Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SearchScreen()));
          }
          if (choice == 'group') {
            await Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const NewGroupScreen()));
          }
          _load();
        },
        child: const Icon(Icons.edit),
      ),
      body: Column(children: [
        if (_needsRelogin)
          Theme(
            data: ThemeData.light(),
            child: Material(
            color: const Color(0xFFFFF3CD),
            child: ListTile(
              dense: true,
              leading: const Icon(Icons.notifications_active),
              title: Text(context.tr('relogin_for_push')),
              trailing: TextButton(onPressed: _logout, child: Text(context.tr('logout'))),
            ),
          ),
          ),
        Expanded(child: _body()),
      ]),
    );
  }

  Future<void> _loadStories() async {
    try {
      final l = await Api.getStoryUsers();
      if (mounted) setState(() => _storyUsers = l);
    } catch (_) {}
  }

  Widget _bubble(
      {required String avatar,
      required String name,
      required VoidCallback onTap,
      bool ring = false,
      bool plus = false,
      bool online = false}) {
    final primary = Theme.of(context).colorScheme.primary;
    return InkWell(
      onTap: onTap,
      child: SizedBox(
        width: 72,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Stack(children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: ring ? Border.all(color: primary, width: 2.5) : null,
              ),
              child: Avatar(url: avatar, name: name, radius: 24),
            ),
            if (plus)
              Positioned(
                right: 0,
                bottom: 0,
                child: CircleAvatar(
                    radius: 10,
                    backgroundColor: primary,
                    child: const Icon(Icons.add, size: 14, color: Colors.white)),
              ),
            if (online)
              Positioned(
                right: 2,
                bottom: 2,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                    border: Border.all(color: Theme.of(context).scaffoldBackgroundColor, width: 2),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 4),
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
        ]),
      ),
    );
  }

  List<Map<String, dynamic>> _storiesFrom(Map<String, dynamic> u) {
    final l = u['stories'];
    return l is List
        ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
        : <Map<String, dynamic>>[];
  }

  Widget _myBubble() {
    final mine = _storyUsers.where((u) => str(u['user_id']) == Api.userId).toList();
    final list = mine.isEmpty ? <Map<String, dynamic>>[] : _storiesFrom(mine.first);
    return _bubble(
      avatar: str(Api.me['avatar']),
      name: context.tr('my_story'),
      plus: list.isEmpty,
      ring: list.isNotEmpty,
      onTap: () async {
        if (list.isNotEmpty) {
          await Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => StoryViewerScreen(user: mine.first, stories: list)));
        } else {
          await Navigator.of(context)
              .push(MaterialPageRoute<void>(builder: (_) => const StoriesScreen()));
        }
        _loadStories();
      },
    );
  }

  Widget _strip() {
    final stories = _storyUsers.where((u) => str(u['user_id']) != Api.userId).toList();
    final online = _chats
        .where((c) => c is Map && c['_group'] != true && str(c['lastseen_status']) == 'on')
        .map((c) => Map<String, dynamic>.from(c as Map))
        .toList();
    return SizedBox(
      height: 100,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        children: [
          _myBubble(),
          for (final u in stories)
            _bubble(
              avatar: str(u['avatar']),
              name: displayName(u),
              ring: true,
              onTap: () async {
                final l = u['stories'];
                final list = l is List
                    ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
                    : <Map<String, dynamic>>[];
                if (list.isEmpty) return;
                await Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => StoryViewerScreen(user: u, stories: list)));
                _loadStories();
              },
            ),
          for (final c in online)
            _bubble(
              avatar: str(c['avatar']),
              name: displayName(c),
              online: true,
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => ChatScreen(
                      userId: str(c['user_id']), name: displayName(c), avatar: str(c['avatar'])))),
            ),
        ],
      ),
    );
  }

  Widget _body() {
    return Column(children: [
      const LiveStrip(compact: true),
      const StoryStrip(height: 170, cardWidth: 96),
      const Divider(height: 1),
      Expanded(child: _chatList()),
    ]);
  }

  /// Avatar with a blue ring when the person has a story (grey when already seen).
  Widget _ringAvatar(Map<String, dynamic> c, String name) {
    final uid = str(c['user_id']);
    final su = _storyUsers.where((u) => str(u['user_id']) == uid).toList();
    final list = su.isEmpty ? <Map<String, dynamic>>[] : _storiesFrom(su.first);
    if (list.isEmpty) return Avatar(url: str(c['avatar']), name: name);
    final unseen = list.any((s) => str(s['is_viewed']) == '0' || s['is_viewed'] == false);
    return GestureDetector(
      onTap: () async {
        await Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => StoryViewerScreen(user: su.first, stories: list)));
        _loadStories();
      },
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
              color: unseen ? const Color(0xFF2D88FF) : Colors.grey.shade500, width: 2.5),
        ),
        child: Avatar(url: str(c['avatar']), name: name, radius: 20),
      ),
    );
  }

  String _callLabel(CallEntry e) {
    final video = e.type == 'video';
    if (e.direction == 'missed') {
      return video
          ? t2(context, 'გამოტოვებული ვიდეო ზარი', 'Missed video call')
          : t2(context, 'გამოტოვებული ზარი', 'Missed call');
    }
    return video
        ? t2(context, 'ვიდეო ზარი დასრულდა', 'Video call ended')
        : t2(context, 'ზარი დასრულდა', 'Call ended');
  }

  Widget _chatList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _chats.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => _load(), child: Text(context.tr('retry'))),
          ]),
        ),
      );
    }
    if (_chats.isEmpty) {
      return Center(child: Text(context.tr('no_chats'), textAlign: TextAlign.center));
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        itemCount: _chats.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final c = Map<String, dynamic>.from(_chats[i] as Map);
          if (c['_group'] == true) return _groupTile(c);
          final name = displayName(c);
          final unread = int.tryParse(str(c['message_count'])) ?? 0;
          final lm = c['last_message'];
          final timeText = lm is Map ? str(lm['time_text']) : '';
          final uid = str(c['user_id']);
          final lastCall = _lastCall[uid];
          final lmTime = lm is Map ? (int.tryParse(str(lm['time'])) ?? 0) : 0;
          // a call newer than the last message is shown instead of the message
          final CallEntry? call = (lastCall != null && lastCall.time >= lmTime) ? lastCall : null;
          final missedNew = call != null &&
              call.direction == 'missed' &&
              call.time > (AppPrefs.callSeen[uid] ?? 0);
          final onSurfaceVar = Theme.of(context).colorScheme.onSurfaceVariant;
          return ListTile(
            leading: Stack(children: [
              _ringAvatar(c, name),
              if (str(c['lastseen_status']) == 'on')
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                      border: Border.all(color: Theme.of(context).scaffoldBackgroundColor, width: 2),
                    ),
                  ),
                ),
            ]),
            title: Row(children: [
              Expanded(
                  child: Text(name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: (unread > 0 || missedNew)
                          ? const TextStyle(fontWeight: FontWeight.bold)
                          : null)),
              if (c['mute'] is Map && str((c['mute'] as Map)['pin']) == 'yes')
                const Icon(Icons.push_pin, size: 14, color: Colors.black45),
              if (c['mute'] is Map && str((c['mute'] as Map)['notify']) == 'no')
                const Icon(Icons.notifications_off, size: 14, color: Colors.black45),
            ]),
            subtitle: call != null
                ? Row(children: [
                    Icon(
                        call.direction == 'missed'
                            ? Icons.call_missed
                            : (call.type == 'video' ? Icons.videocam : Icons.call),
                        size: 16,
                        color: call.direction == 'missed' ? Colors.red : onSurfaceVar),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(_callLabel(call),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: missedNew ? Colors.red : null,
                              fontWeight: missedNew ? FontWeight.bold : null)),
                    ),
                  ])
                : Text(_preview(context, c),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: unread > 0 ? const TextStyle(fontWeight: FontWeight.w600) : null),
            trailing: (missedNew && call != null)
                ? Row(mainAxisSize: MainAxisSize.min, children: [
                    GestureDetector(
                      onTap: () async {
                        try {
                          await startCall(context,
                              userId: uid,
                              name: name,
                              avatar: str(c['avatar']),
                              video: call.type == 'video');
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text('$e')));
                          }
                        }
                      },
                      child: CircleAvatar(
                        radius: 20,
                        backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                        child: Icon(call.type == 'video' ? Icons.videocam : Icons.call, size: 20),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const CircleAvatar(radius: 5, backgroundColor: Color(0xFF2D88FF)),
                  ])
                : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(timeText, style: const TextStyle(fontSize: 12)),
                if (unread > 0)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary,
                        borderRadius: BorderRadius.circular(10)),
                    child: Text('$unread',
                        style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ),
              ],
            ),
            onLongPress: () => _chatMenu(c),
            onTap: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ChatScreen(
                      userId: str(c['user_id']),
                      name: name,
                      avatar: str(c['avatar']),
                      chatId: str(c['chat_id']),
                      muted: c['mute'] is Map && str((c['mute'] as Map)['notify']) == 'no')));
              _load();
            },
          );
        },
      ),
    );
  }
}
