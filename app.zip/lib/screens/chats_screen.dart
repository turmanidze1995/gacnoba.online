import 'dart:async';
import 'package:flutter/material.dart';
import '../api.dart';
import '../config.dart';
import '../crypto.dart';
import '../utils.dart';
import 'call_screens.dart';
import 'chat_screen.dart';
import 'login_screen.dart';
import 'search_screen.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});
  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  List<dynamic> _chats = [];
  bool _loading = true;
  String? _error;
  Timer? _timer;
  bool _callOpen = false;
  final Set<String> _handledCalls = {};

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    try {
      final res = await Api.getChats();
      if (!mounted) return;
      final list = (res['data'] as List?) ?? [];
      setState(() {
        _chats = list
            .where((c) => c is Map && (str(c['chat_type']).isEmpty || c['chat_type'] == 'user'))
            .toList();
        _loading = false;
        _error = null;
      });
      if (res['agora_call'] == true && !_callOpen) {
        final d = res['agora_call_data'];
        if (d is Map) {
          final data = Map<String, dynamic>.from(d);
          final call = data['data'];
          final id = call is Map ? str(call['id']) : '';
          if (id.isNotEmpty && !_handledCalls.contains(id)) {
            _handledCalls.add(id);
            _showIncoming(data);
          }
        }
      }
    } on ApiException catch (e) {
      if (e.unauthorized) {
        await Api.clearSession();
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
        return;
      }
      if (!silent && mounted) setState(() {
        _loading = false;
        _error = e.message;
      });
    } catch (e) {
      if (!silent && mounted) setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  Future<void> _showIncoming(Map<String, dynamic> data) async {
    _callOpen = true;
    await Navigator.of(context).push(MaterialPageRoute(
        fullscreenDialog: true, builder: (_) => IncomingCallScreen(data: data)));
    _callOpen = false;
  }

  Future<void> _logout() async {
    await Api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
  }

  String _preview(Map c) {
    final lm = c['last_message'];
    if (lm is! Map) return '';
    final text = cleanText(decryptText(lm['text'], lm['time']));
    if (text.isNotEmpty) return text;
    if (str(lm['media']).isNotEmpty) return '📎 Attachment';
    if (str(lm['stickers']).isNotEmpty) return '🙂 Sticker';
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Config.appName),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'logout') _logout();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'logout', child: Text('Log out')),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const SearchScreen()));
          _load();
        },
        child: const Icon(Icons.edit),
      ),
      body: _body(),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _chats.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => _load(), child: const Text('Retry')),
          ]),
        ),
      );
    }
    if (_chats.isEmpty) {
      return const Center(child: Text('No chats yet. Tap the pencil to start one.'));
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        itemCount: _chats.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final c = Map<String, dynamic>.from(_chats[i] as Map);
          final name = displayName(c);
          final unread = int.tryParse(str(c['message_count'])) ?? 0;
          final lm = c['last_message'];
          final timeText = lm is Map ? str(lm['time_text']) : '';
          return ListTile(
            leading: Avatar(url: str(c['avatar']), name: name),
            title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(_preview(c), maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(timeText, style: const TextStyle(fontSize: 12)),
                if (unread > 0)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary,
                        borderRadius: BorderRadius.circular(10)),
                    child: Text('$unread',
                        style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ),
              ],
            ),
            onTap: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ChatScreen(
                      userId: str(c['user_id']), name: name, avatar: str(c['avatar']))));
              _load();
            },
          );
        },
      ),
    );
  }
}
