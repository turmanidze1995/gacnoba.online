import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../api.dart';
import '../i18n.dart';
import '../utils.dart';

/// Screen shown when somebody calls us (detected by polling get_chats).
class IncomingCallScreen extends StatefulWidget {
  final Map<String, dynamic> data; // agora_call_data from get_chats
  const IncomingCallScreen({super.key, required this.data});
  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  Timer? _expire;

  Map get _call => (widget.data['data'] as Map?) ?? {};

  @override
  void initState() {
    super.initState();
    // WoWonder keeps a call "ringing" for ~40 seconds.
    _expire = Timer(const Duration(seconds: 40), () {
      if (mounted) Navigator.of(context).maybePop();
    });
  }

  @override
  void dispose() {
    _expire?.cancel();
    super.dispose();
  }

  Future<void> _accept() async {
    final id = str(_call['id']);
    try {
      await Api.agoraAction(id, 'answer');
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => CallScreen(
              channel: str(_call['room_name']),
              token: str(_call['access_token']),
              video: str(_call['type']) == 'video',
              peerName: str(widget.data['name']),
              peerAvatar: str(widget.data['avatar']),
              callId: id,
              outgoing: false,
            )));
  }

  Future<void> _decline() async {
    try {
      await Api.agoraAction(str(_call['id']), 'decline');
    } catch (_) {}
    if (mounted) Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final name = str(widget.data['name']);
    final video = str(_call['type']) == 'video';
    return Scaffold(
      backgroundColor: const Color(0xFF111418),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Column(children: [
              Avatar(url: str(widget.data['avatar']), name: name, radius: 56),
              const SizedBox(height: 20),
              Text(name, style: const TextStyle(color: Colors.white, fontSize: 26)),
              const SizedBox(height: 8),
              Text(video ? context.tr('incoming_video') : context.tr('incoming_audio'),
                  style: const TextStyle(color: Colors.white70)),
            ]),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _roundButton(Icons.call_end, Colors.red, _decline),
              _roundButton(video ? Icons.videocam : Icons.call, Colors.green, _accept),
            ]),
          ],
        ),
      ),
    );
  }
}

Widget _roundButton(IconData icon, Color color, VoidCallback onTap) {
  return InkWell(
    onTap: onTap,
    customBorder: const CircleBorder(),
    child: Container(
      width: 68,
      height: 68,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      child: Icon(icon, color: Colors.white, size: 32),
    ),
  );
}

/// Audio / video call through Agora. The WoWonder server creates the call,
/// the token and the push notification; we only join the channel.
class CallScreen extends StatefulWidget {
  final String channel;
  final String token;
  final bool video;
  final String peerName;
  final String peerAvatar;
  final String callId;
  final bool outgoing;
  const CallScreen({
    super.key,
    required this.channel,
    required this.token,
    required this.video,
    required this.peerName,
    required this.callId,
    required this.outgoing,
    this.peerAvatar = '',
  });
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  RtcEngine? _engine;
  int? _remoteUid;
  bool _joined = false;
  bool _muted = false;
  bool _speaker = false;
  bool _ending = false;
  String _status = 'connecting';
  Timer? _poll;
  Timer? _timeout;

  @override
  void initState() {
    super.initState();
    _speaker = widget.video;
    _init();
  }

  Future<void> _init() async {
    try {
      final perms = <Permission>[Permission.microphone];
      if (widget.video) perms.add(Permission.camera);
      final statuses = await perms.request();
      if (statuses.values.any((s) => !s.isGranted)) {
        _end('permission_denied');
        return;
      }
      final appId = await Api.getAgoraAppId();
      if (appId == null || appId.isEmpty) {
        _end('Agora App ID is not set in the site admin panel', isKey: false);
        return;
      }
      final engine = createAgoraRtcEngine();
      _engine = engine;
      await engine.initialize(RtcEngineContext(
        appId: appId,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ));
      engine.registerEventHandler(RtcEngineEventHandler(
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          if (!mounted) return;
          setState(() {
            _joined = true;
            _status = widget.outgoing ? 'ringing' : 'connecting';
          });
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          _timeout?.cancel();
          if (!mounted) return;
          setState(() {
            _remoteUid = remoteUid;
            _status = 'connected';
          });
        },
        onUserOffline:
            (RtcConnection connection, int remoteUid, UserOfflineReasonType reason) {
          _end('call_ended');
        },
      ));
      if (widget.video) {
        await engine.enableVideo();
        await engine.startPreview();
      } else {
        await engine.enableAudio();
      }
      await engine.setEnableSpeakerphone(_speaker);
      await engine.joinChannel(
        token: widget.token,
        channelId: widget.channel,
        uid: 0,
        options: const ChannelMediaOptions(
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
          channelProfile: ChannelProfileType.channelProfileCommunication,
        ),
      );
      if (widget.outgoing) {
        _timeout = Timer(const Duration(seconds: 45), () => _end('no_answer'));
        _poll = Timer.periodic(const Duration(seconds: 2), (_) async {
          try {
            final s = await Api.agoraCheck(widget.callId);
            if (s == 'declined') _end('call_declined');
          } catch (_) {}
        });
      }
    } catch (e) {
      _end('Call failed: $e', isKey: false);
    }
  }

  Future<void> _end(String message, {bool isKey = true}) async {
    if (_ending) return;
    _ending = true;
    _poll?.cancel();
    _timeout?.cancel();
    try {
      await _engine?.leaveChannel();
      await _engine?.release();
    } catch (_) {}
    _engine = null;
    if (widget.outgoing) {
      try {
        await Api.agoraAction(widget.callId, 'close');
      } catch (_) {}
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(isKey ? context.tr(message) : message)));
    Navigator.of(context).maybePop();
  }

  @override
  void dispose() {
    _poll?.cancel();
    _timeout?.cancel();
    if (!_ending) {
      _engine?.leaveChannel();
      _engine?.release();
    }
    super.dispose();
  }

  Widget _background() {
    final engine = _engine;
    if (widget.video && engine != null && _remoteUid != null) {
      return AgoraVideoView(
        controller: VideoViewController.remote(
          rtcEngine: engine,
          canvas: VideoCanvas(uid: _remoteUid),
          connection: RtcConnection(channelId: widget.channel),
        ),
      );
    }
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Avatar(url: widget.peerAvatar, name: widget.peerName, radius: 56),
        const SizedBox(height: 20),
        Text(widget.peerName, style: const TextStyle(color: Colors.white, fontSize: 26)),
        const SizedBox(height: 8),
        Text(context.tr(_status), style: const TextStyle(color: Colors.white70)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final engine = _engine;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _end('call_ended');
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF111418),
        body: Stack(children: [
          Positioned.fill(child: _background()),
          if (widget.video && _joined && engine != null)
            Positioned(
              top: 48,
              right: 16,
              width: 110,
              height: 160,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: engine,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 36,
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _roundButton(_muted ? Icons.mic_off : Icons.mic, Colors.white24, () async {
                setState(() => _muted = !_muted);
                await _engine?.muteLocalAudioStream(_muted);
              }),
              _roundButton(_speaker ? Icons.volume_up : Icons.volume_down, Colors.white24,
                  () async {
                setState(() => _speaker = !_speaker);
                await _engine?.setEnableSpeakerphone(_speaker);
              }),
              if (widget.video)
                _roundButton(Icons.cameraswitch, Colors.white24, () async {
                  await _engine?.switchCamera();
                }),
              _roundButton(Icons.call_end, Colors.red, () => _end('call_ended')),
            ]),
          ),
        ]),
      ),
    );
  }
}
