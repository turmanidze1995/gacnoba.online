import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import '../api.dart';
import '../call_log.dart';
import '../config.dart';
import '../i18n.dart';
import '../utils.dart';

int _nowSeconds() => DateTime.now().millisecondsSinceEpoch ~/ 1000;

/// Starts an outgoing call through the site's Twilio API (same as the website).
Future<void> startCall(
  BuildContext context, {
  required String userId,
  required String name,
  required String avatar,
  required bool video,
}) async {
  final nav = Navigator.of(context);
  final res = await Api.twilioCreate(userId, video ? 'video' : 'audio');
  // The website joins the caller with access_token_2 and the callee with access_token.
  await nav.push(MaterialPageRoute<void>(
      builder: (_) => CallScreen(
            room: str(res['room_name']),
            token: str(res['access_token_2']),
            video: video,
            peerName: name,
            peerAvatar: avatar,
            peerUserId: userId,
            callId: str(res['id']),
            outgoing: true,
          )));
}

/// Screen shown when somebody calls us (detected by CallWatcher).
class IncomingCallScreen extends StatefulWidget {
  /// {type: video|audio, user_id, name, avatar, data: {id, room_name, access_token, ...}}
  final Map<String, dynamic> data;
  const IncomingCallScreen({super.key, required this.data});
  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  Timer? _expire;
  bool _answered = false;

  Map get _call => (widget.data['data'] as Map?) ?? {};
  String get _type => str(widget.data['type']) == 'audio' ? 'audio' : 'video';

  String get _peerId {
    final id = str(widget.data['user_id']);
    return id.isNotEmpty ? id : str(_call['from_id']);
  }

  void _logMissed() {
    CallLog.add(CallEntry(
      userId: _peerId,
      name: str(widget.data['name']),
      avatar: str(widget.data['avatar']),
      type: _type,
      direction: 'missed',
      time: _nowSeconds(),
      seconds: 0,
    )).catchError((Object _) {});
  }

  @override
  void initState() {
    super.initState();
    // The site keeps a call "ringing" for ~40 seconds.
    _expire = Timer(const Duration(seconds: 40), () {
      if (!mounted || _answered) return;
      _logMissed();
      Navigator.of(context).pop();
    });
  }

  @override
  void dispose() {
    _expire?.cancel();
    super.dispose();
  }

  Future<void> _accept() async {
    _answered = true;
    _expire?.cancel();
    final id = str(_call['id']);
    try {
      await Api.twilioAction(id, _type, 'answer');
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
        builder: (_) => CallScreen(
              room: str(_call['room_name']),
              token: str(_call['access_token']),
              video: _type == 'video',
              peerName: str(widget.data['name']),
              peerAvatar: str(widget.data['avatar']),
              peerUserId: _peerId,
              callId: id,
              outgoing: false,
            )));
  }

  Future<void> _decline() async {
    _answered = true;
    _expire?.cancel();
    _logMissed();
    try {
      await Api.twilioAction(str(_call['id']), _type, 'decline')
          .timeout(const Duration(seconds: 6));
    } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final name = str(widget.data['name']);
    final video = _type == 'video';
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _decline();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF111418),
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(children: [
                Avatar(url: str(widget.data['avatar']), name: name, radius: 56),
                const SizedBox(height: 20),
                Text(name, style: const TextStyle(color: Colors.white, fontSize: 26)),
                const SizedBox(height: 8),
                Text(video ? context.tr('incoming_video') : context.tr('incoming_audio'),
                    style: const TextStyle(color: Colors.white70)),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                _roundButton(Icons.call_end, Colors.red, _decline),
                _roundButton(video ? Icons.videocam : Icons.call, Colors.green, _accept),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _roundButton(IconData icon, Color color, VoidCallback onTap) {
  return InkWell(
    onTap: onTap,
    customBorder: const CircleBorder(),
    child: Container(
      width: 68,
      height: 68,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      child: Icon(icon, color: Colors.white, size: 32),
    ),
  );
}

/// The call itself. Twilio has no Flutter SDK, so the call runs in a WebView with
/// twilio-video.js (the same library the website uses) and the tokens from the site API.
const String _callHtml = r'''<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<style>
html,body{margin:0;height:100%;background:#111418;overflow:hidden}
#remote{position:absolute;left:0;top:0;right:0;bottom:0}
#remote video{width:100%;height:100%;object-fit:cover}
#local{position:absolute;top:48px;right:16px;width:110px;height:160px;border-radius:12px;overflow:hidden;background:#000}
#local video{width:100%;height:100%;object-fit:cover;transform:scaleX(-1)}
</style></head><body>
<div id="remote"></div><div id="local"></div>
<script>
var CFG = __CFG__;
var room = null, facing = 'user';
function post(m){ try { Call.postMessage(m); } catch(e){} }
var remoteEl = document.getElementById('remote');
var localEl = document.getElementById('local');
function attach(track){
  if (track.kind === 'video') { remoteEl.appendChild(track.attach()); }
  else if (track.kind === 'audio') { var a = track.attach(); a.autoplay = true; document.body.appendChild(a); a.play && a.play().catch(function(){}); }
}
function partConnected(p){
  post('peer');
  p.tracks.forEach(function(pub){ if (pub.track) attach(pub.track); });
  p.on('trackSubscribed', attach);
  p.on('trackUnsubscribed', function(t){ t.detach().forEach(function(n){ n.remove(); }); });
}
window.setMute = function(m){
  if (!room) return;
  room.localParticipant.audioTracks.forEach(function(pub){ m ? pub.track.disable() : pub.track.enable(); });
};
window.flipCamera = function(){
  if (!room) return;
  facing = facing === 'user' ? 'environment' : 'user';
  room.localParticipant.videoTracks.forEach(function(pub){ pub.track.restart({facingMode: facing}); });
};
window.hangup = function(){ try { if (room) room.disconnect(); } catch(e){} };
function start(){
  var opts = { name: CFG.room, audio: true, video: CFG.video ? { width: 640, height: 480, facingMode: 'user' } : false };
  Twilio.Video.connect(CFG.token, opts).then(function(r){
    room = r;
    post('joined');
    if (CFG.video) {
      r.localParticipant.videoTracks.forEach(function(pub){ localEl.appendChild(pub.track.attach()); });
    }
    r.participants.forEach(partConnected);
    r.on('participantConnected', partConnected);
    r.on('participantDisconnected', function(){ post('left'); });
    r.on('disconnected', function(){ post('disconnected'); });
  }).catch(function(e){ post('error:' + ((e && (e.message || e.name)) || e)); });
}
function load(urls, i){
  if (i >= urls.length) { post('error:Twilio SDK could not be loaded'); return; }
  var s = document.createElement('script');
  s.src = urls[i];
  s.onload = start;
  s.onerror = function(){ load(urls, i + 1); };
  document.head.appendChild(s);
}
load([CFG.site + '/themes/wowonder/javascript/twilio-video.min.js',
      'https://sdk.twilio.com/js/video/releases/2.18.1/twilio-video.min.js'], 0);
</script></body></html>''';

class CallScreen extends StatefulWidget {
  final String room;
  final String token;
  final bool video;
  final String peerName;
  final String peerAvatar;
  final String peerUserId;
  final String callId;
  final bool outgoing;
  const CallScreen({
    super.key,
    required this.room,
    required this.token,
    required this.video,
    required this.peerName,
    required this.callId,
    required this.outgoing,
    this.peerAvatar = '',
    this.peerUserId = '',
  });
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  WebViewController? _web;
  bool _peerIn = false;
  bool _muted = false;
  bool _ending = false;
  String _status = 'connecting';
  Timer? _poll;
  Timer? _timeout;
  DateTime? _connectedAt;

  String get _type => widget.video ? 'video' : 'audio';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final perms = <Permission>[Permission.microphone];
      if (widget.video) perms.add(Permission.camera);
      final statuses = await perms.request();
      if (statuses.values.any((s) => !s.isGranted)) {
        _end('permission_denied');
        return;
      }
      if (widget.token.isEmpty || widget.room.isEmpty) {
        _end('Call failed: the site returned no Twilio token. Check Twilio settings in admin-cp.',
            isKey: false);
        return;
      }
      final cfg = jsonEncode({
        'site': Config.siteUrl,
        'room': widget.room,
        'token': widget.token,
        'video': widget.video,
      }).replaceAll('<', '\\u003c');
      final html = _callHtml.replaceFirst('__CFG__', cfg);

      final c = WebViewController(onPermissionRequest: (req) => req.grant())
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF111418))
        ..addJavaScriptChannel('Call', onMessageReceived: (m) => _onMsg(m.message))
        ..loadHtmlString(html, baseUrl: Config.siteUrl);
      final platform = c.platform;
      if (platform is AndroidWebViewController) {
        await platform.setMediaPlaybackRequiresUserGesture(false);
      }
      if (!mounted) return;
      setState(() => _web = c);

      // nobody joined within 45 seconds
      _timeout = Timer(const Duration(seconds: 45), () {
        if (!_peerIn) _end('no_answer');
      });
      // watch the call row on the site (declined by the other side)
      _poll = Timer.periodic(const Duration(seconds: 3), (_) async {
        if (_ending) return;
        try {
          final s = await Api.twilioCheck(widget.callId, _type);
          if (s == 'declined') _end('call_declined');
        } catch (_) {}
      });
    } catch (e) {
      _end('Call failed: $e', isKey: false);
    }
  }

  void _onMsg(String m) {
    if (!mounted || _ending) return;
    if (m == 'joined') {
      setState(() => _status = widget.outgoing ? 'ringing' : 'connecting');
    } else if (m == 'peer') {
      _timeout?.cancel();
      _connectedAt ??= DateTime.now();
      setState(() {
        _peerIn = true;
        _status = 'connected';
      });
    } else if (m == 'left') {
      _end('call_ended');
    } else if (m.startsWith('error:')) {
      _end('Call failed: ${m.substring(6)}', isKey: false);
    }
  }

  Future<void> _end(String message, {bool isKey = true}) async {
    if (_ending) return;
    _ending = true;
    _poll?.cancel();
    _timeout?.cancel();
    final secs = _connectedAt == null ? 0 : DateTime.now().difference(_connectedAt!).inSeconds;
    CallLog.add(CallEntry(
      userId: widget.peerUserId,
      name: widget.peerName,
      avatar: widget.peerAvatar,
      type: _type,
      direction: widget.outgoing ? 'out' : (secs > 0 ? 'in' : 'missed'),
      time: _nowSeconds(),
      seconds: secs,
    )).catchError((Object _) {});
    final web = _web;
    try {
      await web?.runJavaScript('window.hangup()');
    } catch (_) {}
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(isKey ? context.tr(message) : message)));
      Navigator.of(context).pop();
    }
    if (widget.outgoing) {
      try {
        await Api.twilioAction(widget.callId, _type, 'close').timeout(const Duration(seconds: 8));
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    _timeout?.cancel();
    if (!_ending) {
      _ending = true;
      _web?.runJavaScript('window.hangup()');
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final showVideo = widget.video && _peerIn;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _end('call_ended');
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF111418),
        body: Stack(children: [
          if (_web != null) Positioned.fill(child: WebViewWidget(controller: _web!)),
          if (!showVideo)
            Positioned.fill(
              child: Container(
                color: const Color(0xFF111418),
                child: Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Avatar(url: widget.peerAvatar, name: widget.peerName, radius: 56),
                    const SizedBox(height: 20),
                    Text(widget.peerName,
                        style: const TextStyle(color: Colors.white, fontSize: 26)),
                    const SizedBox(height: 8),
                    Text(context.tr(_status), style: const TextStyle(color: Colors.white70)),
                  ]),
                ),
              ),
            ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 36,
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _roundButton(_muted ? Icons.mic_off : Icons.mic, Colors.white24, () async {
                setState(() => _muted = !_muted);
                await _web?.runJavaScript('window.setMute($_muted)');
              }),
              if (widget.video)
                _roundButton(Icons.cameraswitch, Colors.white24, () async {
                  await _web?.runJavaScript('window.flipCamera()');
                }),
              _roundButton(Icons.call_end, Colors.red, () => _end('call_ended')),
            ]),
          ),
        ]),
      ),
    );
  }
}
