import 'package:flutter/material.dart';
import '../api.dart';
import '../i18n.dart';
import '../utils.dart';
import 'chat_screen.dart';

class ArchivedScreen extends StatefulWidget {
  const ArchivedScreen({super.key});
  @override
  State<ArchivedScreen> createState() => _ArchivedScreenState();
}

class _ArchivedScreenState extends State<ArchivedScreen> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.archivedChats();
      if (mounted) setState(() => _items = l);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('archived_chats'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? Center(child: Text(context.tr('no_chats')))
              : ListView(children: [
                  for (final c in _items)
                    ListTile(
                      leading: Avatar(url: str(c['avatar']), name: displayName(c)),
                      title: Text(displayName(c)),
                      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                          builder: (_) => ChatScreen(
                              userId: str(c['user_id']),
                              name: displayName(c),
                              avatar: str(c['avatar']),
                              chatId: str(c['chat_id'])))),
                      trailing: IconButton(
                        tooltip: context.tr('unarchive_chat'),
                        icon: const Icon(Icons.unarchive),
                        onPressed: () async {
                          try {
                            await Api.muteChat(str(c['chat_id']), archive: 'no');
                            _load();
                          } catch (_) {}
                        },
                      ),
                    ),
                ]),
    );
  }
}
