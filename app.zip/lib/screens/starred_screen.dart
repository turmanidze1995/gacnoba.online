import 'package:flutter/material.dart';
import '../api.dart';
import '../crypto.dart';
import '../i18n.dart';
import '../utils.dart';

class StarredScreen extends StatefulWidget {
  final String chatId;
  const StarredScreen({super.key, required this.chatId});
  @override
  State<StarredScreen> createState() => _StarredScreenState();
}

class _StarredScreenState extends State<StarredScreen> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.favMessages(widget.chatId);
      if (mounted) setState(() => _items = l);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Map<String, dynamic> _src(Map<String, dynamic> m) =>
      m['message'] is Map ? Map<String, dynamic>.from(m['message'] as Map) : m;

  String _text(Map<String, dynamic> m) {
    final src = _src(m);
    final t = cleanText(decryptText(src['text'], src['time']));
    if (t.isNotEmpty) return t;
    return str(src['media']).isNotEmpty ? 'File' : '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('starred_messages'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Icon(Icons.star_border, size: 48, color: Colors.black26))
              : ListView.separated(
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) => ListTile(
                    leading: const Icon(Icons.star, color: Colors.amber),
                    title: Text(_text(_items[i])),
                    subtitle: Text(str(_src(_items[i])['time_text'])),
                  ),
                ),
    );
  }
}
