import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../emoji_data.dart';
import '../utils.dart';
import 'gif_sheet.dart';
import 'music_sheet.dart';

/// Result of the story editor: the finished picture and the caption
/// (the caption ends with "♪<preview url>" when a song was added).
class StoryDraft {
  final String path;
  final String caption;

  /// Preview url of the chosen song ('' = no song). It is sent in the story
  /// description, because the site limits the story title to 100 characters.
  final String music;
  StoryDraft(this.path, this.caption, [this.music = '']);
}

class _Overlay {
  final Widget child;
  Offset pos;
  double scale = 1;
  double baseScale = 1;
  _Overlay(this.child, this.pos);
}

/// Story editor: photo + emoji, stickers, text and a song (like Messenger).
class StoryComposerScreen extends StatefulWidget {
  final String imagePath;
  const StoryComposerScreen({super.key, required this.imagePath});
  @override
  State<StoryComposerScreen> createState() => _StoryComposerScreenState();
}

class _StoryComposerScreenState extends State<StoryComposerScreen> {
  final GlobalKey _boundary = GlobalKey();
  final List<_Overlay> _items = [];
  final TextEditingController _caption = TextEditingController();
  Size _area = const Size(300, 500);
  String _musicUrl = '';
  _Overlay? _musicOverlay;
  bool _busy = false;

  @override
  void dispose() {
    _caption.dispose();
    super.dispose();
  }

  void _add(Widget child, {bool music = false}) {
    final o = _Overlay(child, Offset(_area.width / 2 - 50, _area.height / 2 - 50));
    setState(() {
      if (music) {
        if (_musicOverlay != null) _items.remove(_musicOverlay);
        _musicOverlay = o;
      }
      _items.add(o);
    });
  }

  Future<void> _addEmoji() async {
    final e = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: 300,
          child: GridView.builder(
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
            itemCount: kEmojis.length,
            itemBuilder: (_, i) => InkWell(
              onTap: () => Navigator.pop(ctx, kEmojis[i]),
              child: Center(child: Text(kEmojis[i], style: const TextStyle(fontSize: 26))),
            ),
          ),
        ),
      ),
    );
    if (e == null) return;
    _add(Text(e, style: const TextStyle(fontSize: 64)));
  }

  Future<void> _addSticker() async {
    final item = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const GifSheet(stickers: true),
    );
    if (item == null) return;
    final url = item['send'] ?? '';
    if (url.isEmpty) return;
    _add(Image.network(url, width: 170, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)));
  }

  Future<void> _addText() async {
    final c = TextEditingController();
    final txt = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: TextField(controller: c, autofocus: true, maxLength: 80),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('✕')),
          TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('OK')),
        ],
      ),
    );
    if (txt == null || txt.isEmpty) return;
    _add(Text(
      txt,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 32,
        fontWeight: FontWeight.bold,
        shadows: [Shadow(color: Colors.black87, blurRadius: 6)],
      ),
    ));
  }

  Future<void> _addMusic() async {
    final it = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const MusicSheet(),
    );
    if (it == null) return;
    _musicUrl = it['preview'] ?? '';
    _add(
      Container(
        width: 230,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.92), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          if ((it['art'] ?? '').isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(it['art']!, width: 44, height: 44, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(Icons.music_note)),
            ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(it['title'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              Text(it['artist'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.black54, fontSize: 12)),
            ]),
          ),
          const Icon(Icons.music_note, color: Colors.black87),
        ]),
      ),
      music: true,
    );
  }

  Future<void> _post() async {
    setState(() => _busy = true);
    try {
      final ro = _boundary.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await ro.toImage(pixelRatio: 2.5);
      final bd = await img.toByteData(format: ui.ImageByteFormat.png);
      if (bd == null) throw Exception('render failed');
      final f = File('${Directory.systemTemp.path}/story_${DateTime.now().millisecondsSinceEpoch}.png');
      await f.writeAsBytes(bd.buffer.asUint8List());
      final cap = _caption.text.trim();
      if (!mounted) return;
      Navigator.of(context).pop(StoryDraft(f.path, cap, _musicUrl));
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  Widget _overlay(_Overlay o) {
    return Positioned(
      left: o.pos.dx,
      top: o.pos.dy,
      child: GestureDetector(
        onScaleStart: (_) => o.baseScale = o.scale,
        onScaleUpdate: (d) => setState(() {
          o.pos += d.focalPointDelta;
          o.scale = (o.baseScale * d.scale).clamp(0.4, 5.0).toDouble();
        }),
        onLongPress: () => setState(() {
          _items.remove(o);
          if (identical(o, _musicOverlay)) {
            _musicOverlay = null;
            _musicUrl = '';
          }
        }),
        child: Transform.scale(scale: o.scale, child: o.child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(children: [
          Row(children: [
            IconButton(
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: () => Navigator.of(context).pop()),
            const Spacer(),
            IconButton(
                tooltip: 'Emoji',
                icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white),
                onPressed: _addEmoji),
            IconButton(
                tooltip: 'Sticker',
                icon: const Icon(Icons.sticky_note_2_outlined, color: Colors.white),
                onPressed: _addSticker),
            IconButton(
                tooltip: 'Text',
                icon: const Icon(Icons.text_fields, color: Colors.white),
                onPressed: _addText),
            IconButton(
                tooltip: 'Music',
                icon: const Icon(Icons.music_note, color: Colors.white),
                onPressed: _addMusic),
          ]),
          Expanded(
            child: LayoutBuilder(builder: (ctx, cons) {
              _area = Size(cons.maxWidth, cons.maxHeight);
              return RepaintBoundary(
                key: _boundary,
                child: ClipRect(
                  child: Container(
                    color: Colors.black,
                    child: Stack(children: [
                      Positioned.fill(
                        child: Image.file(File(widget.imagePath), fit: BoxFit.contain),
                      ),
                      for (final o in _items) _overlay(o),
                    ]),
                  ),
                ),
              );
            }),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(10, 6, 10, 8 + MediaQuery.of(context).viewInsets.bottom),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _caption,
                  maxLength: 100,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    counterText: '',
                    hintText: t2(context, 'წარწერა (არასავალდებულო)', 'Caption (optional)'),
                    hintStyle: const TextStyle(color: Colors.white54),
                    isDense: true,
                    enabledBorder: const OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white38)),
                    focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: _busy ? null : _post,
                icon: _busy
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.send),
                label: Text(t2(context, 'გამოქვეყნება', 'Post')),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
