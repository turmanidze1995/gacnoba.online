import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../config.dart';
import '../utils.dart';

/// Unread count shown as a badge on the bottom navigation.
final ValueNotifier<int> notificationBadge = ValueNotifier<int>(0);

/// All site notifications (likes, reactions, comments, follows, friend requests...).
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> _items = [];
  List<Map<String, dynamic>> _requests = [];
  bool _loading = true;
  String? _error;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  List<Map<String, dynamic>> _maps(dynamic l) =>
      l is List ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];

  Future<void> _load({bool silent = false}) async {
    try {
      final res = await Api.getNotifications();
      final n = _maps(res['notifications']);
      final r = _maps(res['friend_requests']);
      if (!mounted) return;
      setState(() {
        _items = n;
        _requests = r;
        _loading = false;
        _error = null;
      });
      notificationBadge.value =
          n.where((e) => str(e['seen']) == '0').length + r.length;
    } on ApiException catch (e) {
      if (!silent && mounted) {
        setState(() {
          _loading = false;
          _error = e.message;
        });
      }
    } catch (e) {
      if (!silent && mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  Map<String, dynamic> _who(Map<String, dynamic> n) {
    final u = n['notifier'];
    return u is Map ? Map<String, dynamic>.from(u) : n;
  }

  String _text(BuildContext context, Map<String, dynamic> n) {
    for (final k in const ['type_text', 'text']) {
      final v = cleanText(str(n[k])).trim();
      if (v.isNotEmpty) return v;
    }
    final t = str(n['type']);
    switch (t) {
      case 'following':
        return t2(context, 'გამოგყვათ', 'started following you');
      case 'liked_post':
      case 'reaction':
        return t2(context, 'რეაქცია დაუსვა თქვენს პოსტს', 'reacted to your post');
      case 'comment':
        return t2(context, 'დაგიკომენტარათ', 'commented on your post');
      case 'visited_profile':
        return t2(context, 'ეწვია თქვენს პროფილს', 'visited your profile');
      default:
        return t.replaceAll('_', ' ');
    }
  }

  Future<void> _open(Map<String, dynamic> n) async {
    var url = str(n['url']);
    if (url.isEmpty) {
      final u = _who(n);
      final un = str(u['username']);
      if (un.isEmpty) return;
      url = un;
    }
    if (!url.startsWith('http')) {
      url = '${Config.siteUrl}/${url.startsWith('/') ? url.substring(1) : url}';
    }
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Widget _tile(Map<String, dynamic> n, {bool request = false}) {
    final u = _who(n);
    final unseen = request || str(n['seen']) == '0';
    final scheme = Theme.of(context).colorScheme;
    final text = request ? t2(context, 'გამოგიგზავნათ მეგობრობის მოთხოვნა', 'sent you a friend request') : _text(context, n);
    return Container(
      color: unseen ? scheme.primary.withAlpha(25) : null,
      child: ListTile(
        leading: Avatar(url: str(u['avatar']), name: displayName(u)),
        title: Text.rich(TextSpan(children: [
          TextSpan(text: displayName(u), style: const TextStyle(fontWeight: FontWeight.bold)),
          TextSpan(text: ' $text'),
        ]), maxLines: 3, overflow: TextOverflow.ellipsis),
        subtitle: Text(str(n['time_text_string']).isNotEmpty
            ? str(n['time_text_string'])
            : str(n['time_text'])),
        trailing: unseen ? const CircleAvatar(radius: 5, backgroundColor: Color(0xFF2D88FF)) : null,
        onTap: () => _open(request ? {'url': str(u['username'])} : n),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'შეტყობინებები', 'Notifications'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (_error != null && _items.isEmpty && _requests.isEmpty)
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      FilledButton(onPressed: _load, child: Text(t2(context, 'თავიდან ცდა', 'Retry'))),
                    ]),
                  ),
                )
              : (_items.isEmpty && _requests.isEmpty)
                  ? Center(child: Text(t2(context, 'შეტყობინებები ჯერ არ არის', 'No notifications yet')))
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView(children: [
                        if (_requests.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                            child: Text(t2(context, 'მეგობრობის მოთხოვნები', 'Friend requests'),
                                style: Theme.of(context).textTheme.titleSmall),
                          ),
                        for (final r in _requests) _tile(r, request: true),
                        if (_requests.isNotEmpty && _items.isNotEmpty) const Divider(),
                        for (final n in _items) _tile(n),
                      ]),
                    ),
    );
  }
}
