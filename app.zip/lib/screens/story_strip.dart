import 'dart:async';
import 'package:flutter/material.dart';
import '../api.dart';
import '../utils.dart';
import 'stories_screen.dart';

/// Horizontal row of story cards (like Messenger): "create story", your own
/// story and the stories of everybody else. Loads and refreshes itself.
class StoryStrip extends StatefulWidget {
  final double height;
  final double cardWidth;
  const StoryStrip({super.key, this.height = 210, this.cardWidth = 112});
  @override
  State<StoryStrip> createState() => _StoryStripState();
}

class _StoryStripState extends State<StoryStrip> {
  List<Map<String, dynamic>> _stories = [];
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final s = await Api.getStoryUsers();
      if (mounted) setState(() => _stories = s);
    } catch (_) {}
  }

  List<Map<String, dynamic>> _storiesOf(Map<String, dynamic> u) {
    final l = u['stories'];
    if (l is! List) return [];
    return l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Widget _card({
    required String bg,
    required String avatar,
    required String name,
    required VoidCallback onTap,
    bool plus = false,
    bool ring = false,
  }) {
    final primary = Theme.of(context).colorScheme.primary;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: widget.cardWidth,
        margin: const EdgeInsets.only(right: 8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Stack(fit: StackFit.expand, children: [
            bg.isNotEmpty
                ? Image.network(bg,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade400))
                : Container(color: Colors.grey.shade400),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black54],
                  stops: [0.55, 1],
                ),
              ),
            ),
            if (plus)
              Center(
                child: CircleAvatar(
                  radius: 18,
                  backgroundColor: primary,
                  child: const Icon(Icons.add, color: Colors.white),
                ),
              )
            else
              Positioned(
                left: 8,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: ring ? primary : Colors.white, width: 2.5),
                  ),
                  child: Avatar(url: avatar, name: name, radius: 14),
                ),
              ),
            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: Text(name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _open(Map<String, dynamic> u, List<Map<String, dynamic>> l) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => StoryViewerScreen(user: u, stories: l)));
    _load();
  }

  Widget _storyCard(Map<String, dynamic> u, List<Map<String, dynamic>> l, {bool you = false}) {
    final m = storyMedia(l.first, str(u['avatar']));
    final bg = (m != null && m['video'] != true) ? str(m['url']) : '';
    final unseen = l.any((s) => str(s['is_viewed']) == '0' || s['is_viewed'] == false);
    return _card(
      bg: bg,
      avatar: str(u['avatar']),
      name: you ? t2(context, 'შენი სთორი', 'Your story') : displayName(u),
      ring: you || unseen,
      onTap: () => _open(u, l),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mine = _stories.where((u) => str(u['user_id']) == Api.userId).toList();
    final others = _stories.where((u) => str(u['user_id']) != Api.userId).toList();
    final cards = <Widget>[
      _card(
        bg: str(Api.me['avatar']),
        avatar: '',
        name: t2(context, 'სთორის დამატება', 'Create story'),
        plus: true,
        onTap: () async {
          await Navigator.of(context)
              .push(MaterialPageRoute<void>(builder: (_) => const StoriesScreen()));
          _load();
        },
      ),
    ];
    if (mine.isNotEmpty) {
      final l = _storiesOf(mine.first);
      if (l.isNotEmpty) cards.add(_storyCard(mine.first, l, you: true));
    }
    for (final u in others) {
      final l = _storiesOf(u);
      if (l.isNotEmpty) cards.add(_storyCard(u, l));
    }
    return SizedBox(
      height: widget.height,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
        children: cards,
      ),
    );
  }
}
