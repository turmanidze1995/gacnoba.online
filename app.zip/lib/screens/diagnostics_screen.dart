import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import '../api.dart';
import '../config.dart';
import '../i18n.dart';
import '../push.dart';
import '../utils.dart';

class _Row {
  final String status; // ok | bad | warn
  final String title;
  final String detail;
  const _Row(this.status, this.title, this.detail);
}

/// Shows what is missing for notifications and calls (App + site settings).
class DiagnosticsScreen extends StatefulWidget {
  const DiagnosticsScreen({super.key});
  @override
  State<DiagnosticsScreen> createState() => _DiagnosticsScreenState();
}

class _DiagnosticsScreenState extends State<DiagnosticsScreen> {
  List<_Row> _rows = [];
  bool _busy = true;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    setState(() => _busy = true);
    final rows = <_Row>[];

    // ---- app side ----
    final ready = Push.ready;
    rows.add(_Row(ready ? 'ok' : 'bad', 'OneSignal in the app',
        ready ? 'Started (App ID is set)' : 'App ID is not set in the app'));
    var permission = false;
    try {
      permission = OneSignal.Notifications.permission;
    } catch (_) {}
    rows.add(_Row(permission ? 'ok' : 'bad', 'Notification permission',
        permission ? 'Allowed' : 'Not allowed: enable notifications for the app in Android settings'));
    final pid = await Push.playerId();
    rows.add(_Row(
        pid != null ? 'ok' : 'bad',
        'Device id in OneSignal',
        pid != null
            ? '${pid.substring(0, pid.length < 8 ? pid.length : 8)}... (created)'
            : 'No id: OneSignal could not register this phone (check Firebase/FCM setup in OneSignal)'));
    final registered = await Api.registeredPush();
    final regOk = pid != null && registered == pid;
    rows.add(_Row(regOk ? 'ok' : 'warn', 'Phone registered on the site',
        regOk ? 'Yes' : 'Not yet: log out and log in again'));

    // ---- site side ----
    Map<String, dynamic> cfg = {};
    try {
      cfg = await Api.getSiteConfig();
    } catch (e) {
      rows.add(_Row('bad', 'Site settings', 'Could not read site settings: $e'));
    }
    if (cfg.isNotEmpty) {
      rows.add(_Row(str(cfg['push']) == '1' ? 'ok' : 'bad', 'Site: push notifications',
          str(cfg['push']) == '1' ? 'On' : 'Off in admin-cp'));
      final msgPush = str(cfg['android_push_messages']);
      rows.add(_Row(msgPush == '1' ? 'ok' : 'bad', 'Site: Android messenger push',
          msgPush == '1' ? 'On' : 'Off in admin-cp (Android messenger push)'));
      final siteAppId = str(cfg['android_m_push_id']);
      final idOk = siteAppId == Config.oneSignalAppId;
      rows.add(_Row(
          siteAppId.isEmpty ? 'bad' : (idOk ? 'ok' : 'warn'),
          'Site: Messenger OneSignal App ID',
          siteAppId.isEmpty
              ? 'Empty: fill the "Android Messenger" section in admin-cp'
              : (idOk ? 'Matches the app' : 'Different from the app (${siteAppId.substring(0, siteAppId.length < 8 ? siteAppId.length : 8)}...)')));
      final key = str(cfg['android_m_push_key']);
      if (key.isEmpty) {
        rows.add(const _Row('bad', 'Site: Messenger REST API key', 'Empty'));
      } else if (key.startsWith('os_v2_org_')) {
        rows.add(const _Row('bad', 'Site: Messenger REST API key',
            'Organization key (os_v2_org_...). Create an APP key in OneSignal > Settings > Keys & IDs'));
      } else if (key.length < 40) {
        rows.add(_Row('bad', 'Site: Messenger REST API key',
            'Too short (${key.length} chars): this looks like a Key ID, not the key itself'));
      } else {
        rows.add(_Row('ok', 'Site: Messenger REST API key',
            'Set (${key.substring(0, 10)}...)'));
      }

      // ---- calls ----
      final flags = <String>[];
      var twilioOn = false;
      cfg.forEach((k, v) {
        final key = k.toLowerCase();
        final val = str(v);
        final isCallKey = key.contains('twilio') ||
            key.contains('agora') ||
            key == 'video_chat' ||
            key == 'audio_chat';
        final secret = key.contains('secret') ||
            key.contains('certificate') ||
            key.contains('sid') ||
            key.contains('token');
        if (isCallKey && !secret && (val == '0' || val == '1')) {
          flags.add('$k=$val');
          if (key.contains('twilio') && val == '1') twilioOn = true;
        }
      });
      rows.add(_Row(twilioOn ? 'bad' : 'ok', 'Site: call provider',
          twilioOn ? 'Twilio calls are ON, so Agora is off. Turn Twilio off in admin-cp.' : 'Twilio is not enabled'));
      final agoraId = str(cfg['agora_chat_app_id']);
      rows.add(_Row(agoraId.isEmpty ? 'bad' : 'ok', 'Site: Agora App ID',
          agoraId.isEmpty ? 'Empty: fill Agora App ID in admin-cp' : 'Set'));
      rows.add(_Row(str(cfg['agora_chat_app_certificate']).isEmpty ? 'warn' : 'ok',
          'Site: Agora certificate',
          str(cfg['agora_chat_app_certificate']).isEmpty ? 'Empty (only OK if your Agora project has no certificate)' : 'Set'));
      if (flags.isNotEmpty) {
        rows.add(_Row('warn', 'Call settings (raw)', flags.join(', ')));
      }
    }

    if (mounted) {
      setState(() {
        _rows = rows;
        _busy = false;
      });
    }
  }

  /// Sends a small photo to gacnoba_uploadtest.php (site root) and shows what the server received.
  Future<void> _uploadTest() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1600, maxHeight: 1600);
    if (x == null || !mounted) return;
    String out;
    final sw = Stopwatch()..start();
    try {
      final r = await Api.upload('', {'user_id': Api.userId ?? ''}, 'avatar', x.path,
          absolute: Uri.parse('${Config.siteUrl}/gacnoba_uploadtest.php'));
      out = const JsonEncoder.withIndent('  ').convert(r);
    } catch (e) {
      out = '$e\n\n${Api.lastUploadResponse}';
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Upload test (${sw.elapsedMilliseconds} ms)'),
        content: SingleChildScrollView(child: SelectableText(out, style: const TextStyle(fontSize: 12))),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  IconData _icon(String s) =>
      s == 'ok' ? Icons.check_circle : (s == 'bad' ? Icons.cancel : Icons.warning_amber);
  Color _color(String s) =>
      s == 'ok' ? Colors.green : (s == 'bad' ? Colors.red : Colors.orange);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('diagnostics')),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _run)],
      ),
      body: _busy
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                ListTile(
                  leading: const Icon(Icons.cloud_upload_outlined),
                  title: const Text('Upload test'),
                  subtitle: const Text('Sends a photo to gacnoba_uploadtest.php and shows what the site received'),
                  onTap: _uploadTest,
                ),
                for (final r in _rows)
                  ListTile(
                    leading: Icon(_icon(r.status), color: _color(r.status)),
                    title: Text(r.title),
                    subtitle: Text(r.detail),
                  ),
              ],
            ),
    );
  }
}
