import 'package:flutter/material.dart';
import '../api.dart';
import '../i18n.dart';
import '../utils.dart';
import 'user_picker_screen.dart';

class NewGroupScreen extends StatefulWidget {
  /// Members that are already selected when the screen opens.
  final List<Map<String, dynamic>> initial;
  const NewGroupScreen({super.key, this.initial = const []});
  @override
  State<NewGroupScreen> createState() => _NewGroupScreenState();
}

class _NewGroupScreenState extends State<NewGroupScreen> {
  final _name = TextEditingController();
  List<Map<String, dynamic>> _members = [];
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _members = List<Map<String, dynamic>>.of(widget.initial);
  }

  Future<void> _pick() async {
    final res = await Navigator.of(context).push<List<Map<String, dynamic>>>(
        MaterialPageRoute(builder: (_) => UserPickerScreen(title: context.tr('select_members'))));
    if (res == null) return;
    final ids = res.map((m) => str(m['user_id'])).toSet();
    setState(() => _members = [
          ...widget.initial.where((m) => !ids.contains(str(m['user_id']))),
          ...res,
        ]);
  }

  Future<void> _create() async {
    final name = _name.text.trim();
    if (name.length < 4 || name.length > 25) {
      setState(() => _error = '${context.tr('group_name')}: 4-25');
      return;
    }
    if (_members.isEmpty) {
      setState(() => _error = context.tr('select_members'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await Api.groupCreate(name, _members.map((m) => str(m['user_id'])).toList());
      if (mounted) Navigator.of(context).pop();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('new_group'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _name,
            maxLength: 25,
            decoration: InputDecoration(
                labelText: context.tr('group_name'), border: const OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _pick,
            icon: const Icon(Icons.group_add),
            label: Text('${context.tr('select_members')} (${_members.length})'),
          ),
          for (final m in _members)
            ListTile(
              leading: Avatar(url: str(m['avatar']), name: str(m['name'])),
              title: Text(str(m['name'])),
            ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          SizedBox(
            height: 48,
            child: FilledButton(
              onPressed: _busy ? null : _create,
              child: _busy
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(context.tr('create')),
            ),
          ),
        ],
      ),
    );
  }
}
