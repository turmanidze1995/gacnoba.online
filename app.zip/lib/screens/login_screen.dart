import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../api.dart';
import '../config.dart';
import '../i18n.dart';
import '../lang_picker.dart';
import '../push.dart';
import 'chats_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  String? _error;

  void _goHome() {
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const ChatsScreen()));
  }

  Future<void> _login() async {
    if (_user.text.trim().isEmpty || _pass.text.isEmpty) {
      setState(() => _error = context.tr('enter_credentials'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final pid = await Push.playerId();
      await Api.login(_user.text.trim(), _pass.text, pid);
      if (!mounted) return;
      _goHome();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Connection error: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _google() async {
    if (Config.googleWebClientId.startsWith('PASTE')) {
      setState(() => _error = 'Google sign-in is not configured yet (googleWebClientId).');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final gsi = GoogleSignIn(
        scopes: ['email', 'profile'],
        serverClientId: Config.googleWebClientId,
      );
      await gsi.signOut();
      final account = await gsi.signIn();
      if (account == null) return; // cancelled by the user
      final auth = await account.authentication;
      final idToken = auth.idToken;
      if (idToken == null || idToken.isEmpty) {
        throw ApiException('Google did not return an ID token');
      }
      final pid = await Push.playerId();
      await Api.googleLogin(idToken, pid);
      if (!mounted) return;
      _goHome();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = '${context.tr('google_failed')}: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: AlignmentDirectional.centerEnd,
              child: IconButton(
                icon: const Icon(Icons.language),
                tooltip: context.tr('language'),
                onPressed: () => showLanguagePicker(context),
              ),
            ),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset('assets/logo.gif', width: 300),
                      const SizedBox(height: 28),
                      TextField(
                        controller: _user,
                        decoration: InputDecoration(
                            labelText: context.tr('username_email'),
                            border: const OutlineInputBorder()),
                        autocorrect: false,
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _pass,
                        obscureText: true,
                        decoration: InputDecoration(
                            labelText: context.tr('password'),
                            border: const OutlineInputBorder()),
                        onSubmitted: (_) => _login(),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 12),
                        Text(_error!, style: const TextStyle(color: Colors.red)),
                      ],
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: FilledButton(
                          onPressed: _busy ? null : _login,
                          child: _busy
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2))
                              : Text(context.tr('login')),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(context.tr('or'), style: const TextStyle(color: Colors.black54)),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: OutlinedButton(
                          onPressed: _busy ? null : _google,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text('G',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 22,
                                      color: Color(0xFF4285F4))),
                              const SizedBox(width: 10),
                              Text(context.tr('google_login')),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        alignment: WrapAlignment.center,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Text(context.tr('no_account')),
                          TextButton(
                            onPressed: _busy
                                ? null
                                : () => Navigator.of(context).push(MaterialPageRoute(
                                    builder: (_) => const RegisterScreen())),
                            child: Text(context.tr('register')),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
