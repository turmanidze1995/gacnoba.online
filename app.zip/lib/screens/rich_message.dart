import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

final RegExp _urlRe = RegExp(r'((https?://|www\.)[^\s<>"]+)', caseSensitive: false);

Uri? _toUri(String raw) {
  var u = raw;
  while (u.isNotEmpty && '.,;:!?)]}'.contains(u[u.length - 1])) {
    u = u.substring(0, u.length - 1);
  }
  if (u.toLowerCase().startsWith('www.')) u = 'https://$u';
  return Uri.tryParse(u);
}

/// First link found in a text (or null).
String? firstLink(String text) {
  final m = _urlRe.firstMatch(text);
  if (m == null) return null;
  return _toUri(m.group(0)!)?.toString();
}

/// YouTube video id of a link (youtube.com/watch, youtu.be, shorts, embed, live) or null.
String? youtubeId(String url) {
  final u = Uri.tryParse(url);
  if (u == null) return null;
  final host = u.host.toLowerCase().replaceFirst('www.', '').replaceFirst('m.', '');
  String? id;
  if (host == 'youtu.be') {
    id = u.pathSegments.isNotEmpty ? u.pathSegments.first : null;
  } else if (host == 'youtube.com' || host == 'music.youtube.com') {
    if (u.path == '/watch') {
      id = u.queryParameters['v'];
    } else if (u.pathSegments.length >= 2 &&
        const ['shorts', 'embed', 'live', 'v'].contains(u.pathSegments.first)) {
      id = u.pathSegments[1];
    }
  }
  if (id == null || !RegExp(r'^[A-Za-z0-9_-]{6,20}$').hasMatch(id)) return null;
  return id;
}

/// True for TikTok video links (tiktok.com/@user/video/ID, vm.tiktok.com/XXXX, tiktok.com/t/XXXX).
bool isTiktokUrl(String url) {
  final u = Uri.tryParse(url);
  if (u == null) return false;
  final host = u.host.toLowerCase();
  if (host != 'tiktok.com' && !host.endsWith('.tiktok.com')) return false;
  if (u.path.contains('/video/')) return true;
  if (host == 'vm.tiktok.com' || host == 'vt.tiktok.com') return u.path.length > 1;
  return u.path.startsWith('/t/');
}

final Map<String, String?> _tiktokCache = {};

/// Video id of a TikTok link. Short links are followed to the real address.
Future<String?> tiktokId(String url) async {
  if (_tiktokCache.containsKey(url)) return _tiktokCache[url];
  final idRe = RegExp(r'/video/(\d+)');
  var m = idRe.firstMatch(url);
  if (m != null) return _tiktokCache[url] = m.group(1);
  var cur = url;
  for (var i = 0; i < 5; i++) {
    final client = http.Client();
    try {
      final req = http.Request('GET', Uri.parse(cur))
        ..followRedirects = false
        ..headers['User-Agent'] =
            'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';
      final r = await client.send(req).timeout(const Duration(seconds: 10));
      await r.stream.drain<void>();
      final loc = r.headers['location'];
      if (loc == null || loc.isEmpty) break;
      cur = Uri.parse(cur).resolve(loc).toString();
      m = idRe.firstMatch(cur);
      if (m != null) return _tiktokCache[url] = m.group(1);
    } catch (_) {
      break;
    } finally {
      client.close();
    }
  }
  return _tiktokCache[url] = null;
}

/// A song message: "🎵 Artist - Title" + a direct link to the audio file.
class SongInfo {
  final String url;
  final String title;
  final String rest;
  SongInfo(this.url, this.title, this.rest);
}

SongInfo? parseSong(String text) {
  final link = firstLink(text);
  if (link == null || !_isAudioLink(link)) return null;
  final m = _urlRe.firstMatch(text)!;
  final without = (text.substring(0, m.start) + text.substring(m.end)).trim();
  final lines = without.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  var title = lines.isNotEmpty ? lines.first : '';
  title = title.replaceFirst('🎵', '').trim();
  final rest = lines.length > 1 ? lines.sublist(1).join('\n') : '';
  return SongInfo(link, title, rest);
}

bool _isAudioLink(String url) {
  final u = url.toLowerCase().split('?').first;
  return u.endsWith('.mp3') ||
      u.endsWith('.m4a') ||
      u.endsWith('.aac') ||
      u.endsWith('.ogg') ||
      u.endsWith('.opus') ||
      u.endsWith('.wav');
}

/// Text where every link can be tapped (opens in the browser / the right app).
class LinkText extends StatefulWidget {
  final String text;
  final TextStyle? style;
  const LinkText(this.text, {super.key, this.style});
  @override
  State<LinkText> createState() => _LinkTextState();
}

class _LinkTextState extends State<LinkText> {
  final List<TapGestureRecognizer> _rec = [];

  void _free() {
    for (final r in _rec) {
      r.dispose();
    }
    _rec.clear();
  }

  @override
  void dispose() {
    _free();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _free();
    final base = widget.style ?? DefaultTextStyle.of(context).style;
    final spans = <InlineSpan>[];
    var last = 0;
    for (final m in _urlRe.allMatches(widget.text)) {
      if (m.start > last) spans.add(TextSpan(text: widget.text.substring(last, m.start)));
      var raw = m.group(0)!;
      final uri = _toUri(raw);
      var shown = raw;
      var tail = '';
      while (shown.isNotEmpty && '.,;:!?)]}'.contains(shown[shown.length - 1])) {
        tail = shown[shown.length - 1] + tail;
        shown = shown.substring(0, shown.length - 1);
      }
      if (uri == null) {
        spans.add(TextSpan(text: raw));
      } else {
        final r = TapGestureRecognizer()
          ..onTap = () => launchUrl(uri, mode: LaunchMode.externalApplication);
        _rec.add(r);
        spans.add(TextSpan(
            text: shown,
            recognizer: r,
            style: base.copyWith(
                decoration: TextDecoration.underline,
                color: base.color == null ? Colors.blue : base.color!.withAlpha(255))));
        if (tail.isNotEmpty) spans.add(TextSpan(text: tail));
      }
      last = m.end;
    }
    if (last < widget.text.length) spans.add(TextSpan(text: widget.text.substring(last)));
    return Text.rich(TextSpan(style: base, children: spans));
  }
}

/// A small web view inside a message bubble (video player, YouTube, TikTok, map).
class _MiniWeb extends StatefulWidget {
  final String? url;
  final String? html;
  final String? baseUrl;
  final List<String> allow;
  final double width;
  final double height;
  const _MiniWeb(
      {this.url,
      this.html,
      this.baseUrl,
      this.allow = const [],
      required this.width,
      required this.height});
  @override
  State<_MiniWeb> createState() => _MiniWebState();
}

class _MiniWebState extends State<_MiniWeb> {
  late final WebViewController _c;

  bool _allowed(String u) {
    if (u.startsWith('about:') || u.startsWith('data:')) return true;
    for (final a in widget.allow) {
      if (u.startsWith(a)) return true;
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(onNavigationRequest: (req) {
        // keep the player inside the bubble: other pages open in the browser
        if (!req.isMainFrame || widget.allow.isEmpty || _allowed(req.url)) {
          return NavigationDecision.navigate;
        }
        final uri = Uri.tryParse(req.url);
        if (uri != null) launchUrl(uri, mode: LaunchMode.externalApplication);
        return NavigationDecision.prevent;
      }));
    if (widget.html != null) {
      _c.loadHtmlString(widget.html!, baseUrl: widget.baseUrl);
    } else if (widget.url != null) {
      _c.loadRequest(Uri.parse(widget.url!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: SizedBox(
          width: widget.width,
          height: widget.height,
          child: WebViewWidget(controller: _c)),
    );
  }
}

/// Video that plays right inside the message.
class InlineVideo extends StatelessWidget {
  final String url;
  const InlineVideo(this.url, {super.key});
  @override
  Widget build(BuildContext context) {
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(200.0, 320.0);
    final safe = url.replaceAll('"', '%22');
    final html = '<html><head><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<style>html,body{margin:0;background:#000;height:100%}video{width:100%;height:100%;object-fit:contain}</style>'
        '</head><body><video src="$safe" controls playsinline preload="metadata"></video></body></html>';
    return _MiniWeb(html: html, width: w, height: w * 0.75);
  }
}

/// YouTube video that plays inside the message. The player is an iframe that
/// fills the whole box (the plain embed address showed a black bar on the side).
class YoutubeEmbed extends StatelessWidget {
  final String id;
  const YoutubeEmbed(this.id, {super.key});
  @override
  Widget build(BuildContext context) {
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(220.0, 340.0);
    final html = '<!doctype html><html><head>'
        '<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">'
        '<style>html,body{margin:0;padding:0;width:100%;height:100%;background:#000;overflow:hidden}'
        'iframe{position:absolute;left:0;top:0;width:100%;height:100%;border:0}</style></head><body>'
        '<iframe src="https://www.youtube.com/embed/$id?playsinline=1&rel=0&modestbranding=1" '
        'allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>'
        '</body></html>';
    return _MiniWeb(
        html: html,
        baseUrl: 'https://www.youtube.com',
        allow: const ['https://www.youtube.com/embed', 'https://www.youtube.com/'],
        width: w,
        height: w * 9 / 16);
  }
}

/// TikTok video that plays inside the message (the link stays under it).
class TiktokEmbed extends StatefulWidget {
  final String url;
  const TiktokEmbed(this.url, {super.key});
  @override
  State<TiktokEmbed> createState() => _TiktokEmbedState();
}

class _TiktokEmbedState extends State<TiktokEmbed> {
  late final Future<String?> _id = tiktokId(widget.url);

  @override
  Widget build(BuildContext context) {
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(250.0, 325.0);
    final h = w * 1.75;
    return FutureBuilder<String?>(
      future: _id,
      builder: (ctx, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return SizedBox(
              width: w,
              height: 60,
              child: const Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))));
        }
        final id = snap.data;
        if (id == null) return const SizedBox.shrink();
        return _MiniWeb(
            url: 'https://www.tiktok.com/embed/v2/$id',
            allow: const ['https://www.tiktok.com/embed'],
            width: w,
            height: h);
      },
    );
  }
}

/// Player for a song message: play / pause, progress and time.
class SongPlayer extends StatefulWidget {
  final String url;
  final String title;
  final Color color;
  const SongPlayer(this.url, this.title, {super.key, required this.color});
  @override
  State<SongPlayer> createState() => _SongPlayerState();
}

class _SongPlayerState extends State<SongPlayer> {
  static _SongPlayerState? _active;
  AudioPlayer? _p;
  final List<StreamSubscription<dynamic>> _subs = [];
  bool _playing = false;
  bool _loading = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;

  AudioPlayer _ensure() {
    var p = _p;
    if (p != null) return p;
    p = AudioPlayer();
    _p = p;
    _subs.add(p.onPlayerStateChanged.listen((s) {
      if (!mounted) return;
      setState(() {
        _playing = s == PlayerState.playing;
        if (s == PlayerState.playing) _loading = false;
      });
    }));
    _subs.add(p.onPositionChanged.listen((d) {
      if (mounted) setState(() => _pos = d);
    }));
    _subs.add(p.onDurationChanged.listen((d) {
      if (mounted) setState(() => _dur = d);
    }));
    _subs.add(p.onPlayerComplete.listen((_) {
      if (mounted) setState(() {
        _playing = false;
        _pos = Duration.zero;
      });
    }));
    return p;
  }

  Future<void> _toggle() async {
    try {
      final p = _ensure();
      if (_playing) {
        await p.pause();
        return;
      }
      if (_active != null && _active != this) await _active!._stop();
      _active = this;
      setState(() => _loading = true);
      if (_pos > Duration.zero && _pos < _dur) {
        await p.resume();
      } else {
        await p.play(UrlSource(widget.url));
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _stop() async {
    try {
      await _p?.pause();
    } catch (_) {}
  }

  @override
  void dispose() {
    if (_active == this) _active = null;
    for (final s in _subs) {
      s.cancel();
    }
    _p?.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.color;
    final total = _dur.inMilliseconds;
    final value = total > 0 ? (_pos.inMilliseconds / total).clamp(0.0, 1.0) : 0.0;
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 210, maxWidth: 280),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Icon(Icons.music_note, size: 18, color: c),
          const SizedBox(width: 4),
          Expanded(
            child: Text(widget.title.isEmpty ? 'MP3' : widget.title,
                maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: c, fontWeight: FontWeight.w600)),
          ),
        ]),
        const SizedBox(height: 4),
        Row(children: [
          InkWell(
            onTap: _toggle,
            borderRadius: BorderRadius.circular(20),
            child: _loading
                ? Padding(
                    padding: const EdgeInsets.all(7),
                    child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: c)))
                : Icon(_playing ? Icons.pause_circle_filled : Icons.play_circle_fill, size: 36, color: c),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                  trackHeight: 3,
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                  overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
                  activeTrackColor: c,
                  inactiveTrackColor: c.withAlpha(70),
                  thumbColor: c),
              child: Slider(
                value: value.toDouble(),
                onChanged: total > 0
                    ? (v) => _p?.seek(Duration(milliseconds: (v * total).toInt()))
                    : null,
              ),
            ),
          ),
          Text(_dur > Duration.zero ? _fmt(_playing || _pos > Duration.zero ? _pos : _dur) : '0:30',
              style: TextStyle(fontSize: 11, color: c)),
        ]),
      ]),
    );
  }
}

/// Normal map (OpenStreetMap) with a pin for a sent location. Tap opens the full map.
class MapPreview extends StatelessWidget {
  final String lat;
  final String lng;
  const MapPreview(this.lat, this.lng, {super.key});

  @override
  Widget build(BuildContext context) {
    final la = double.tryParse(lat) ?? 0;
    final lo = double.tryParse(lng) ?? 0;
    const d = 0.004;
    final bbox = '${lo - d},${la - d},${lo + d},${la + d}';
    final url = 'https://www.openstreetmap.org/export/embed.html?bbox=$bbox&layer=mapnik&marker=$la,$lng';
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(220.0, 320.0);
    return GestureDetector(
      onTap: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=$la,$lng'),
          mode: LaunchMode.externalApplication),
      child: Stack(children: [
        IgnorePointer(child: _MiniWeb(url: url, width: w, height: 150)),
        Positioned.fill(child: Container(color: Colors.transparent)),
      ]),
    );
  }
}
