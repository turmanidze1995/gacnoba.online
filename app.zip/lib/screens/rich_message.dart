import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

final RegExp _urlRe = RegExp(r'((https?://|www\.)[^\s<>"]+)', caseSensitive: false);

Uri? _toUri(String raw) {
  var u = raw;
  while (u.isNotEmpty && '.,;:!?)]}'.contains(u[u.length - 1])) {
    u = u.substring(0, u.length - 1);
  }
  if (u.toLowerCase().startsWith('www.')) u = 'https://$u';
  return Uri.tryParse(u);
}

/// First link found in a text (or null).
String? firstLink(String text) {
  final m = _urlRe.firstMatch(text);
  if (m == null) return null;
  return _toUri(m.group(0)!)?.toString();
}

/// YouTube video id of a link (youtube.com/watch, youtu.be, shorts, embed, live) or null.
String? youtubeId(String url) {
  final u = Uri.tryParse(url);
  if (u == null) return null;
  final host = u.host.toLowerCase().replaceFirst('www.', '').replaceFirst('m.', '');
  String? id;
  if (host == 'youtu.be') {
    id = u.pathSegments.isNotEmpty ? u.pathSegments.first : null;
  } else if (host == 'youtube.com' || host == 'music.youtube.com') {
    if (u.path == '/watch') {
      id = u.queryParameters['v'];
    } else if (u.pathSegments.length >= 2 &&
        const ['shorts', 'embed', 'live', 'v'].contains(u.pathSegments.first)) {
      id = u.pathSegments[1];
    }
  }
  if (id == null || !RegExp(r'^[A-Za-z0-9_-]{6,20}$').hasMatch(id)) return null;
  return id;
}

/// Text where every link can be tapped (opens in the browser / the right app).
class LinkText extends StatefulWidget {
  final String text;
  final TextStyle? style;
  const LinkText(this.text, {super.key, this.style});
  @override
  State<LinkText> createState() => _LinkTextState();
}

class _LinkTextState extends State<LinkText> {
  final List<TapGestureRecognizer> _rec = [];

  void _free() {
    for (final r in _rec) {
      r.dispose();
    }
    _rec.clear();
  }

  @override
  void dispose() {
    _free();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _free();
    final base = widget.style ?? DefaultTextStyle.of(context).style;
    final spans = <InlineSpan>[];
    var last = 0;
    for (final m in _urlRe.allMatches(widget.text)) {
      if (m.start > last) spans.add(TextSpan(text: widget.text.substring(last, m.start)));
      var raw = m.group(0)!;
      final uri = _toUri(raw);
      var shown = raw;
      var tail = '';
      while (shown.isNotEmpty && '.,;:!?)]}'.contains(shown[shown.length - 1])) {
        tail = shown[shown.length - 1] + tail;
        shown = shown.substring(0, shown.length - 1);
      }
      if (uri == null) {
        spans.add(TextSpan(text: raw));
      } else {
        final r = TapGestureRecognizer()
          ..onTap = () => launchUrl(uri, mode: LaunchMode.externalApplication);
        _rec.add(r);
        spans.add(TextSpan(
            text: shown,
            recognizer: r,
            style: base.copyWith(
                decoration: TextDecoration.underline,
                color: base.color == null ? Colors.blue : base.color!.withAlpha(255))));
        if (tail.isNotEmpty) spans.add(TextSpan(text: tail));
      }
      last = m.end;
    }
    if (last < widget.text.length) spans.add(TextSpan(text: widget.text.substring(last)));
    return Text.rich(TextSpan(style: base, children: spans));
  }
}

/// A small web view inside a message bubble (video player, YouTube, map).
class _MiniWeb extends StatefulWidget {
  final String? url;
  final String? html;
  final double width;
  final double height;
  const _MiniWeb({this.url, this.html, required this.width, required this.height});
  @override
  State<_MiniWeb> createState() => _MiniWebState();
}

class _MiniWebState extends State<_MiniWeb> {
  late final WebViewController _c;

  @override
  void initState() {
    super.initState();
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black);
    if (widget.html != null) {
      _c.loadHtmlString(widget.html!);
    } else if (widget.url != null) {
      _c.loadRequest(Uri.parse(widget.url!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: SizedBox(
          width: widget.width,
          height: widget.height,
          child: WebViewWidget(controller: _c)),
    );
  }
}

/// Video that plays right inside the message.
class InlineVideo extends StatelessWidget {
  final String url;
  const InlineVideo(this.url, {super.key});
  @override
  Widget build(BuildContext context) {
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(200.0, 320.0);
    final safe = url.replaceAll('"', '%22');
    final html = '<html><head><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<style>html,body{margin:0;background:#000;height:100%}video{width:100%;height:100%;object-fit:contain}</style>'
        '</head><body><video src="$safe" controls playsinline preload="metadata"></video></body></html>';
    return _MiniWeb(html: html, width: w, height: w * 0.75);
  }
}

/// YouTube video that plays inside the message.
class YoutubeEmbed extends StatelessWidget {
  final String id;
  const YoutubeEmbed(this.id, {super.key});
  @override
  Widget build(BuildContext context) {
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(220.0, 340.0);
    return _MiniWeb(
        url: 'https://www.youtube.com/embed/$id?playsinline=1&rel=0', width: w, height: w * 9 / 16);
  }
}

/// Normal map (OpenStreetMap) with a pin for a sent location. Tap opens the full map.
class MapPreview extends StatelessWidget {
  final String lat;
  final String lng;
  const MapPreview(this.lat, this.lng, {super.key});

  @override
  Widget build(BuildContext context) {
    final la = double.tryParse(lat) ?? 0;
    final lo = double.tryParse(lng) ?? 0;
    const d = 0.004;
    final bbox = '${lo - d},${la - d},${lo + d},${la + d}';
    final url = 'https://www.openstreetmap.org/export/embed.html?bbox=$bbox&layer=mapnik&marker=$la,$lng';
    final w = (MediaQuery.of(context).size.width * 0.7).clamp(220.0, 320.0);
    return GestureDetector(
      onTap: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=$la,$lng'),
          mode: LaunchMode.externalApplication),
      child: Stack(children: [
        IgnorePointer(child: _MiniWeb(url: url, width: w, height: 150)),
        Positioned.fill(child: Container(color: Colors.transparent)),
      ]),
    );
  }
}
