import 'package:flutter/material.dart';
import '../api.dart';
import '../i18n.dart';

/// Bottom sheet that searches Giphy (GIFs or stickers). Pops the chosen item
/// as {'send': url, 'id': giphyId}.
class GifSheet extends StatefulWidget {
  final bool stickers;
  const GifSheet({super.key, this.stickers = false});
  @override
  State<GifSheet> createState() => _GifSheetState();
}

class _GifSheetState extends State<GifSheet> {
  final _q = TextEditingController();
  List<Map<String, String>> _items = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _search('');
  }

  Future<void> _search(String q) async {
    setState(() => _busy = true);
    try {
      final items = await Api.searchGiphy(q, stickers: widget.stickers);
      if (mounted) setState(() => _items = items);
    } catch (_) {
      if (mounted) setState(() => _items = []);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.6,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10),
              child: TextField(
                controller: _q,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: context.tr(widget.stickers ? 'sticker' : 'search_gif'),
                  prefixIcon: const Icon(Icons.search),
                  border: const OutlineInputBorder(),
                  isDense: true,
                ),
                onSubmitted: _search,
              ),
            ),
            Expanded(
              child: _busy
                  ? const Center(child: CircularProgressIndicator())
                  : GridView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3, mainAxisSpacing: 4, crossAxisSpacing: 4),
                      itemCount: _items.length,
                      itemBuilder: (_, i) => InkWell(
                        onTap: () => Navigator.of(context).pop(<String, String>{
                          'send': _items[i]['send'] ?? '',
                          'id': _items[i]['id'] ?? '',
                        }),
                        child: Image.network(_items[i]['preview']!, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
