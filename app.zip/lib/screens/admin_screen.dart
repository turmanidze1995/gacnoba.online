import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../config.dart';
import '../utils.dart';
import 'chat_screen.dart';
import 'diagnostics_screen.dart';

/// Admin panel. Only shown to site administrators (Api.isAdmin); other users
/// never see the entry for it.
class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    if (!Api.isAdmin) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: Text(t2(context, 'წვდომა არ გაქვთ', 'No access'))),
      );
    }
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'საადმინო', 'Admin'))),
      body: ListView(children: [
        ListTile(
          leading: const Icon(Icons.people_alt_outlined),
          title: Text(t2(context, 'მომხმარებლები', 'Users')),
          subtitle: Text(t2(context, 'ყველა, ონლაინ სტატუსით', 'Everyone, with online status')),
          onTap: () => Navigator.of(context)
              .push(MaterialPageRoute<void>(builder: (_) => const AdminUsersScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.bug_report_outlined),
          title: Text(t2(context, 'დიაგნოსტიკა', 'Diagnostics')),
          subtitle: Text(t2(context, 'push და ზარების შემოწმება', 'Check push and calls')),
          onTap: () => Navigator.of(context)
              .push(MaterialPageRoute<void>(builder: (_) => const DiagnosticsScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.admin_panel_settings_outlined),
          title: Text(t2(context, 'საიტის admin-cp', 'Site admin-cp')),
          trailing: const Icon(Icons.open_in_new),
          onTap: () => launchUrl(Uri.parse('${Config.siteUrl}/admin-cp'),
              mode: LaunchMode.externalApplication),
        ),
      ]),
    );
  }
}

class AdminUsersScreen extends StatefulWidget {
  const AdminUsersScreen({super.key});
  @override
  State<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends State<AdminUsersScreen> {
  final _q = TextEditingController();
  List<Map<String, dynamic>> _users = [];
  int _online = 0;
  bool _loading = true;
  String? _error;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _maps(dynamic l) =>
      l is List ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];

  Future<void> _load() async {
    final q = _q.text.trim();
    try {
      final res = await Api.gacnobaPeople(q: q);
      if (!mounted) return;
      setState(() {
        _users = _maps(res['users']);
        _online = int.tryParse(str(res['online_count'])) ?? 0;
        _loading = false;
        _error = null;
      });
      return;
    } catch (_) {}
    try {
      final l = q.isEmpty ? <Map<String, dynamic>>[] : _maps(await Api.searchUsers(q));
      if (!mounted) return;
      setState(() {
        _users = l;
        _online = l.where((u) => str(u['lastseen_status']) == 'on').length;
        _loading = false;
        _error = q.isEmpty
            ? t2(context, 'სრული სიისთვის საიტზე უნდა იყოს gacnoba_people.php. ძებნა მუშაობს.',
                'The full list needs gacnoba_people.php on the site. Search works.')
            : null;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'მომხმარებლები', 'Users'))),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: _q,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: t2(context, 'ძებნა', 'Search'),
              border: const OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: (_) {
              _debounce?.cancel();
              _debounce = Timer(const Duration(milliseconds: 450), _load);
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Text('${t2(context, 'სულ', 'Total')}: ${_users.length}   '),
            const Icon(Icons.circle, color: Colors.green, size: 10),
            Text(' ${t2(context, 'ონლაინ', 'Online')}: $_online'),
          ]),
        ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(_error!, style: const TextStyle(color: Colors.orange)),
          ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: _users.length,
                  itemBuilder: (_, i) {
                    final u = _users[i];
                    final on = str(u['lastseen_status']) == 'on';
                    return ListTile(
                      leading: Avatar(url: str(u['avatar']), name: displayName(u)),
                      title: Text(displayName(u), maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('@${str(u['username'])}  ·  id ${str(u['user_id'])}'),
                      trailing: on ? const Icon(Icons.circle, color: Colors.green, size: 12) : null,
                      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                          builder: (_) => ChatScreen(
                              userId: str(u['user_id']),
                              name: displayName(u),
                              avatar: str(u['avatar'])))),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
