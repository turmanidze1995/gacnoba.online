import 'package:flutter/material.dart';
import '../call_native.dart';
import '../utils.dart';

/// Call ringtone (any system ringtone) and message notification sound.
class SoundsScreen extends StatefulWidget {
  const SoundsScreen({super.key});
  @override
  State<SoundsScreen> createState() => _SoundsScreenState();
}

class _SoundsScreenState extends State<SoundsScreen> {
  String _title = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    CallNative.stopPreview();
    super.dispose();
  }

  Future<void> _load() async {
    final r = await CallNative.getRingtone();
    if (mounted) setState(() => _title = r['title'] ?? '');
  }

  Future<void> _pick() async {
    await CallNative.stopPreview();
    final r = await CallNative.pickRingtone();
    if (r != null && mounted) setState(() => _title = r['title'] ?? '');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'ხმები და მელოდიები', 'Sounds and ringtones'))),
      body: ListView(children: [
        ListTile(
          leading: const Icon(Icons.ring_volume),
          title: Text(t2(context, 'ზარის მელოდია', 'Call ringtone')),
          subtitle: Text(_title.isEmpty ? t2(context, 'სისტემის ნაგულისხმევი', 'System default') : _title),
          onTap: _pick,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            OutlinedButton.icon(
              onPressed: CallNative.previewRingtone,
              icon: const Icon(Icons.play_arrow),
              label: Text(t2(context, 'მოსმენა', 'Play')),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: CallNative.stopPreview,
              icon: const Icon(Icons.stop),
              label: Text(t2(context, 'გაჩერება', 'Stop')),
            ),
            const SizedBox(width: 8),
            TextButton(
              onPressed: () async {
                await CallNative.resetRingtone();
                _load();
              },
              child: Text(t2(context, 'ნაგულისხმევი', 'Default')),
            ),
          ]),
        ),
        const Divider(height: 32),
        ListTile(
          leading: const Icon(Icons.notifications_active_outlined),
          title: Text(t2(context, 'შეტყობინების ხმა', 'Message sound')),
          subtitle: Text(t2(
              context,
              'გაიხსნება Android-ის პარამეტრები: აირჩიეთ არხი და მასში „ხმა“',
              'Opens Android settings: choose a channel and its "Sound"')),
          trailing: const Icon(Icons.open_in_new),
          onTap: CallNative.openNotificationSettings,
        ),
      ]),
    );
  }
}
