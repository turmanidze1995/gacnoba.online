import 'package:flutter/material.dart';
import '../i18n.dart';
import 'calls_screen.dart';
import 'chats_screen.dart';
import 'settings_screen.dart';
import 'notifications_screen.dart';
import 'people_screen.dart';
import '../utils.dart';

/// Main screen with the bottom navigation: chats, stories, calls, settings.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [
          ChatsScreen(),
          PeopleScreen(),
          CallsScreen(),
          NotificationsScreen(),
          SettingsScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          // Messenger look: soft grey pill behind the selected icon, blue icon
          indicatorColor: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF262626)
              : const Color(0xFFE7F3FF),
          iconTheme: WidgetStateProperty.resolveWith((st) => IconThemeData(
              color: st.contains(WidgetState.selected)
                  ? const Color(0xFF0084FF)
                  : Theme.of(context).colorScheme.onSurfaceVariant)),
          labelTextStyle: WidgetStateProperty.resolveWith((st) => TextStyle(
              fontSize: 12,
              fontWeight: st.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500,
              color: st.contains(WidgetState.selected)
                  ? const Color(0xFF0084FF)
                  : Theme.of(context).colorScheme.onSurfaceVariant)),
        ),
        child: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.chat_bubble_outline),
              selectedIcon: const Icon(Icons.chat_bubble),
              label: context.tr('chats')),
          NavigationDestination(
              icon: const Icon(Icons.people_outline),
              selectedIcon: const Icon(Icons.people),
              label: t2(context, 'ონლაინი', 'Online')),
          NavigationDestination(
              icon: const Icon(Icons.call_outlined),
              selectedIcon: const Icon(Icons.call),
              label: context.tr('calls')),
          NavigationDestination(
              icon: ValueListenableBuilder<int>(
                valueListenable: notificationBadge,
                builder: (_, n, __) => Badge(
                    isLabelVisible: n > 0,
                    label: Text('$n'),
                    child: const Icon(Icons.notifications_none)),
              ),
              selectedIcon: const Icon(Icons.notifications),
              label: t2(context, 'შეტყობ.', 'Alerts')),
          NavigationDestination(
              icon: const Icon(Icons.settings_outlined),
              selectedIcon: const Icon(Icons.settings),
              label: context.tr('settings')),
        ],
      ),
      ),
    );
  }
}
