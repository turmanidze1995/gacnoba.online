import 'dart:async';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../crypto.dart';
import '../utils.dart';
import 'call_screens.dart';

class ChatScreen extends StatefulWidget {
  final String userId;
  final String name;
  final String avatar;
  const ChatScreen({super.key, required this.userId, required this.name, this.avatar = ''});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final Map<int, Map<String, dynamic>> _byId = {};
  final _controller = TextEditingController();
  Timer? _timer;
  bool _loading = true;
  bool _sending = false;
  bool _fetching = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch(initial: true);
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _fetch());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _sorted {
    final ids = _byId.keys.toList()..sort();
    return ids.map((i) => _byId[i]!).toList();
  }

  Future<void> _fetch({bool initial = false}) async {
    if (_fetching) return;
    _fetching = true;
    try {
      String? after;
      if (!initial && _byId.isNotEmpty) {
        after = _byId.keys.reduce((a, b) => a > b ? a : b).toString();
      }
      final msgs = await Api.getMessages(widget.userId, afterId: after);
      for (final m in msgs) {
        if (m is! Map) continue;
        final id = int.tryParse(str(m['id']));
        if (id == null) continue;
        final mm = Map<String, dynamic>.from(m);
        mm['_text'] = cleanText(decryptText(m['text'], m['time']));
        _byId[id] = mm;
      }
      if (mounted) setState(() {
        _loading = false;
        _error = null;
      });
    } on ApiException catch (e) {
      if (mounted) setState(() {
        _loading = false;
        _error = e.message;
      });
    } catch (e) {
      if (mounted) setState(() {
        _loading = false;
        _error = e.toString();
      });
    } finally {
      _fetching = false;
    }
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      await Api.sendText(widget.userId, text);
      _controller.clear();
      await _fetch();
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _pickImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (x == null) return;
    setState(() => _sending = true);
    try {
      await Api.sendFile(widget.userId, x.path);
      await _fetch();
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _call(bool video) async {
    try {
      final res = await Api.agoraCreate(widget.userId, video ? 'video' : 'audio');
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => CallScreen(
                channel: str(res['room_name']),
                token: str(res['token']),
                video: video,
                peerName: widget.name,
                peerAvatar: widget.avatar,
                callId: str(res['id']),
                outgoing: true,
              )));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Widget _bubble(Map<String, dynamic> m) {
    final mine = str(m['from_id']) == Api.userId;
    final media = str(m['media']);
    final sticker = str(m['stickers']);
    final text = str(m['_text']);
    final scheme = Theme.of(context).colorScheme;
    final children = <Widget>[];
    if (sticker.isNotEmpty && isImageUrl(sticker)) {
      children.add(Image.network(sticker, width: 160, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)));
    }
    if (media.isNotEmpty) {
      if (isImageUrl(media)) {
        children.add(ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(media, width: 220,
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
        ));
      } else {
        children.add(InkWell(
          onTap: () => launchUrl(Uri.parse(media), mode: LaunchMode.externalApplication),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.attach_file, size: 18, color: mine ? Colors.white : null),
            const SizedBox(width: 4),
            Text('Open attachment',
                style: TextStyle(
                    decoration: TextDecoration.underline,
                    color: mine ? Colors.white : null)),
          ]),
        ));
      }
    }
    if (text.isNotEmpty) {
      children.add(Text(text, style: TextStyle(color: mine ? Colors.white : null)));
    }
    children.add(Text(str(m['time_text']),
        style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : Colors.black45)));
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: mine ? scheme.primary : scheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: children,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final msgs = _sorted;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          Avatar(url: widget.avatar, name: widget.name, radius: 16),
          const SizedBox(width: 10),
          Expanded(child: Text(widget.name, overflow: TextOverflow.ellipsis)),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.call), onPressed: () => _call(false)),
          IconButton(icon: const Icon(Icons.videocam), onPressed: () => _call(true)),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : (_error != null && msgs.isEmpty)
                  ? Center(child: Text(_error!))
                  : ListView.builder(
                      reverse: true,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: msgs.length,
                      itemBuilder: (_, i) => _bubble(msgs[msgs.length - 1 - i]),
                    ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.image), onPressed: _sending ? null : _pickImage),
              Expanded(
                child: TextField(
                  controller: _controller,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(
                    hintText: 'Message',
                    filled: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none),
                  ),
                ),
              ),
              IconButton(
                icon: _sending
                    ? const SizedBox(
                        width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.send),
                onPressed: _sending ? null : _send,
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
