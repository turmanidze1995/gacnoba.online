import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../config.dart';
import '../crypto.dart';
import '../emoji_data.dart';
import '../i18n.dart';
import '../utils.dart';
import 'call_screens.dart';
import 'gif_sheet.dart';

class ChatScreen extends StatefulWidget {
  final String userId;
  final String name;
  final String avatar;
  const ChatScreen({super.key, required this.userId, required this.name, this.avatar = ''});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final Map<int, Map<String, dynamic>> _byId = {};
  final TextEditingController _controller = TextEditingController();
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<PlayerState>? _subState;
  StreamSubscription<void>? _subDone;
  Timer? _timer;
  Timer? _typingStop;
  Timer? _recTimer;
  AudioRecorder? _rec;

  bool _loading = true;
  bool _sending = false;
  bool _fetching = false;
  bool _typing = false;
  bool _peerRecording = false;
  bool _emojiOpen = false;
  bool _recording = false;
  bool _hasMore = true;
  bool _loadingOlder = false;
  bool _isPlaying = false;
  int _recSeconds = 0;
  String? _error;
  String? _playingUrl;
  DateTime _lastTyping = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onTextChanged);
    _subState = _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _isPlaying = s == PlayerState.playing);
    });
    _subDone = _player.onPlayerComplete.listen((_) {
      if (mounted) {
        setState(() {
          _isPlaying = false;
          _playingUrl = null;
        });
      }
    });
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _fetch());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _typingStop?.cancel();
    _recTimer?.cancel();
    _subState?.cancel();
    _subDone?.cancel();
    _player.dispose();
    _rec?.dispose();
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _sorted {
    final ids = _byId.keys.toList()..sort();
    return ids.map((i) => _byId[i]!).toList();
  }

  Map<String, dynamic> _prepare(Map m) {
    final mm = Map<String, dynamic>.from(m);
    mm['_text'] = cleanText(decryptText(m['text'], m['time']));
    return mm;
  }

  Future<void> _fetch() async {
    if (_fetching) return;
    _fetching = true;
    try {
      final res = await Api.getMessagesRaw(widget.userId);
      final msgs = (res['messages'] as List?) ?? [];
      final fresh = <int, Map<String, dynamic>>{};
      for (final m in msgs) {
        if (m is! Map) continue;
        final id = int.tryParse(str(m['id']));
        if (id == null) continue;
        fresh[id] = _prepare(m);
      }
      if (fresh.isNotEmpty) {
        final minId = fresh.keys.reduce(math.min);
        // messages inside the fetched range that are gone were deleted
        _byId.removeWhere((id, _) => id >= minId && !fresh.containsKey(id));
        _byId.addAll(fresh);
      }
      final typing = str(res['typing']) == '1';
      final recording = (int.tryParse(str(res['is_recording'])) ?? 0) > 0;
      if (mounted) {
        setState(() {
          _loading = false;
          _error = null;
          _typing = typing;
          _peerRecording = recording;
        });
      }
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = e.message;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = e.toString();
        });
      }
    } finally {
      _fetching = false;
    }
  }

  Future<void> _loadOlder() async {
    if (_loadingOlder || _byId.isEmpty) return;
    setState(() => _loadingOlder = true);
    try {
      final minId = _byId.keys.reduce(math.min);
      final res = await Api.getMessagesRaw(widget.userId, beforeId: minId.toString());
      final msgs = (res['messages'] as List?) ?? [];
      var added = 0;
      for (final m in msgs) {
        if (m is! Map) continue;
        final id = int.tryParse(str(m['id']));
        if (id == null || _byId.containsKey(id)) continue;
        _byId[id] = _prepare(m);
        added++;
      }
      if (mounted) setState(() => _hasMore = added > 0);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loadingOlder = false);
    }
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  // ---------- typing indicator ----------
  void _onTextChanged() {
    if (mounted) setState(() {});
    final hasText = _controller.text.trim().isNotEmpty;
    final now = DateTime.now();
    if (hasText && now.difference(_lastTyping).inSeconds >= 3) {
      _lastTyping = now;
      Api.setTyping(widget.userId, 'typing').catchError((Object _) {});
    }
    _typingStop?.cancel();
    _typingStop = Timer(const Duration(seconds: 5), () {
      Api.setTyping(widget.userId, 'stop').catchError((Object _) {});
    });
  }

  // ---------- sending ----------
  Future<void> _run(Future<void> Function() action) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await action();
      await _fetch();
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    await _run(() async {
      await Api.sendText(widget.userId, text);
      _controller.clear();
      Api.setTyping(widget.userId, 'stop').catchError((Object _) {});
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    final x = await ImagePicker().pickImage(source: source, imageQuality: 85);
    if (x == null) return;
    await _run(() => Api.sendFile(widget.userId, x.path));
  }

  Future<void> _pickVideo() async {
    final x = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (x == null) return;
    await _run(() => Api.sendFile(widget.userId, x.path));
  }

  Future<void> _pickGif() async {
    final url = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const GifSheet(),
    );
    if (url == null || url.isEmpty) return;
    await _run(() => Api.sendGif(widget.userId, url));
  }

  void _attachMenu() {
    final gifEnabled = !Config.giphyApiKey.startsWith('PASTE');
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.photo),
            title: Text(ctx.tr('gallery')),
            onTap: () {
              Navigator.pop(ctx);
              _pickImage(ImageSource.gallery);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: Text(ctx.tr('camera')),
            onTap: () {
              Navigator.pop(ctx);
              _pickImage(ImageSource.camera);
            },
          ),
          ListTile(
            leading: const Icon(Icons.videocam),
            title: Text(ctx.tr('video')),
            onTap: () {
              Navigator.pop(ctx);
              _pickVideo();
            },
          ),
          if (gifEnabled)
            ListTile(
              leading: const Icon(Icons.gif_box),
              title: Text(ctx.tr('gif')),
              onTap: () {
                Navigator.pop(ctx);
                _pickGif();
              },
            ),
        ]),
      ),
    );
  }

  // ---------- voice messages ----------
  Future<void> _startRecording() async {
    try {
      final rec = AudioRecorder();
      if (!await rec.hasPermission()) {
        await rec.dispose();
        _snack(context.tr('permission_denied'));
        return;
      }
      final path =
          '${Directory.systemTemp.path}/voice_${DateTime.now().millisecondsSinceEpoch}.wav';
      await rec.start(
        const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );
      _rec = rec;
      if (!mounted) return;
      setState(() {
        _recording = true;
        _recSeconds = 0;
      });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSeconds++);
      });
      Api.setTyping(widget.userId, 'recording').catchError((Object _) {});
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _stopRecording({required bool send}) async {
    _recTimer?.cancel();
    final rec = _rec;
    _rec = null;
    String? path;
    try {
      path = await rec?.stop();
      await rec?.dispose();
    } catch (_) {}
    final seconds = _recSeconds;
    if (mounted) setState(() => _recording = false);
    Api.setTyping(widget.userId, 'stop').catchError((Object _) {});
    if (path == null) return;
    final file = File(path);
    if (send && seconds >= 1) {
      await _run(() => Api.sendFile(widget.userId, path!));
    }
    try {
      await file.delete();
    } catch (_) {}
  }

  Future<void> _togglePlay(String url) async {
    try {
      if (_playingUrl == url && _isPlaying) {
        await _player.pause();
        return;
      }
      if (_playingUrl == url) {
        await _player.resume();
        return;
      }
      await _player.stop();
      setState(() => _playingUrl = url);
      await _player.play(UrlSource(url));
    } catch (e) {
      _snack('$e');
    }
  }

  // ---------- message actions ----------
  void _messageMenu(Map<String, dynamic> m, bool mine) {
    final text = str(m['_text']);
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          if (text.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy),
              title: Text(ctx.tr('copy')),
              onTap: () {
                Clipboard.setData(ClipboardData(text: text));
                Navigator.pop(ctx);
                _snack(ctx.tr('done'));
              },
            ),
          if (mine)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: Text(ctx.tr('delete'), style: const TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _deleteMessage(int.tryParse(str(m['id'])));
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _deleteMessage(int? id) async {
    if (id == null) return;
    try {
      await Api.deleteMessage(id.toString());
      if (mounted) setState(() => _byId.remove(id));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<bool> _confirm(String message) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('delete'))),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _clearChat() async {
    if (!await _confirm(context.tr('clear_confirm'))) return;
    try {
      await Api.deleteConversation(widget.userId);
      if (mounted) setState(() => _byId.clear());
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _block(bool block) async {
    try {
      await Api.blockUser(widget.userId, block);
      _snack(context.tr(block ? 'user_blocked' : 'user_unblocked'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _call(bool video) async {
    try {
      final res = await Api.agoraCreate(widget.userId, video ? 'video' : 'audio');
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => CallScreen(
                channel: str(res['room_name']),
                token: str(res['token']),
                video: video,
                peerName: widget.name,
                peerAvatar: widget.avatar,
                callId: str(res['id']),
                outgoing: true,
              )));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  // ---------- emoji ----------
  void _insertEmoji(String e) {
    final text = _controller.text;
    final sel = _controller.selection;
    final start = sel.isValid && sel.start >= 0 ? sel.start : text.length;
    final end = sel.isValid && sel.end >= 0 ? sel.end : text.length;
    final newText = text.replaceRange(start, end, e);
    _controller.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: start + e.length),
    );
  }

  Widget _emojiPanel() {
    return SizedBox(
      height: 250,
      child: GridView.builder(
        padding: const EdgeInsets.all(6),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
        itemCount: kEmojis.length,
        itemBuilder: (_, i) => InkWell(
          onTap: () => _insertEmoji(kEmojis[i]),
          child: Center(child: Text(kEmojis[i], style: const TextStyle(fontSize: 26))),
        ),
      ),
    );
  }

  // ---------- bubbles ----------
  Widget _voiceTile(String url, bool mine) {
    final playing = _playingUrl == url && _isPlaying;
    final color = mine ? Colors.white : Colors.black87;
    return InkWell(
      onTap: () => _togglePlay(url),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill, size: 34, color: color),
        const SizedBox(width: 6),
        Icon(Icons.graphic_eq, color: color),
        const SizedBox(width: 6),
        Icon(Icons.mic, size: 16, color: color),
      ]),
    );
  }

  Widget _bubble(Map<String, dynamic> m) {
    final mine = str(m['from_id']) == Api.userId;
    final media = str(m['media']);
    final sticker = str(m['stickers']);
    final text = str(m['_text']);
    final lat = str(m['lat']);
    final lng = str(m['lng']);
    final seen = str(m['seen']).isNotEmpty && str(m['seen']) != '0';
    final scheme = Theme.of(context).colorScheme;
    final fg = mine ? Colors.white : null;
    final children = <Widget>[];

    if (sticker.isNotEmpty && isImageUrl(sticker.contains('.gif') ? sticker.split('?').first : sticker)) {
      children.add(ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(sticker, width: 200,
            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
      ));
    }
    if (media.isNotEmpty) {
      if (isImageUrl(media)) {
        children.add(GestureDetector(
          onTap: () => showDialog<void>(
            context: context,
            builder: (_) => Dialog(
              backgroundColor: Colors.black,
              insetPadding: EdgeInsets.zero,
              child: InteractiveViewer(child: Image.network(media)),
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(media, width: 220,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
          ),
        ));
      } else if (isAudioUrl(media)) {
        children.add(_voiceTile(media, mine));
      } else if (isVideoUrl(media)) {
        children.add(InkWell(
          onTap: () => launchUrl(Uri.parse(media), mode: LaunchMode.externalApplication),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.play_circle_fill, size: 34, color: fg),
            const SizedBox(width: 6),
            Text(context.tr('video'), style: TextStyle(color: fg)),
          ]),
        ));
      } else {
        children.add(InkWell(
          onTap: () => launchUrl(Uri.parse(media), mode: LaunchMode.externalApplication),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.attach_file, size: 18, color: fg),
            const SizedBox(width: 4),
            Text(context.tr('open_attachment'),
                style: TextStyle(decoration: TextDecoration.underline, color: fg)),
          ]),
        ));
      }
    }
    if (lat.isNotEmpty && lat != '0' && lng.isNotEmpty && lng != '0') {
      children.add(InkWell(
        onTap: () => launchUrl(Uri.parse('https://maps.google.com/?q=$lat,$lng'),
            mode: LaunchMode.externalApplication),
        child: Text('📍 $lat, $lng',
            style: TextStyle(decoration: TextDecoration.underline, color: fg)),
      ));
    }
    if (text.isNotEmpty) {
      children.add(Text(text, style: TextStyle(color: fg)));
    }
    children.add(Row(mainAxisSize: MainAxisSize.min, children: [
      Text(str(m['time_text']),
          style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : Colors.black45)),
      if (mine) ...[
        const SizedBox(width: 4),
        Icon(Icons.done_all, size: 14, color: seen ? Colors.lightBlueAccent : Colors.white54),
      ],
    ]));

    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _messageMenu(m, mine),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: mine ? scheme.primary : scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: children,
            ),
          ),
        ),
      ),
    );
  }

  // ---------- input bar ----------
  Widget _recordingBar() {
    final mm = (_recSeconds ~/ 60).toString().padLeft(2, '0');
    final ss = (_recSeconds % 60).toString().padLeft(2, '0');
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.red),
          onPressed: () => _stopRecording(send: false),
        ),
        const Icon(Icons.fiber_manual_record, color: Colors.red, size: 14),
        const SizedBox(width: 6),
        Text('$mm:$ss', style: const TextStyle(fontSize: 16)),
        const SizedBox(width: 10),
        Expanded(
          child: Text(context.tr('recording'),
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.black54)),
        ),
        IconButton(
          icon: Icon(Icons.send, color: Theme.of(context).colorScheme.primary),
          onPressed: () => _stopRecording(send: true),
        ),
      ]),
    );
  }

  Widget _inputBar() {
    final hasText = _controller.text.trim().isNotEmpty;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.add_circle_outline),
          onPressed: _sending ? null : _attachMenu,
        ),
        IconButton(
          icon: Icon(_emojiOpen ? Icons.keyboard : Icons.emoji_emotions_outlined),
          onPressed: () {
            FocusScope.of(context).unfocus();
            setState(() => _emojiOpen = !_emojiOpen);
          },
        ),
        Expanded(
          child: TextField(
            controller: _controller,
            minLines: 1,
            maxLines: 5,
            textCapitalization: TextCapitalization.sentences,
            onTap: () {
              if (_emojiOpen) setState(() => _emojiOpen = false);
            },
            decoration: InputDecoration(
              hintText: context.tr('message'),
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none),
            ),
          ),
        ),
        if (_sending)
          const Padding(
            padding: EdgeInsets.all(12),
            child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
          )
        else if (hasText)
          IconButton(icon: const Icon(Icons.send), onPressed: _send)
        else
          IconButton(icon: const Icon(Icons.mic), onPressed: _startRecording),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final msgs = _sorted;
    final primary = Theme.of(context).colorScheme.primary;
    final showStatus = _typing || _peerRecording;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          Avatar(url: widget.avatar, name: widget.name, radius: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(widget.name, overflow: TextOverflow.ellipsis),
                if (showStatus)
                  Row(children: [
                    Icon(_peerRecording ? Icons.mic : Icons.edit, size: 13, color: primary),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(
                        context.tr(_peerRecording ? 'recording' : 'typing'),
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: primary),
                      ),
                    ),
                  ]),
              ],
            ),
          ),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.call), onPressed: () => _call(false)),
          IconButton(icon: const Icon(Icons.videocam), onPressed: () => _call(true)),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'block') _block(true);
              if (v == 'unblock') _block(false);
              if (v == 'clear') _clearChat();
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'clear', child: Text(context.tr('clear_chat'))),
              PopupMenuItem(value: 'block', child: Text(context.tr('block_user'))),
              PopupMenuItem(value: 'unblock', child: Text(context.tr('unblock_user'))),
            ],
          ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : (_error != null && msgs.isEmpty)
                  ? Center(child: Text(_error!))
                  : ListView.builder(
                      reverse: true,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: msgs.length + 1,
                      itemBuilder: (_, i) {
                        if (i == msgs.length) {
                          // top of the conversation
                          if (!_hasMore || msgs.length < 30) return const SizedBox.shrink();
                          return Center(
                            child: _loadingOlder
                                ? const Padding(
                                    padding: EdgeInsets.all(8),
                                    child: CircularProgressIndicator(strokeWidth: 2))
                                : TextButton(
                                    onPressed: _loadOlder,
                                    child: Text(context.tr('load_older'))),
                          );
                        }
                        return _bubble(msgs[msgs.length - 1 - i]);
                      },
                    ),
        ),
        SafeArea(
          top: false,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            _recording ? _recordingBar() : _inputBar(),
            if (_emojiOpen && !_recording) _emojiPanel(),
          ]),
        ),
      ]),
    );
  }
}
