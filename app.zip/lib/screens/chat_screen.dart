import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../config.dart';
import '../crypto.dart';
import '../emoji_data.dart';
import '../i18n.dart';
import '../utils.dart';
import 'call_screens.dart';
import 'gif_sheet.dart';
import 'music_sheet.dart';
import 'starred_screen.dart';
import 'user_picker_screen.dart';

class ChatScreen extends StatefulWidget {
  final String userId;
  final String name;
  final String avatar;
  final String chatId;
  final bool isGroup;
  final bool isOwner;
  final List<dynamic> members;
  const ChatScreen({
    super.key,
    required this.userId,
    required this.name,
    this.avatar = '',
    this.chatId = '',
    this.isGroup = false,
    this.isOwner = false,
    this.members = const [],
  });
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final Map<int, Map<String, dynamic>> _byId = {};
  final TextEditingController _controller = TextEditingController();
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<PlayerState>? _subState;
  StreamSubscription<void>? _subDone;
  Timer? _timer;
  Timer? _typingStop;
  Timer? _recTimer;
  AudioRecorder? _rec;

  bool _loading = true;
  bool _sending = false;
  bool _fetching = false;
  bool _typing = false;
  bool _peerRecording = false;
  bool _emojiOpen = false;
  bool _recording = false;
  bool _hasMore = true;
  bool _loadingOlder = false;
  bool _isPlaying = false;
  int _recSeconds = 0;
  String? _error;
  String? _playingUrl;
  Map<String, dynamic>? _replyTo;
  DateTime _lastTyping = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onTextChanged);
    _subState = _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _isPlaying = s == PlayerState.playing);
    });
    _subDone = _player.onPlayerComplete.listen((_) {
      if (mounted) {
        setState(() {
          _isPlaying = false;
          _playingUrl = null;
        });
      }
    });
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _fetch());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _typingStop?.cancel();
    _recTimer?.cancel();
    _subState?.cancel();
    _subDone?.cancel();
    _player.dispose();
    _rec?.dispose();
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _sorted {
    final ids = _byId.keys.toList()..sort();
    return ids.map((i) => _byId[i]!).toList();
  }

  Map<String, dynamic> _prepare(Map m) {
    final mm = Map<String, dynamic>.from(m);
    mm['_text'] = cleanText(decryptText(m['text'], m['time']));
    return mm;
  }

  Future<void> _fetch() async {
    if (_fetching) return;
    _fetching = true;
    try {
      final res = widget.isGroup
          ? await Api.groupMessagesRaw(widget.userId)
          : await Api.getMessagesRaw(widget.userId);
      final msgs = _extractMessages(res);
      final fresh = <int, Map<String, dynamic>>{};
      for (final m in msgs) {
        if (m is! Map) continue;
        final id = int.tryParse(str(m['id']));
        if (id == null) continue;
        fresh[id] = _prepare(m);
      }
      if (fresh.isNotEmpty) {
        final minId = fresh.keys.reduce(math.min);
        // messages inside the fetched range that are gone were deleted
        _byId.removeWhere((id, _) => id >= minId && !fresh.containsKey(id));
        _byId.addAll(fresh);
      }
      final typing = str(res['typing']) == '1';
      final recording = (int.tryParse(str(res['is_recording'])) ?? 0) > 0;
      if (mounted) {
        setState(() {
          _loading = false;
          _error = null;
          _typing = typing;
          _peerRecording = recording;
        });
      }
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = e.message;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = e.toString();
        });
      }
    } finally {
      _fetching = false;
    }
  }

  List<dynamic> _extractMessages(Map<String, dynamic> res) {
    final d = res['data'];
    if (d is Map && d['messages'] is List) return d['messages'] as List;
    if (d is List) return d;
    return (res['messages'] as List?) ?? [];
  }

  void _setTyping(String status) {
    if (widget.isGroup) return;
    Api.setTyping(widget.userId, status).catchError((Object _) {});
  }

  Future<void> _apiText(String text, {String? replyId}) => widget.isGroup
      ? Api.groupSendText(widget.userId, text, replyId: replyId)
      : _apiText(text, replyId: replyId);

  Future<void> _apiFile(String path) => widget.isGroup
      ? Api.groupSendFile(widget.userId, path)
      : Api.sendFile(widget.userId, path);

  Future<void> _apiSticker(String url, String id) => widget.isGroup
      ? Api.groupSendSticker(widget.userId, url, id)
      : Api.sendSticker(widget.userId, url, id);

  Future<void> _apiGif(String url) => widget.isGroup
      ? Api.groupSendSticker(widget.userId, url, '')
      : _apiGif(url);

  Future<void> _loadOlder() async {
    if (_loadingOlder || _byId.isEmpty) return;
    setState(() => _loadingOlder = true);
    try {
      final minId = _byId.keys.reduce(math.min);
      final res = widget.isGroup
          ? await Api.groupMessagesRaw(widget.userId, beforeId: minId.toString())
          : await Api.getMessagesRaw(widget.userId, beforeId: minId.toString());
      final msgs = _extractMessages(res);
      var added = 0;
      for (final m in msgs) {
        if (m is! Map) continue;
        final id = int.tryParse(str(m['id']));
        if (id == null || _byId.containsKey(id)) continue;
        _byId[id] = _prepare(m);
        added++;
      }
      if (mounted) setState(() => _hasMore = added > 0);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loadingOlder = false);
    }
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  // ---------- typing indicator ----------
  void _onTextChanged() {
    if (mounted) setState(() {});
    final hasText = _controller.text.trim().isNotEmpty;
    final now = DateTime.now();
    if (hasText && now.difference(_lastTyping).inSeconds >= 3) {
      _lastTyping = now;
      _setTyping('typing');
    }
    _typingStop?.cancel();
    _typingStop = Timer(const Duration(seconds: 5), () {
      _setTyping('stop');
    });
  }

  // ---------- sending ----------
  Future<void> _run(Future<void> Function() action) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await action();
      await _fetch();
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    final replyId = _replyTo == null ? null : str(_replyTo!['id']);
    await _run(() async {
      await Api.sendText(widget.userId, text, replyId: replyId);
      _controller.clear();
      if (mounted) setState(() => _replyTo = null);
      _setTyping('stop');
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    final x = await ImagePicker().pickImage(source: source, imageQuality: 85);
    if (x == null) return;
    await _run(() => _apiFile(x.path));
  }

  Future<void> _pickVideo() async {
    final x = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (x == null) return;
    await _run(() => _apiFile(x.path));
  }

  bool get _giphyReady => !Config.giphyApiKey.startsWith('PASTE');

  Future<void> _pickGif({required bool stickers}) async {
    if (!_giphyReady) {
      _snack('GIF/stickers need a Giphy key: add GIPHY_API_KEY to app-settings.txt (see SETUP-KA.md)');
      return;
    }
    final item = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      builder: (_) => GifSheet(stickers: stickers),
    );
    if (item == null) return;
    final url = item['send'] ?? '';
    if (url.isEmpty) return;
    if (stickers) {
      await _run(() => _apiSticker(url, item['id'] ?? ''));
    } else {
      await _run(() => Api.sendGif(widget.userId, url));
    }
  }

  Future<void> _pickMusic() async {
    final item = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const MusicSheet(),
    );
    if (item == null) return;
    final text = '🎵 ${item['artist']} — ${item['title']}\n${item['preview']}';
    await _run(() => _apiText(text));
  }

  Future<void> _pickFile() async {
    final res = await FilePicker.platform.pickFiles();
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;
    await _run(() => _apiFile(path));
  }

  void _attachMenu() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.photo),
            title: Text(ctx.tr('gallery')),
            onTap: () {
              Navigator.pop(ctx);
              _pickImage(ImageSource.gallery);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: Text(ctx.tr('camera')),
            onTap: () {
              Navigator.pop(ctx);
              _pickImage(ImageSource.camera);
            },
          ),
          ListTile(
            leading: const Icon(Icons.videocam),
            title: Text(ctx.tr('video')),
            onTap: () {
              Navigator.pop(ctx);
              _pickVideo();
            },
          ),
          ListTile(
            leading: const Icon(Icons.insert_drive_file),
            title: Text(ctx.tr('file')),
            onTap: () {
              Navigator.pop(ctx);
              _pickFile();
            },
          ),
          ListTile(
            leading: const Icon(Icons.gif_box),
            title: Text(ctx.tr('gif')),
            onTap: () {
              Navigator.pop(ctx);
              _pickGif(stickers: false);
            },
          ),
          ListTile(
            leading: const Icon(Icons.sticky_note_2),
            title: Text(ctx.tr('sticker')),
            onTap: () {
              Navigator.pop(ctx);
              _pickGif(stickers: true);
            },
          ),
          ListTile(
            leading: const Icon(Icons.music_note),
            title: Text(t2(ctx, 'მუსიკა', 'Music')),
            onTap: () {
              Navigator.pop(ctx);
              _pickMusic();
            },
          ),
        ]),
      ),
    );
  }

  // ---------- voice messages ----------
  Future<void> _startRecording() async {
    try {
      final rec = AudioRecorder();
      if (!await rec.hasPermission()) {
        await rec.dispose();
        _snack(context.tr('permission_denied'));
        return;
      }
      final path =
          '${Directory.systemTemp.path}/voice_${DateTime.now().millisecondsSinceEpoch}.wav';
      await rec.start(
        const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );
      _rec = rec;
      if (!mounted) return;
      setState(() {
        _recording = true;
        _recSeconds = 0;
      });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSeconds++);
      });
      _setTyping('recording');
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _stopRecording({required bool send}) async {
    _recTimer?.cancel();
    final rec = _rec;
    _rec = null;
    String? path;
    try {
      path = await rec?.stop();
      await rec?.dispose();
    } catch (_) {}
    final seconds = _recSeconds;
    if (mounted) setState(() => _recording = false);
    _setTyping('stop');
    if (path == null) return;
    final file = File(path);
    if (send && seconds >= 1) {
      await _run(() => _apiFile(path!));
    }
    try {
      await file.delete();
    } catch (_) {}
  }

  Future<void> _togglePlay(String url) async {
    try {
      if (_playingUrl == url && _isPlaying) {
        await _player.pause();
        return;
      }
      if (_playingUrl == url) {
        await _player.resume();
        return;
      }
      await _player.stop();
      setState(() => _playingUrl = url);
      await _player.play(UrlSource(url));
    } catch (e) {
      _snack('$e');
    }
  }

  // ---------- message actions ----------
  void _messageMenu(Map<String, dynamic> m, bool mine) {
    final text = str(m['_text']);
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.reply),
            title: Text(ctx.tr('reply')),
            onTap: () {
              Navigator.pop(ctx);
              setState(() => _replyTo = m);
            },
          ),
          if (widget.chatId.isNotEmpty && !widget.isGroup)
            ListTile(
              leading: const Icon(Icons.star_border),
              title: Text(ctx.tr('star')),
              onTap: () async {
                Navigator.pop(ctx);
                try {
                  await Api.favMessage(str(m['id']), widget.chatId, true);
                  _snack(context.tr('done'));
                } catch (e) {
                  _snack('$e');
                }
              },
            ),
          ListTile(
            leading: const Icon(Icons.forward),
            title: Text(ctx.tr('forward')),
            onTap: () {
              Navigator.pop(ctx);
              _forward(int.tryParse(str(m['id'])));
            },
          ),
          if (text.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy),
              title: Text(ctx.tr('copy')),
              onTap: () {
                Clipboard.setData(ClipboardData(text: text));
                Navigator.pop(ctx);
                _snack(ctx.tr('done'));
              },
            ),
          if (mine)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: Text(ctx.tr('delete'), style: const TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _deleteMessage(int.tryParse(str(m['id'])));
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _forward(int? id) async {
    if (id == null) return;
    try {
      final res = await Api.getChats();
      final list = ((res['data'] as List?) ?? [])
          .where((c) => c is Map && (str(c['chat_type']).isEmpty || c['chat_type'] == 'user'))
          .map((c) => Map<String, dynamic>.from(c as Map))
          .toList();
      if (!mounted) return;
      final target = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (ctx) => SimpleDialog(
          title: Text(ctx.tr('forward')),
          children: [
            SizedBox(
              width: double.maxFinite,
              height: 360,
              child: ListView(
                children: [
                  for (final c in list)
                    ListTile(
                      leading: Avatar(url: str(c['avatar']), name: displayName(c)),
                      title: Text(displayName(c)),
                      onTap: () => Navigator.pop(ctx, c),
                    ),
                ],
              ),
            ),
          ],
        ),
      );
      if (target == null) return;
      await Api.forwardMessage(id.toString(), str(target['user_id']));
      _snack(context.tr('done'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _deleteMessage(int? id) async {
    if (id == null) return;
    try {
      await Api.deleteMessage(id.toString());
      if (mounted) setState(() => _byId.remove(id));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<bool> _confirm(String message) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('delete'))),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _showMembers() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(ctx.tr('members')),
        children: [
          SizedBox(
            width: double.maxFinite,
            height: 360,
            child: ListView(children: [
              for (final p in widget.members)
                if (p is Map)
                  ListTile(
                    leading: Avatar(url: str(p['avatar']), name: displayName(p)),
                    title: Text(displayName(p)),
                    trailing: (widget.isOwner && str(p['user_id']) != Api.userId)
                        ? IconButton(
                            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                            tooltip: ctx.tr('remove'),
                            onPressed: () async {
                              Navigator.pop(ctx);
                              try {
                                await Api.groupRemoveUser(widget.userId, str(p['user_id']));
                                _snack(context.tr('done'));
                              } catch (e) {
                                _snack('$e');
                              }
                            },
                          )
                        : null,
                  ),
            ]),
          ),
        ],
      ),
    );
  }

  Future<void> _addMembers() async {
    final picked = await Navigator.of(context).push<List<Map<String, dynamic>>>(
        MaterialPageRoute(builder: (_) => UserPickerScreen(title: context.tr('add_members'))));
    if (picked == null || picked.isEmpty) return;
    try {
      await Api.groupAddUsers(widget.userId, picked.map((u) => str(u['user_id'])).toList());
      _snack(context.tr('done'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _leaveGroup() async {
    if (!await _confirm('${context.tr('leave_group')}?')) return;
    try {
      await Api.groupLeave(widget.userId);
      if (mounted) Navigator.of(context).pop();
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _deleteGroup() async {
    if (!await _confirm('${context.tr('delete_group')}?')) return;
    try {
      await Api.groupDelete(widget.userId);
      if (mounted) Navigator.of(context).pop();
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _clearChat() async {
    if (!await _confirm(context.tr('clear_confirm'))) return;
    try {
      await Api.deleteConversation(widget.userId);
      if (mounted) setState(() => _byId.clear());
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _block(bool block) async {
    try {
      await Api.blockUser(widget.userId, block);
      _snack(context.tr(block ? 'user_blocked' : 'user_unblocked'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _call(bool video) async {
    try {
      await startCall(context,
          userId: widget.userId, name: widget.name, avatar: widget.avatar, video: video);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  // ---------- emoji ----------
  void _insertEmoji(String e) {
    final text = _controller.text;
    final sel = _controller.selection;
    final start = sel.isValid && sel.start >= 0 ? sel.start : text.length;
    final end = sel.isValid && sel.end >= 0 ? sel.end : text.length;
    final newText = text.replaceRange(start, end, e);
    _controller.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: start + e.length),
    );
  }

  Widget _emojiPanel() {
    return SizedBox(
      height: 250,
      child: GridView.builder(
        padding: const EdgeInsets.all(6),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
        itemCount: kEmojis.length,
        itemBuilder: (_, i) => InkWell(
          onTap: () => _insertEmoji(kEmojis[i]),
          child: Center(child: Text(kEmojis[i], style: const TextStyle(fontSize: 26))),
        ),
      ),
    );
  }

  // ---------- bubbles ----------
  Widget _voiceTile(String url, bool mine) {
    final playing = _playingUrl == url && _isPlaying;
    final color = mine ? Colors.white : Colors.black87;
    return InkWell(
      onTap: () => _togglePlay(url),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill, size: 34, color: color),
        const SizedBox(width: 6),
        Icon(Icons.graphic_eq, color: color),
        const SizedBox(width: 6),
        Icon(Icons.mic, size: 16, color: color),
      ]),
    );
  }

  Widget _bubble(Map<String, dynamic> m) {
    final mine = str(m['from_id']) == Api.userId;
    final media = str(m['media']);
    final sticker = str(m['stickers']);
    final text = str(m['_text']);
    final lat = str(m['lat']);
    final lng = str(m['lng']);
    final seen = str(m['seen']).isNotEmpty && str(m['seen']) != '0';
    final scheme = Theme.of(context).colorScheme;
    final fg = mine ? Colors.white : null;
    final children = <Widget>[];

    if (widget.isGroup && !mine) {
      final ud = m['user_data'];
      final who = ud is Map ? displayName(ud) : '';
      if (who.isNotEmpty) {
        children.add(Text(who,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: scheme.primary)));
      }
    }

    final reply = m['reply'];
    if (reply is Map && reply.isNotEmpty) {
      final rt = cleanText(decryptText(reply['text'], reply['time']));
      final label = rt.isNotEmpty ? rt : (str(reply['media']).isNotEmpty ? '📎' : '');
      if (label.isNotEmpty) {
        children.add(Container(
          margin: const EdgeInsets.only(bottom: 4),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.black12,
            borderRadius: BorderRadius.circular(6),
            border: Border(left: BorderSide(color: mine ? Colors.white70 : scheme.primary, width: 3)),
          ),
          child: Text(label, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: fg)),
        ));
      }
    }

    if (sticker.isNotEmpty && isImageUrl(sticker.contains('.gif') ? sticker.split('?').first : sticker)) {
      children.add(ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(sticker, width: 200,
            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
      ));
    }
    if (media.isNotEmpty) {
      if (isImageUrl(media)) {
        children.add(GestureDetector(
          onTap: () => showDialog<void>(
            context: context,
            builder: (_) => Dialog(
              backgroundColor: Colors.black,
              insetPadding: EdgeInsets.zero,
              child: InteractiveViewer(child: Image.network(media)),
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(media, width: 220,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
          ),
        ));
      } else if (isAudioUrl(media)) {
        children.add(_voiceTile(media, mine));
      } else if (isVideoUrl(media)) {
        children.add(InkWell(
          onTap: () => launchUrl(Uri.parse(media), mode: LaunchMode.externalApplication),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.play_circle_fill, size: 34, color: fg),
            const SizedBox(width: 6),
            Text(context.tr('video'), style: TextStyle(color: fg)),
          ]),
        ));
      } else {
        children.add(InkWell(
          onTap: () => launchUrl(Uri.parse(media), mode: LaunchMode.externalApplication),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.attach_file, size: 18, color: fg),
            const SizedBox(width: 4),
            Text(context.tr('open_attachment'),
                style: TextStyle(decoration: TextDecoration.underline, color: fg)),
          ]),
        ));
      }
    }
    if (lat.isNotEmpty && lat != '0' && lng.isNotEmpty && lng != '0') {
      children.add(InkWell(
        onTap: () => launchUrl(Uri.parse('https://maps.google.com/?q=$lat,$lng'),
            mode: LaunchMode.externalApplication),
        child: Text('📍 $lat, $lng',
            style: TextStyle(decoration: TextDecoration.underline, color: fg)),
      ));
    }
    if (text.isNotEmpty) {
      children.add(Text(text, style: TextStyle(color: fg)));
    }
    children.add(Row(mainAxisSize: MainAxisSize.min, children: [
      Text(str(m['time_text']),
          style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : Colors.black45)),
      if (mine) ...[
        const SizedBox(width: 4),
        Icon(Icons.done_all, size: 14, color: seen ? Colors.lightBlueAccent : Colors.white54),
      ],
    ]));

    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _messageMenu(m, mine),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: mine ? scheme.primary : scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: children,
            ),
          ),
        ),
      ),
    );
  }

  // ---------- input bar ----------
  Widget _replyBar() {
    final r = _replyTo!;
    final t = str(r['_text']).isNotEmpty ? str(r['_text']) : '📎';
    return Container(
      color: Colors.black12,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(children: [
        const Icon(Icons.reply, size: 18),
        const SizedBox(width: 8),
        Expanded(
          child: Text('${context.tr('replying_to')} $t',
              maxLines: 1, overflow: TextOverflow.ellipsis),
        ),
        IconButton(
          icon: const Icon(Icons.close, size: 18),
          onPressed: () => setState(() => _replyTo = null),
        ),
      ]),
    );
  }

  Widget _recordingBar() {
    final mm = (_recSeconds ~/ 60).toString().padLeft(2, '0');
    final ss = (_recSeconds % 60).toString().padLeft(2, '0');
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.red),
          onPressed: () => _stopRecording(send: false),
        ),
        const Icon(Icons.fiber_manual_record, color: Colors.red, size: 14),
        const SizedBox(width: 6),
        Text('$mm:$ss', style: const TextStyle(fontSize: 16)),
        const SizedBox(width: 10),
        Expanded(
          child: Text(context.tr('recording'),
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.black54)),
        ),
        IconButton(
          icon: Icon(Icons.send, color: Theme.of(context).colorScheme.primary),
          onPressed: () => _stopRecording(send: true),
        ),
      ]),
    );
  }

  Widget _inputBar() {
    final hasText = _controller.text.trim().isNotEmpty;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.add_circle_outline),
          onPressed: _sending ? null : _attachMenu,
        ),
        IconButton(
          icon: Icon(_emojiOpen ? Icons.keyboard : Icons.emoji_emotions_outlined),
          onPressed: () {
            FocusScope.of(context).unfocus();
            setState(() => _emojiOpen = !_emojiOpen);
          },
        ),
        Expanded(
          child: TextField(
            controller: _controller,
            minLines: 1,
            maxLines: 5,
            textCapitalization: TextCapitalization.sentences,
            onTap: () {
              if (_emojiOpen) setState(() => _emojiOpen = false);
            },
            decoration: InputDecoration(
              hintText: context.tr('message'),
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none),
            ),
          ),
        ),
        if (_sending)
          const Padding(
            padding: EdgeInsets.all(12),
            child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
          )
        else if (hasText)
          IconButton(icon: const Icon(Icons.send), onPressed: _send)
        else
          IconButton(icon: const Icon(Icons.mic), onPressed: _startRecording),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final msgs = _sorted;
    final primary = Theme.of(context).colorScheme.primary;
    final showStatus = _typing || _peerRecording;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          Avatar(url: widget.avatar, name: widget.name, radius: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(widget.name, overflow: TextOverflow.ellipsis),
                if (widget.isGroup)
                  Text('${context.tr('members')}: ${widget.members.length}',
                      style: const TextStyle(fontSize: 12)),
                if (showStatus)
                  Row(children: [
                    Icon(_peerRecording ? Icons.mic : Icons.edit, size: 13, color: primary),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(
                        context.tr(_peerRecording ? 'recording' : 'typing'),
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: primary),
                      ),
                    ),
                  ]),
              ],
            ),
          ),
        ]),
        actions: [
          if (!widget.isGroup) ...[
            IconButton(icon: const Icon(Icons.call), onPressed: () => _call(false)),
            IconButton(icon: const Icon(Icons.videocam), onPressed: () => _call(true)),
          ],
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'block') _block(true);
              if (v == 'unblock') _block(false);
              if (v == 'clear') _clearChat();
              if (v == 'starred') {
                Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => StarredScreen(chatId: widget.chatId)));
              }
              if (v == 'members') _showMembers();
              if (v == 'add') _addMembers();
              if (v == 'leave') _leaveGroup();
              if (v == 'delete_group') _deleteGroup();
            },
            itemBuilder: (_) => widget.isGroup
                ? [
                    PopupMenuItem(value: 'members', child: Text(context.tr('members'))),
                    PopupMenuItem(value: 'add', child: Text(context.tr('add_members'))),
                    PopupMenuItem(value: 'leave', child: Text(context.tr('leave_group'))),
                    if (widget.isOwner)
                      PopupMenuItem(value: 'delete_group', child: Text(context.tr('delete_group'))),
                  ]
                : [
                    if (widget.chatId.isNotEmpty)
                      PopupMenuItem(
                          value: 'starred', child: Text(context.tr('starred_messages'))),
                    PopupMenuItem(value: 'clear', child: Text(context.tr('clear_chat'))),
                    PopupMenuItem(value: 'block', child: Text(context.tr('block_user'))),
                    PopupMenuItem(value: 'unblock', child: Text(context.tr('unblock_user'))),
                  ],
          ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : (_error != null && msgs.isEmpty)
                  ? Center(child: Text(_error!))
                  : ListView.builder(
                      reverse: true,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: msgs.length + 1,
                      itemBuilder: (_, i) {
                        if (i == msgs.length) {
                          // top of the conversation
                          if (!_hasMore || msgs.length < 30) return const SizedBox.shrink();
                          return Center(
                            child: _loadingOlder
                                ? const Padding(
                                    padding: EdgeInsets.all(8),
                                    child: CircularProgressIndicator(strokeWidth: 2))
                                : TextButton(
                                    onPressed: _loadOlder,
                                    child: Text(context.tr('load_older'))),
                          );
                        }
                        return _bubble(msgs[msgs.length - 1 - i]);
                      },
                    ),
        ),
        SafeArea(
          top: false,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (_replyTo != null && !_recording) _replyBar(),
            _recording ? _recordingBar() : _inputBar(),
            if (_emojiOpen && !_recording) _emojiPanel(),
          ]),
        ),
      ]),
    );
  }
}
