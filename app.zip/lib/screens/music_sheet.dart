import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import '../api.dart';
import '../utils.dart';

/// Bottom sheet that searches songs (iTunes previews). Pops the chosen song as
/// {'title', 'artist', 'art', 'preview'}.
class MusicSheet extends StatefulWidget {
  const MusicSheet({super.key});
  @override
  State<MusicSheet> createState() => _MusicSheetState();
}

class _MusicSheetState extends State<MusicSheet> {
  final _q = TextEditingController();
  final AudioPlayer _player = AudioPlayer();
  List<Map<String, String>> _items = [];
  bool _busy = false;
  String? _error;
  String _playing = '';

  @override
  void dispose() {
    _player.dispose();
    _q.dispose();
    super.dispose();
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final l = await Api.searchMusic(q);
      if (mounted) setState(() => _items = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggle(String url) async {
    try {
      if (_playing == url) {
        await _player.stop();
        if (mounted) setState(() => _playing = '');
        return;
      }
      await _player.play(UrlSource(url));
      if (mounted) setState(() => _playing = url);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.65,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: TextField(
                  controller: _q,
                  autofocus: true,
                  textInputAction: TextInputAction.search,
                  decoration: InputDecoration(
                    hintText: t2(context, 'სიმღერის ძებნა', 'Search for a song'),
                    prefixIcon: const Icon(Icons.music_note),
                    border: const OutlineInputBorder(),
                    isDense: true,
                  ),
                  onSubmitted: _search,
                ),
              ),
              Expanded(
                child: _busy
                    ? const Center(child: CircularProgressIndicator())
                    : _error != null
                        ? Center(child: Text(_error!))
                        : ListView.builder(
                            itemCount: _items.length,
                            itemBuilder: (_, i) {
                              final it = _items[i];
                              final prev = it['preview'] ?? '';
                              return ListTile(
                                leading: (it['art'] ?? '').isEmpty
                                    ? const Icon(Icons.music_note)
                                    : ClipRRect(
                                        borderRadius: BorderRadius.circular(6),
                                        child: Image.network(it['art']!,
                                            width: 48,
                                            height: 48,
                                            fit: BoxFit.cover,
                                            errorBuilder: (_, __, ___) =>
                                                const Icon(Icons.music_note))),
                                title: Text(it['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
                                subtitle: Text(it['artist'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
                                trailing: IconButton(
                                  icon: Icon(_playing == prev ? Icons.stop_circle : Icons.play_circle),
                                  onPressed: () => _toggle(prev),
                                ),
                                onTap: () => Navigator.of(context).pop(it),
                              );
                            },
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
