import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../i18n.dart';
import '../utils.dart';
import 'story_composer.dart';

/// Url and kind of the media of one story.
Map<String, dynamic>? storyMedia(Map<String, dynamic> story, String userAvatar) {
  String fileOf(dynamic f) => f is Map ? str(f['filename']) : str(f);
  final vids = story['videos'];
  if (vids is List && vids.isNotEmpty) {
    final u = fileOf(vids.first);
    if (u.isNotEmpty) return {'url': u, 'video': true};
  }
  final th = str(story['thumbnail']);
  if (th.isNotEmpty && th != userAvatar) return {'url': th, 'video': false};
  final imgs = story['images'];
  if (imgs is List && imgs.isNotEmpty) {
    final u = fileOf(imgs.first);
    if (u.isNotEmpty) return {'url': u, 'video': false};
  }
  return null;
}

class StoriesScreen extends StatefulWidget {
  const StoriesScreen({super.key});
  @override
  State<StoriesScreen> createState() => _StoriesScreenState();
}

class _StoriesScreenState extends State<StoriesScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.getStoryUsers();
      if (mounted) {
        setState(() {
          _users = l;
          _error = null;
        });
      }
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Map<String, dynamic>> _storiesOf(Map<String, dynamic> u) {
    final l = u['stories'];
    if (l is! List) return [];
    return l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<void> _addStory() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
              leading: const Icon(Icons.photo),
              title: Text(ctx.tr('gallery')),
              onTap: () => Navigator.pop(ctx, 'gallery')),
          ListTile(
              leading: const Icon(Icons.photo_camera),
              title: Text(ctx.tr('camera')),
              onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(
              leading: const Icon(Icons.videocam),
              title: Text(ctx.tr('video')),
              onTap: () => Navigator.pop(ctx, 'video')),
        ]),
      ),
    );
    if (choice == null) return;
    final picker = ImagePicker();
    XFile? file;
    if (choice == 'video') {
      file = await picker.pickVideo(source: ImageSource.gallery);
    } else {
      file = await picker.pickImage(
          source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery,
          imageQuality: 85);
    }
    if (file == null || !mounted) return;
    final pickedPath = file.path;
    var sendPath = pickedPath;
    var caption = '';
    var music = '';
    if (choice == 'video') {
      final c = await _askCaption();
      if (c == null) return;
      caption = c;
    } else {
      final draft = await Navigator.of(context).push<StoryDraft>(MaterialPageRoute(
          fullscreenDialog: true, builder: (_) => StoryComposerScreen(imagePath: pickedPath)));
      if (draft == null) return;
      sendPath = draft.path;
      caption = draft.caption;
      music = draft.music;
    }
    setState(() => _busy = true);
    try {
      await Api.createStory(sendPath, video: choice == 'video', title: caption, music: music);
      await _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.tr('done'))));
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _askCaption() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('caption')),
        content: TextField(controller: c, maxLength: 100),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: Text(ctx.tr('done'))),
        ],
      ),
    );
  }

  Future<void> _open(Map<String, dynamic> user) async {
    final stories = _storiesOf(user);
    if (stories.isEmpty) return;
    await Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => StoryViewerScreen(user: user, stories: stories)));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final mine = _users.where((u) => str(u['user_id']) == Api.userId).toList();
    final others = _users.where((u) => str(u['user_id']) != Api.userId).toList();
    final myAvatar = str(Api.me['avatar']);
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('stories'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                children: [
                  ListTile(
                    leading: Stack(children: [
                      Avatar(url: myAvatar, name: context.tr('you'), radius: 26),
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: CircleAvatar(
                          radius: 10,
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          child: const Icon(Icons.add, size: 14, color: Colors.white),
                        ),
                      ),
                    ]),
                    title: Text(context.tr('my_story')),
                    subtitle: Text(_busy ? '...' : context.tr('add_story')),
                    onTap: _busy
                        ? null
                        : (mine.isNotEmpty && _storiesOf(mine.first).isNotEmpty
                            ? () => _open(mine.first)
                            : _addStory),
                    trailing: IconButton(icon: const Icon(Icons.add_a_photo), onPressed: _busy ? null : _addStory),
                  ),
                  const Divider(height: 1),
                  if (_error != null) Padding(padding: const EdgeInsets.all(16), child: Text(_error!)),
                  if (others.isEmpty && _error == null)
                    Padding(
                      padding: const EdgeInsets.all(32),
                      child: Center(child: Text(context.tr('no_stories'))),
                    ),
                  for (final u in others)
                    Builder(builder: (_) {
                      final stories = _storiesOf(u);
                      final unseen = stories.any((s) => str(s['is_viewed']) == '0' || s['is_viewed'] == false);
                      final last = stories.isNotEmpty ? stories.first : <String, dynamic>{};
                      return ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: unseen ? Theme.of(context).colorScheme.primary : Colors.grey,
                                width: 2.5),
                          ),
                          child: Avatar(url: str(u['avatar']), name: displayName(u), radius: 22),
                        ),
                        title: Text(displayName(u), maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(str(last['time_text'])),
                        onTap: () => _open(u),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}

class StoryViewerScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  final List<Map<String, dynamic>> stories;
  const StoryViewerScreen({super.key, required this.user, required this.stories});
  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen> {
  final PageController _page = PageController();
  final AudioPlayer _music = AudioPlayer();
  Timer? _timer;
  int _index = 0;
  final _reply = TextEditingController();
  final _focus = FocusNode();
  bool _sendingReply = false;

  Map<String, dynamic> get _story => widget.stories[_index];

  bool get _isOwner => _story['is_owner'] == true || str(widget.user['user_id']) == Api.userId;

  @override
  void initState() {
    super.initState();
    _shown();
    // typing a reply pauses the story
    _focus.addListener(() {
      if (_focus.hasFocus) {
        _timer?.cancel();
      } else {
        _armTimer();
      }
    });
  }

  void _armTimer() {
    _timer?.cancel();
    final m = storyMedia(_story, str(widget.user['avatar']));
    if (m == null || m['video'] != true) {
      _timer = Timer(const Duration(seconds: 6), _next);
    }
  }

  /// Like Messenger: a reaction or a reply to a story goes to the owner as a
  /// private message, together with the picture of the story.
  Future<void> _sendToOwner(String text, {bool withPicture = true}) async {
    if (_sendingReply || text.trim().isEmpty) return;
    final uid = str(widget.user['user_id']);
    if (uid.isEmpty) return;
    setState(() => _sendingReply = true);
    String? msg;
    try {
      final m = storyMedia(_story, str(widget.user['avatar']));
      if (withPicture && m != null && m['video'] != true) {
        final r = await http.get(Uri.parse(str(m['url']))).timeout(const Duration(seconds: 25));
        if (r.statusCode == 200) {
          final f = File('${Directory.systemTemp.path}/story_reply_${DateTime.now().millisecondsSinceEpoch}.jpg');
          await f.writeAsBytes(r.bodyBytes);
          await Api.sendFile(uid, f.path);
        }
      }
      await Api.sendText(uid, text.trim());
      msg = 'გაიგზავნა ✓';
    } catch (e) {
      msg = '$e';
    }
    if (!mounted) return;
    setState(() => _sendingReply = false);
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 1)));
  }

  Future<void> _sendReply() async {
    final t = _reply.text;
    _reply.clear();
    _focus.unfocus();
    await _sendToOwner(t);
  }

  Widget _replyBar() {
    const emojis = ['❤️', '😂', '😮', '😢', '😡', '👍'];
    return Positioned(
      left: 12,
      right: 12,
      bottom: 12 + MediaQuery.of(context).viewInsets.bottom,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          for (final e in emojis)
            GestureDetector(
              onTap: () => _sendToOwner('$e  სთორზე რეაქცია', withPicture: false),
              child: Text(e, style: const TextStyle(fontSize: 30)),
            ),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _reply,
              focusNode: _focus,
              style: const TextStyle(color: Colors.white),
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _sendReply(),
              decoration: InputDecoration(
                hintText: 'მიწერე პასუხი...',
                hintStyle: const TextStyle(color: Colors.white60),
                isDense: true,
                filled: true,
                fillColor: Colors.white12,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: const BorderSide(color: Colors.white54)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: const BorderSide(color: Colors.white54)),
              ),
            ),
          ),
          IconButton(
              icon: const Icon(Icons.send, color: Colors.white), onPressed: _sendReply),
        ]),
      ]),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _reply.dispose();
    _focus.dispose();
    _music.dispose();
    _page.dispose();
    super.dispose();
  }

  void _shown() {
    Api.markStorySeen(str(_story['id']));
    _timer?.cancel();
    _music.stop().catchError((_) {});
    final mm = RegExp(r'♪(https?://\S+)')
        .firstMatch('${str(_story['title'])} ${str(_story['description'])}');
    if (mm != null) {
      _playMusic(mm.group(1)!);
    }
    _armTimer();
  }

  Future<void> _playMusic(String url) async {
    try {
      await _music.setReleaseMode(ReleaseMode.loop);
      await _music.setVolume(1.0);
      await _music.play(UrlSource(url));
    } catch (_) {}
  }

  void _next() {
    if (_index < widget.stories.length - 1) {
      _page.nextPage(duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    } else if (mounted) {
      Navigator.of(context).pop();
    }
  }

  void _prev() {
    if (_index > 0) {
      _page.previousPage(duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text('${ctx.tr('delete')}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('delete'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.deleteStory(str(_story['id']));
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Widget _pageFor(Map<String, dynamic> s) {
    final m = storyMedia(s, str(widget.user['avatar']));
    final caption = '${str(s['title'])} ${str(s['description'])}'
        .replaceAll(RegExp(r'♪https?://\S+'), '')
        .trim();
    Widget body;
    if (m == null) {
      body = const Icon(Icons.image_not_supported, color: Colors.white54, size: 64);
    } else if (m['video'] == true) {
      body = Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.play_circle_fill, color: Colors.white, size: 80),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: () => launchUrl(Uri.parse(str(m['url'])), mode: LaunchMode.externalApplication),
          child: Text(context.tr('open_video')),
        ),
      ]);
    } else {
      body = InteractiveViewer(
        child: Image.network(str(m['url']), fit: BoxFit.contain,
            errorBuilder: (_, __, ___) =>
                const Icon(Icons.broken_image, color: Colors.white54, size: 64)),
      );
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapUp: (d) {
        final w = MediaQuery.of(context).size.width;
        if (d.localPosition.dx < w / 3) {
          _prev();
        } else {
          _next();
        }
      },
      child: Stack(children: [
        Center(child: body),
        if (caption.isNotEmpty)
          Positioned(
            left: 16,
            right: 16,
            bottom: _isOwner ? 36 : 140,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: Colors.black54, borderRadius: BorderRadius.circular(10)),
              child: Text(caption, style: const TextStyle(color: Colors.white, fontSize: 16)),
            ),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final owner = _story['is_owner'] == true || str(widget.user['user_id']) == Api.userId;
    final views = str(_story['view_count']);
    return Scaffold(
      backgroundColor: Colors.black,
      resizeToAvoidBottomInset: false,
      body: Stack(children: [
        PageView.builder(
          controller: _page,
          itemCount: widget.stories.length,
          onPageChanged: (i) {
            setState(() => _index = i);
            _shown();
          },
          itemBuilder: (_, i) => _pageFor(widget.stories[i]),
        ),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
              child: Row(children: [
                for (var i = 0; i < widget.stories.length; i++)
                  Expanded(
                    child: Container(
                      height: 3,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      color: i <= _index ? Colors.white : Colors.white30,
                    ),
                  ),
              ]),
            ),
            ListTile(
              leading: Avatar(
                  url: str(widget.user['avatar']), name: displayName(widget.user), radius: 18),
              title: Text(displayName(widget.user),
                  style: const TextStyle(color: Colors.white), maxLines: 1),
              subtitle: Text(
                  '${str(_story['time_text'])}${owner && views.isNotEmpty ? '  ·  👁 $views' : ''}',
                  style: const TextStyle(color: Colors.white70)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (owner)
                  IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.white),
                      onPressed: _delete),
                IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () => Navigator.of(context).pop()),
              ]),
            ),
          ]),
        ),
        if (!owner) _replyBar(),
      ]),
    );
  }
}
