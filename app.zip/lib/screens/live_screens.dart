import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import '../api.dart';
import '../call_native.dart';
import '../config.dart';
import '../utils.dart';
import 'user_picker_screen.dart';

/// Live video (same Agora live channel as the website, so web users can watch too).
/// The page uses the Agora SDK that the site itself serves.
const String _liveHtml = r"""<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<style>
html,body{margin:0;height:100%;background:#000;overflow:hidden}
#v{position:absolute;left:0;top:0;right:0;bottom:0;background:#000}
</style></head><body>
<div id="v"></div>
<script src="__SITE__/themes/wowonder/javascript/agora.js"></script>
<script>
var CFG = __CFG__;
function post(m){ try { Live.postMessage(m); } catch(e){} }
function fail(e){ post('error:' + ((e && (e.msg || e.message || e.reason)) || e || 'unknown')); }
var client = null, localStream = null, camIdx = 0;
window.flip = function(){
  if (!client || !localStream) return;
  client.getCameras(function(list){
    if (!list || list.length < 2) return;
    camIdx = (camIdx + 1) % list.length;
    localStream.switchDevice('video', list[camIdx].deviceId, function(){}, function(e){ fail(e); });
  });
};
window.mute = function(m){ if (!localStream) return; if (m) localStream.muteAudio(); else localStream.unmuteAudio(); };
window.thumb = function(){
  var v = document.querySelector('#v video');
  if (!v || !v.videoWidth) return '';
  var c = document.createElement('canvas');
  c.width = 480; c.height = Math.round(480 * v.videoHeight / v.videoWidth);
  c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.7);
};
window.leave = function(){
  try { if (localStream) { localStream.stop(); localStream.close(); } } catch(e){}
  try { if (client) client.leave(function(){}, function(){}); } catch(e){}
};
if (typeof AgoraRTC === 'undefined') {
  post('error:Agora SDK could not be loaded from the site');
} else {
  client = AgoraRTC.createClient({mode: 'live', codec: 'vp8'});
  client.on('stream-published', function(){ post('published'); });
  client.on('stream-added', function(e){ if (!CFG.host) client.subscribe(e.stream, function(err){ fail(err); }); });
  client.on('stream-subscribed', function(e){ e.stream.play('v'); post('playing'); });
  client.on('peer-leave', function(){ if (!CFG.host) post('hostleft'); });
  client.init(CFG.appId, function(){
    client.setClientRole(CFG.host ? 'host' : 'audience', function(){
      var uid = CFG.host ? null : Math.floor(Math.random() * 1000000) + 1;
      client.join(CFG.token || null, CFG.channel, uid, function(id){
        if (!CFG.host) { post('joined'); return; }
        localStream = AgoraRTC.createStream({streamID: id, audio: true, video: true, screen: false});
        localStream.setVideoProfile('720p_6');
        localStream.init(function(){
          localStream.play('v');
          client.publish(localStream, function(err){ fail(err); });
        }, function(err){ fail(err); });
      }, function(err){ fail(err); });
    }, function(err){ fail(err); });
  }, function(err){ fail(err); });
}
</script></body></html>""";

Future<WebViewController> _buildLiveWeb(Map<String, dynamic> cfg, void Function(String) onMsg) async {
  final json = jsonEncode(cfg).replaceAll('<', '\\u003c');
  final html = _liveHtml.replaceFirst('__SITE__', Config.siteUrl).replaceFirst('__CFG__', json);
  final c = WebViewController(onPermissionRequest: (req) => req.grant())
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..setBackgroundColor(Colors.black)
    ..addJavaScriptChannel('Live', onMessageReceived: (m) => onMsg(m.message))
    ..loadHtmlString(html, baseUrl: Config.siteUrl);
  final platform = c.platform;
  if (platform is AndroidWebViewController) {
    await platform.setMediaPlaybackRequiresUserGesture(false);
  }
  return c;
}

class _LiveComment {
  final String id;
  final String userId;
  final String name;
  final String text;
  _LiveComment(this.name, this.text, {this.id = '', this.userId = ''});
}

String _commentName(dynamic p) {
  if (p is! Map) return '';
  final n = str(p['name']);
  if (n.isNotEmpty) return n;
  return '${str(p['first_name'])} ${str(p['last_name'])}'.trim();
}

/// Adds the new comments of a poll to [out] and returns the highest comment id seen.
int _readComments(Map<String, dynamic> res, List<_LiveComment> out, int last) {
  final l = res['comments'];
  var max = last;
  if (l is List) {
    for (final c in l) {
      if (c is! Map) continue;
      final id = int.tryParse(str(c['id'])) ?? 0;
      if (id <= last) continue;
      if (id > max) max = id;
      final text = str(c['text']);
      if (text.isEmpty) continue;
      final pub = c['publisher'];
      out.add(_LiveComment(_commentName(pub), text,
          id: str(c['id']), userId: pub is Map ? str(pub['user_id']) : str(c['user_id'])));
    }
  }
  while (out.length > 40) {
    out.removeAt(0);
  }
  return max;
}

Widget _commentsList(List<_LiveComment> list,
    {void Function(_LiveComment)? onTap, Set<String> hidden = const {}}) {
  final vis = list.where((c) => !hidden.contains(c.userId)).toList();
  final shown = vis.length > 6 ? vis.sublist(vis.length - 6) : vis;
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisSize: MainAxisSize.min,
    children: [
      for (final c in shown)
        GestureDetector(
          onTap: onTap == null ? null : () => onTap(c),
          child: Container(
            margin: const EdgeInsets.only(bottom: 4),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration:
                BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(14)),
            child: Text.rich(TextSpan(children: [
              TextSpan(
                  text: '${c.name}  ',
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
              TextSpan(text: c.text, style: const TextStyle(color: Colors.white)),
            ])),
          ),
        ),
    ],
  );
}

void _liveSnack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
}

/// Tap on a comment: like it; the host can also hide / block the writer.
Future<void> _commentMenu(BuildContext context, _LiveComment c,
    {required bool host, required void Function(String userId) onHide}) async {
  final act = await showModalBottomSheet<String>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
            leading: const Icon(Icons.favorite, color: Colors.red),
            title: const Text('კომენტარის მოწონება'),
            onTap: () => Navigator.pop(ctx, 'like')),
        if (host && c.userId.isNotEmpty && c.userId != Api.userId) ...[
          ListTile(
              leading: const Icon(Icons.visibility_off),
              title: const Text('ამ ლაივში მისი კომენტარების დამალვა'),
              onTap: () => Navigator.pop(ctx, 'hide')),
          ListTile(
              leading: const Icon(Icons.block, color: Colors.red),
              title: const Text('მომხმარებლის დაბლოკვა'),
              onTap: () => Navigator.pop(ctx, 'block')),
        ],
      ]),
    ),
  );
  if (act == null || !context.mounted) return;
  try {
    if (act == 'like') {
      await Api.commentLike(c.id);
      if (context.mounted) _liveSnack(context, '❤️');
    } else if (act == 'hide') {
      onHide(c.userId);
    } else if (act == 'block') {
      await Api.blockUser(c.userId, true);
      onHide(c.userId);
      if (context.mounted) _liveSnack(context, '${c.name} დაბლოკილია');
    }
  } catch (e) {
    if (context.mounted) _liveSnack(context, '$e');
  }
}

class _FloatEmoji extends StatelessWidget {
  final String emoji;
  final double dx;
  final VoidCallback onDone;
  const _FloatEmoji({super.key, required this.emoji, required this.dx, required this.onDone});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 1800),
      onEnd: onDone,
      builder: (_, t, __) => Positioned(
        right: 60 + dx,
        bottom: 150 + 300 * t,
        child: IgnorePointer(
            child: Opacity(opacity: 1 - t, child: Text(emoji, style: const TextStyle(fontSize: 34)))),
      ),
    );
  }
}

Widget _liveBadge(int viewers) {
  return Row(mainAxisSize: MainAxisSize.min, children: [
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(6)),
      child: const Text('LIVE',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
    ),
    const SizedBox(width: 8),
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.visibility, size: 14, color: Colors.white),
        const SizedBox(width: 4),
        Text('$viewers', style: const TextStyle(color: Colors.white, fontSize: 12)),
      ]),
    ),
  ]);
}

// ---------------------------------------------------------------- broadcaster

class LiveHostScreen extends StatefulWidget {
  /// who may see the live video: everyone | friends | selected
  final String audience;
  final List<String> audienceIds;
  const LiveHostScreen({super.key, this.audience = 'everyone', this.audienceIds = const []});
  @override
  State<LiveHostScreen> createState() => _LiveHostScreenState();
}

class _LiveHostScreenState extends State<LiveHostScreen> {
  WebViewController? _web;
  String _postId = '';
  String _channel = '';
  String _token = '';
  int _viewers = 0;
  int _last = 0;
  final List<_LiveComment> _comments = [];
  bool _muted = false;
  bool _commentsOff = false;
  final Set<String> _hidden = {};
  bool _ending = false;
  bool _ready = false;
  String? _error;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _init();
  }

  void _fail(String m) {
    if (mounted && !_ending) setState(() => _error = m);
  }

  Future<void> _init() async {
    try {
      final st = await [Permission.camera, Permission.microphone].request();
      if (st.values.any((s) => !s.isGranted)) {
        _fail(t2(context, 'კამერისა და მიკროფონის ნებართვაა საჭირო', 'Camera and microphone permission is required'));
        return;
      }
      final res = await Api.liveStart(audience: widget.audience, ids: widget.audienceIds);
      final appId = '${res['app_id']}';
      _channel = '${res['channel']}';
      _token = '${res['token'] ?? ''}';
      CallNative.setCallActive(true, name: 'LIVE', video: true);
      final c = await _buildLiveWeb(
          {'site': Config.siteUrl, 'appId': appId, 'channel': _channel, 'token': _token, 'host': true},
          _onMsg);
      if (mounted) setState(() => _web = c);
    } catch (e) {
      _fail('$e');
    }
  }

  void _onMsg(String m) {
    if (!mounted || _ending) return;
    if (m == 'published') {
      _startLive();
    } else if (m.startsWith('error:')) {
      _fail(m.substring(6));
    }
  }

  Future<void> _startLive() async {
    if (_ready) return;
    _ready = true;
    try {
      _postId = await Api.liveCreate(_channel, _token);
      if (_postId.isEmpty) throw Exception('live post was not created');
      if (mounted) setState(() {});
      _poll = Timer.periodic(const Duration(seconds: 3), (_) => _tick());
      _tick();
      Future.delayed(const Duration(seconds: 2), _thumb);
    } catch (e) {
      _fail('$e');
    }
  }

  Future<void> _tick() async {
    if (_ending || _postId.isEmpty) return;
    try {
      final res = await Api.liveCheck(_postId, host: true, offset: _last);
      _viewers = int.tryParse(str(res['count'])) ?? _viewers;
      _last = _readComments(res, _comments, _last);
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _thumb() async {
    try {
      final r = await _web!.runJavaScriptReturningResult('window.thumb()');
      var s = r.toString();
      try {
        final d = jsonDecode(s);
        if (d is String) s = d;
      } catch (_) {
        s = s.replaceAll('"', '').replaceAll(r'\/', '/');
      }
      final i = s.indexOf(',');
      if (i < 0) return;
      final f = File('${Directory.systemTemp.path}/live_thumb.jpg');
      await f.writeAsBytes(base64Decode(s.substring(i + 1)));
      await Api.liveThumb(_postId, f.path);
    } catch (_) {}
  }

  Future<void> _finish() async {
    if (_ending) return;
    _ending = true;
    _poll?.cancel();
    CallNative.setCallActive(false);
    try {
      await _web?.runJavaScript('window.leave()');
    } catch (_) {}
    if (_postId.isNotEmpty) {
      try {
        await Api.liveEnd(_postId).timeout(const Duration(seconds: 8));
      } catch (_) {}
    }
  }

  Future<void> _confirmEnd() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t2(ctx, 'ეთერის დასრულება?', 'End live video?')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t2(ctx, 'არა', 'No'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(t2(ctx, 'დასრულება', 'End'))),
        ],
      ),
    );
    if (ok != true) return;
    await _finish();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _poll?.cancel();
    if (!_ending) {
      _ending = true;
      CallNative.setCallActive(false);
      _web?.runJavaScript('window.leave()');
      if (_postId.isNotEmpty) Api.liveEnd(_postId).catchError((Object _) {});
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmEnd();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(children: [
          if (_web != null) Positioned.fill(child: WebViewWidget(controller: _web!)),
          if (_error != null)
            Positioned.fill(
              child: Container(
                color: Colors.black,
                padding: const EdgeInsets.all(24),
                child: Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.error_outline, color: Colors.white70, size: 48),
                    const SizedBox(height: 12),
                    Text(_error!,
                        textAlign: TextAlign.center, style: const TextStyle(color: Colors.white)),
                    const SizedBox(height: 16),
                    FilledButton(
                        onPressed: () async {
                          await _finish();
                          if (mounted) Navigator.of(context).pop();
                        },
                        child: Text(t2(context, 'დახურვა', 'Close'))),
                  ]),
                ),
              ),
            ),
          if (_error == null && _postId.isEmpty)
            const Positioned.fill(child: Center(child: CircularProgressIndicator())),
          if (_error == null && _postId.isNotEmpty) ...[
            Positioned(left: 16, top: 48, child: _liveBadge(_viewers)),
            Positioned(
                left: 12,
                right: 12,
                bottom: 110,
                child: _commentsList(_comments,
                    hidden: _hidden,
                    onTap: (c) => _commentMenu(context, c,
                        host: true, onHide: (u) => setState(() => _hidden.add(u))))),
            Positioned(
              left: 0,
              right: 0,
              bottom: 36,
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                _roundButton(_muted ? Icons.mic_off : Icons.mic, Colors.white24, () async {
                  setState(() => _muted = !_muted);
                  await _web?.runJavaScript('window.mute($_muted)');
                }),
                _roundButton(Icons.cameraswitch, Colors.white24, () async {
                  await _web?.runJavaScript('window.flip()');
                }),
                _roundButton(_commentsOff ? Icons.comments_disabled : Icons.chat_bubble_outline,
                    _commentsOff ? Colors.orange : Colors.white24, () async {
                  try {
                    await Api.postDisableComments(_postId);
                    if (mounted) setState(() => _commentsOff = !_commentsOff);
                    if (mounted) {
                      _liveSnack(context, _commentsOff ? 'კომენტარები გამორთულია' : 'კომენტარები ჩართულია');
                    }
                  } catch (e) {
                    if (mounted) _liveSnack(context, '$e');
                  }
                }),
                _roundButton(Icons.stop, Colors.red, _confirmEnd),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}

Widget _roundButton(IconData icon, Color color, VoidCallback onTap) {
  return InkWell(
    onTap: onTap,
    customBorder: const CircleBorder(),
    child: Container(
      width: 64,
      height: 64,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      child: Icon(icon, color: Colors.white, size: 30),
    ),
  );
}

// -------------------------------------------------------------------- viewer

class LiveWatchScreen extends StatefulWidget {
  final Map<String, dynamic> live;
  const LiveWatchScreen({super.key, required this.live});
  @override
  State<LiveWatchScreen> createState() => _LiveWatchScreenState();
}

class _LiveWatchScreenState extends State<LiveWatchScreen> {
  WebViewController? _web;
  Timer? _poll;
  final _input = TextEditingController();
  final List<_LiveComment> _comments = [];
  int _viewers = 0;
  int _last = 0;
  int _offlinePolls = 0;
  bool _playing = false;
  bool _ended = false;
  String? _error;
  final List<(Key, String, double)> _floats = [];
  int _floatSeq = 0;

  String get _postId => str(widget.live['post_id']);

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final c = await _buildLiveWeb({
        'site': Config.siteUrl,
        'appId': str(widget.live['app_id']),
        'channel': str(widget.live['stream_name']),
        'token': str(widget.live['token']),
        'host': false,
      }, _onMsg);
      if (mounted) setState(() => _web = c);
      _poll = Timer.periodic(const Duration(seconds: 4), (_) => _tick());
      _tick();
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  void _onMsg(String m) {
    if (!mounted) return;
    if (m == 'playing') {
      setState(() => _playing = true);
    } else if (m == 'hostleft') {
      _over();
    } else if (m.startsWith('error:')) {
      setState(() => _error = m.substring(6));
    }
  }

  Future<void> _tick() async {
    if (_ended) return;
    try {
      final res = await Api.liveCheck(_postId, host: false, offset: _last);
      _viewers = int.tryParse(str(res['count'])) ?? _viewers;
      _last = _readComments(res, _comments, _last);
      if (str(res['still_live']) == 'offline') {
        _offlinePolls++;
        if (_offlinePolls >= 3) {
          _over();
          return;
        }
      } else {
        _offlinePolls = 0;
      }
      if (mounted) setState(() {});
    } catch (_) {
      // "live ended" comes back as an API error
      _over();
    }
  }

  void _over() {
    if (_ended || !mounted) return;
    _ended = true;
    _poll?.cancel();
    setState(() {});
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) Navigator.of(context).maybePop();
    });
  }

  Future<void> _send() async {
    final t = _input.text.trim();
    if (t.isEmpty) return;
    _input.clear();
    try {
      await Api.liveComment(_postId, t);
      _tick();
    } catch (e) {
      if (mounted) _liveSnack(context, '$e');
    }
  }

  static const _reactions = ['👍', '❤️', '😂', '😮', '😢', '😡'];

  Future<void> _react(int i) async {
    final key = ValueKey('f${_floatSeq++}');
    setState(() => _floats.add((key, _reactions[i], (_floatSeq % 5) * 14.0)));
    try {
      await Api.postReaction(_postId, i + 1);
    } catch (_) {}
  }

  @override
  void dispose() {
    _poll?.cancel();
    _input.dispose();
    _web?.runJavaScript('window.leave()');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = str(widget.live['name']);
    return Scaffold(
      backgroundColor: Colors.black,
      resizeToAvoidBottomInset: false,
      body: Stack(children: [
        if (_web != null) Positioned.fill(child: WebViewWidget(controller: _web!)),
        if (!_playing || _ended || _error != null)
          Positioned.fill(
            child: Container(
              color: Colors.black,
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Avatar(url: str(widget.live['avatar']), name: name, radius: 44),
                  const SizedBox(height: 14),
                  Text(name, style: const TextStyle(color: Colors.white, fontSize: 22)),
                  const SizedBox(height: 10),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Text(_error!,
                          textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                    )
                  else if (_ended)
                    Text(t2(context, 'ეთერი დასრულდა', 'The live video has ended'),
                        style: const TextStyle(color: Colors.white70))
                  else
                    const CircularProgressIndicator(),
                ]),
              ),
            ),
          ),
        Positioned(
          left: 12,
          top: 44,
          right: 12,
          child: Row(children: [
            Avatar(url: str(widget.live['avatar']), name: name, radius: 16),
            const SizedBox(width: 8),
            Expanded(
                child: Text(name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        shadows: [Shadow(color: Colors.black87, blurRadius: 6)]))),
            _liveBadge(_viewers),
            IconButton(
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: () => Navigator.of(context).maybePop()),
          ]),
        ),
        Positioned(
            left: 12,
            right: 64,
            bottom: 78 + MediaQuery.of(context).viewInsets.bottom,
            child: _commentsList(_comments,
                onTap: (c) => _commentMenu(context, c, host: false, onHide: (_) {}))),
        Positioned(
          right: 8,
          bottom: 78 + MediaQuery.of(context).viewInsets.bottom,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < _reactions.length; i++)
              GestureDetector(
                onTap: () => _react(i),
                child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Text(_reactions[i], style: const TextStyle(fontSize: 26))),
              ),
          ]),
        ),
        for (final f in _floats)
          _FloatEmoji(
              key: f.$1,
              emoji: f.$2,
              dx: f.$3,
              onDone: () {
                if (mounted) setState(() => _floats.removeWhere((x) => x.$1 == f.$1));
              }),
        Positioned(
          left: 12,
          right: 12,
          bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _input,
                style: const TextStyle(color: Colors.white),
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: t2(context, 'დაწერე კომენტარი...', 'Write a comment...'),
                  hintStyle: const TextStyle(color: Colors.white54),
                  isDense: true,
                  filled: true,
                  fillColor: Colors.black45,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                ),
              ),
            ),
            IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: _send),
          ]),
        ),
      ]),
    );
  }
}

// ------------------------------------------------------------ list of live now

/// "Live now" row for the People tab: everybody who is live + a "Go live" button.
class LiveStrip extends StatefulWidget {
  /// compact: shown only while somebody is live (used on the chats page).
  final bool compact;
  const LiveStrip({super.key, this.compact = false});
  @override
  State<LiveStrip> createState() => _LiveStripState();
}

class _LiveStripState extends State<LiveStrip> {
  List<Map<String, dynamic>> _lives = [];
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 8), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final l = await Api.liveList();
      if (mounted) setState(() => _lives = l);
    } catch (_) {}
  }

  Future<void> _goLive() async {
    final mode = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(t2(ctx, 'ვინ ნახავს შენს ლაივს?', 'Who can watch your live video?'),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          ListTile(
            leading: const Icon(Icons.public),
            title: Text(t2(ctx, 'ყველა', 'Everyone')),
            onTap: () => Navigator.pop(ctx, 'everyone'),
          ),
          ListTile(
            leading: const Icon(Icons.people_outline),
            title: Text(t2(ctx, 'მხოლოდ მეგობრები', 'Friends only')),
            subtitle: Text(t2(ctx, 'ვისაც ადევნებ თვალს ან შენზე არიან გამოწერილი',
                'People you follow or who follow you')),
            onTap: () => Navigator.pop(ctx, 'friends'),
          ),
          ListTile(
            leading: const Icon(Icons.person_add_alt_1_outlined),
            title: Text(t2(ctx, 'შერჩეული ადამიანები', 'Selected people')),
            onTap: () => Navigator.pop(ctx, 'selected'),
          ),
        ]),
      ),
    );
    if (mode == null || !mounted) return;
    var ids = <String>[];
    if (mode == 'selected') {
      final picked = await Navigator.of(context).push<List<Map<String, dynamic>>>(MaterialPageRoute(
          builder: (_) => UserPickerScreen(title: t2(context, 'აირჩიე ვინ ნახავს', 'Choose who can watch'))));
      if (picked == null || picked.isEmpty || !mounted) return;
      ids = picked.map((u) => str(u['user_id'])).where((e) => e.isNotEmpty).toList();
    }
    if (!mounted) return;
    await Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => LiveHostScreen(audience: mode, audienceIds: ids)));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.compact && _lives.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 12, 0),
        child: Row(children: [
          Text(t2(context, 'ლაივი', 'Live'),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const Spacer(),
          if (!widget.compact)
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: _goLive,
            icon: const Icon(Icons.sensors, size: 18),
            label: Text(t2(context, 'ეთერში გასვლა', 'Go live')),
          ),
        ]),
      ),
      if (_lives.isNotEmpty)
        SizedBox(
          height: 104,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(12, 8, 4, 4),
            children: [
              for (final l in _lives)
                GestureDetector(
                  onTap: () async {
                    await Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => LiveWatchScreen(live: l)));
                    _load();
                  },
                  child: Container(
                    width: 76,
                    margin: const EdgeInsets.only(right: 8),
                    child: Column(children: [
                      Stack(clipBehavior: Clip.none, children: [
                        Container(
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.red, width: 3)),
                          child: Avatar(url: str(l['avatar']), name: str(l['name']), radius: 26),
                        ),
                        Positioned(
                          bottom: -4,
                          left: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                                color: Colors.red, borderRadius: BorderRadius.circular(4)),
                            child: const Text('LIVE',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 8),
                      Text(str(l['name']),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12)),
                    ]),
                  ),
                ),
            ],
          ),
        ),
    ]);
  }
}
