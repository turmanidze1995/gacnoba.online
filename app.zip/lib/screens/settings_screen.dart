import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../api.dart';
import '../call_watcher.dart';
import '../i18n.dart';
import '../lang_picker.dart';
import '../utils.dart';
import 'diagnostics_screen.dart';
import 'login_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic> _me = Api.me;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    try {
      await Api.loadAdmin();
    } catch (_) {}
    if (mounted) setState(() => _me = Api.me);
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _changePhoto() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (x == null) return;
    try {
      await Api.updateAvatar(x.path);
      await _refresh();
      _snack(context.tr('saved'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _editProfile() async {
    final first = TextEditingController(text: str(_me['first_name']));
    final last = TextEditingController(text: str(_me['last_name']));
    final about = TextEditingController(text: str(_me['about']));
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('edit_profile')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: first, decoration: InputDecoration(labelText: ctx.tr('first_name'))),
            TextField(controller: last, decoration: InputDecoration(labelText: ctx.tr('last_name'))),
            TextField(
                controller: about,
                maxLines: 3,
                decoration: InputDecoration(labelText: ctx.tr('about'))),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.updateProfile(
          first: first.text.trim(), last: last.text.trim(), about: about.text.trim());
      await _refresh();
      _snack(context.tr('saved'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _changePassword() async {
    final cur = TextEditingController();
    final next = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('change_password')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: cur,
              obscureText: true,
              decoration: InputDecoration(labelText: ctx.tr('current_password'))),
          TextField(
              controller: next,
              obscureText: true,
              decoration: InputDecoration(labelText: ctx.tr('new_password'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.changePassword(cur.text, next.text);
      _snack(context.tr('saved'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _logout() async {
    CallWatcher.stop();
    await Api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
  }

  @override
  Widget build(BuildContext context) {
    final name = displayName(_me);
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('settings'))),
      body: ListView(children: [
        const SizedBox(height: 16),
        Center(
          child: InkWell(
            onTap: _changePhoto,
            child: Stack(children: [
              Avatar(url: str(_me['avatar']), name: name.isEmpty ? '?' : name, radius: 48),
              Positioned(
                right: 0,
                bottom: 0,
                child: CircleAvatar(
                  radius: 14,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 10),
        Center(child: Text(name, style: Theme.of(context).textTheme.titleLarge)),
        if (str(_me['username']).isNotEmpty)
          Center(child: Text('@${str(_me['username'])}', style: const TextStyle(color: Colors.black54))),
        const SizedBox(height: 12),
        const Divider(),
        ListTile(
            leading: const Icon(Icons.person_outline),
            title: Text(context.tr('edit_profile')),
            onTap: _editProfile),
        ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: Text(context.tr('change_photo')),
            onTap: _changePhoto),
        ListTile(
            leading: const Icon(Icons.lock_outline),
            title: Text(context.tr('change_password')),
            onTap: _changePassword),
        ListTile(
            leading: const Icon(Icons.language),
            title: Text(context.tr('language')),
            onTap: () => showLanguagePicker(context)),
        ListTile(
            leading: const Icon(Icons.block),
            title: Text(context.tr('blocked_users')),
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute<void>(builder: (_) => const BlockedUsersScreen()))),
        if (Api.isAdmin)
          ListTile(
              leading: const Icon(Icons.bug_report_outlined),
              title: Text(context.tr('diagnostics')),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => const DiagnosticsScreen()))),
        const Divider(),
        ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text(context.tr('logout'), style: const TextStyle(color: Colors.red)),
            onTap: _logout),
      ]),
    );
  }
}

class BlockedUsersScreen extends StatefulWidget {
  const BlockedUsersScreen({super.key});
  @override
  State<BlockedUsersScreen> createState() => _BlockedUsersScreenState();
}

class _BlockedUsersScreenState extends State<BlockedUsersScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.getBlockedUsers();
      if (mounted) setState(() => _users = l);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('blocked_users'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _users.isEmpty
              ? Center(child: Text(context.tr('no_blocked')))
              : ListView(children: [
                  for (final u in _users)
                    ListTile(
                      leading: Avatar(url: str(u['avatar']), name: displayName(u)),
                      title: Text(displayName(u)),
                      trailing: TextButton(
                        onPressed: () async {
                          try {
                            await Api.blockUser(str(u['user_id']), false);
                            _load();
                          } catch (_) {}
                        },
                        child: Text(context.tr('unblock_user')),
                      ),
                    ),
                ]),
    );
  }
}
