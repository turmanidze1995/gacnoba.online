import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import '../api.dart';
import '../app_lock.dart';
import '../call_log.dart';
import '../call_native.dart';
import '../call_watcher.dart';
import '../prefs.dart';
import '../i18n.dart';
import '../lang_picker.dart';
import '../utils.dart';
import 'admin_screen.dart';
import 'login_screen.dart';
import 'privacy_screen.dart';
import 'sounds_screen.dart';
import '../updater.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic> _me = Api.me;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    try {
      await Api.loadAdmin();
    } catch (_) {}
    if (mounted) setState(() => _me = Api.me);
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _changePhoto() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (x == null) return;
    try {
      final before = str(Api.me['avatar']);
      await Api.updateAvatar(x.path);
      PaintingBinding.instance.imageCache.clear();
      PaintingBinding.instance.imageCache.clearLiveImages();
      await _refresh();
      if (before.isNotEmpty && str(Api.me['avatar']) == before) {
        _snack('სერვერმა ფოტო ვერ შეცვალა (ძველი დარჩა). სცადე სხვა სურათი ან შეამოწმე ატვირთვის ლიმიტი.');
      } else {
        _snack(context.tr('saved'));
      }
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _editProfile() async {
    final first = TextEditingController(text: str(_me['first_name']));
    final last = TextEditingController(text: str(_me['last_name']));
    final about = TextEditingController(text: str(_me['about']));
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('edit_profile')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: first, decoration: InputDecoration(labelText: ctx.tr('first_name'))),
            TextField(controller: last, decoration: InputDecoration(labelText: ctx.tr('last_name'))),
            TextField(
                controller: about,
                maxLines: 3,
                decoration: InputDecoration(labelText: ctx.tr('about'))),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.updateProfile(
          first: first.text.trim(), last: last.text.trim(), about: about.text.trim());
      await _refresh();
      _snack(context.tr('saved'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _changePassword() async {
    final cur = TextEditingController();
    final next = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('change_password')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: cur,
              obscureText: true,
              decoration: InputDecoration(labelText: ctx.tr('current_password'))),
          TextField(
              controller: next,
              obscureText: true,
              decoration: InputDecoration(labelText: ctx.tr('new_password'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.changePassword(cur.text, next.text);
      _snack(context.tr('saved'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  String _themeLabel() {
    switch (AppPrefs.themeMode.value) {
      case ThemeMode.dark:
        return t2(context, 'მუქი (შავი)', 'Dark (black)');
      case ThemeMode.light:
        return t2(context, 'ღია', 'Light');
      case ThemeMode.system:
        return t2(context, 'სისტემის მიხედვით', 'Follow system');
    }
  }

  Future<void> _pickTheme() async {
    final v = await showModalBottomSheet<ThemeMode>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          for (final m in const [ThemeMode.system, ThemeMode.light, ThemeMode.dark])
            ListTile(
              leading: Icon(m == ThemeMode.dark
                  ? Icons.dark_mode
                  : (m == ThemeMode.light ? Icons.light_mode : Icons.brightness_auto)),
              title: Text(m == ThemeMode.dark
                  ? t2(ctx, 'მუქი (შავი ღამის თემა)', 'Dark (black night theme)')
                  : (m == ThemeMode.light
                      ? t2(ctx, 'ღია', 'Light')
                      : t2(ctx, 'სისტემის მიხედვით', 'Follow system'))),
              trailing: AppPrefs.themeMode.value == m ? const Icon(Icons.check) : null,
              onTap: () => Navigator.pop(ctx, m),
            ),
        ]),
      ),
    );
    if (v == null) return;
    await AppPrefs.setThemeMode(v);
    if (mounted) setState(() {});
  }

  Future<bool> _confirm(String text) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('delete'))),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _clearAllChats() async {
    if (!await _confirm(t2(context, 'წაიშალოს ყველა ჩატის მიმოწერა? ამის გაუქმება შეუძლებელია.',
        'Delete the messages of ALL chats? This cannot be undone.'))) {
      return;
    }
    _snack(t2(context, 'მიმდინარეობს გასუფთავება...', 'Clearing...'));
    try {
      final res = await Api.getChats(limit: '300');
      final ids = ((res['data'] as List?) ?? [])
          .whereType<Map>()
          .where((c) => str(c['chat_type']).isEmpty || c['chat_type'] == 'user')
          .map((c) => str(c['user_id']))
          .where((id) => id.isNotEmpty)
          .toList();
      var n = 0;
      for (final id in ids) {
        try {
          await Api.deleteConversation(id);
          n++;
        } catch (_) {}
      }
      _snack(t2(context, 'გასუფთავდა: $n ჩატი', 'Cleared: $n chats'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _clearNotifications() async {
    try {
      await OneSignal.Notifications.clearAll();
    } catch (_) {}
    await CallNative.stopRing();
    _snack(t2(context, 'შეტყობინებები გასუფთავდა', 'Notifications cleared'));
  }

  Future<void> _clearMenu() async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.delete_sweep_outlined, color: Colors.red),
            title: Text(t2(ctx, 'ყველა ჩატის გასუფთავება', 'Clear all chats')),
            onTap: () {
              Navigator.pop(ctx);
              _clearAllChats();
            },
          ),
          ListTile(
            leading: const Icon(Icons.notifications_off_outlined),
            title: Text(t2(ctx, 'შეტყობინებების გასუფთავება', 'Clear notifications')),
            onTap: () {
              Navigator.pop(ctx);
              _clearNotifications();
            },
          ),
          ListTile(
            leading: const Icon(Icons.call_missed_outgoing),
            title: Text(t2(ctx, 'ზარების ისტორიის გასუფთავება', 'Clear call history')),
            onTap: () {
              Navigator.pop(ctx);
              CallLog.clear();
              _snack(t2(context, 'გასუფთავდა', 'Cleared'));
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _logout() async {
    CallWatcher.stop();
    await Api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
  }

  @override
  Widget build(BuildContext context) {
    final name = displayName(_me);
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('settings'))),
      body: ListView(children: [
        const SizedBox(height: 16),
        Center(
          child: InkWell(
            onTap: _changePhoto,
            child: Stack(children: [
              Avatar(url: str(_me['avatar']), name: name.isEmpty ? '?' : name, radius: 48),
              Positioned(
                right: 0,
                bottom: 0,
                child: CircleAvatar(
                  radius: 14,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 10),
        Center(child: Text(name, style: Theme.of(context).textTheme.titleLarge)),
        if (str(_me['username']).isNotEmpty)
          Center(child: Text('@${str(_me['username'])}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant))),
        const SizedBox(height: 12),
        const Divider(),
        ListTile(
            leading: const Icon(Icons.person_outline),
            title: Text(context.tr('edit_profile')),
            onTap: _editProfile),
        ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: Text(context.tr('change_photo')),
            onTap: _changePhoto),
        ListTile(
            leading: const Icon(Icons.lock_outline),
            title: Text(context.tr('change_password')),
            onTap: _changePassword),
        ListTile(
            leading: const Icon(Icons.language),
            title: Text(context.tr('language')),
            onTap: () => showLanguagePicker(context)),
        ListTile(
            leading: const Icon(Icons.block),
            title: Text(context.tr('blocked_users')),
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute<void>(builder: (_) => const BlockedUsersScreen()))),
        const Divider(),
        ListTile(
            leading: const Icon(Icons.dark_mode_outlined),
            title: Text(t2(context, 'თემა', 'Theme')),
            subtitle: Text(_themeLabel()),
            onTap: _pickTheme),
        ListTile(
            leading: const Icon(Icons.privacy_tip_outlined),
            title: Text(t2(context, 'კონფიდენციალურობა', 'Privacy')),
            subtitle: Text(t2(context, 'ონლაინ სტატუსი, ვინ მომწერს', 'Online status, who can message me')),
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute<void>(builder: (_) => const PrivacyScreen()))),
        ListTile(
            leading: const Icon(Icons.fingerprint),
            title: Text(t2(context, 'აპის დაცვა', 'App lock')),
            subtitle: Text(AppLockService.enabled
                ? (AppLockService.mode == 'pin'
                    ? t2(context, 'PIN კოდი ჩართულია', 'PIN is on')
                    : t2(context, 'პატერნი ჩართულია', 'Pattern is on'))
                : t2(context, 'PIN, პატერნი, თითის ანაბეჭდი', 'PIN, pattern, fingerprint')),
            onTap: () async {
              await Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => const LockSettingsScreen()));
              if (mounted) setState(() {});
            }),
        ListTile(
            leading: const Icon(Icons.music_note_outlined),
            title: Text(t2(context, 'ხმები და მელოდიები', 'Sounds and ringtones')),
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute<void>(builder: (_) => const SoundsScreen()))),
        ListTile(
            leading: const Icon(Icons.system_update),
            title: Text(t2(context, 'განახლების შემოწმება', 'Check for updates')),
            onTap: () => Updater.check(context, manual: true)),
        ListTile(
            leading: const Icon(Icons.cleaning_services_outlined),
            title: Text(t2(context, 'გასუფთავება', 'Clear data')),
            subtitle: Text(t2(context, 'ჩატები, შეტყობინებები, ზარები', 'Chats, notifications, calls')),
            onTap: _clearMenu),
        if (Api.isAdmin)
          ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: Text(t2(context, 'საადმინო', 'Admin')),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => const AdminScreen()))),
        const Divider(),
        ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text(context.tr('logout'), style: const TextStyle(color: Colors.red)),
            onTap: _logout),
      ]),
    );
  }
}

class BlockedUsersScreen extends StatefulWidget {
  const BlockedUsersScreen({super.key});
  @override
  State<BlockedUsersScreen> createState() => _BlockedUsersScreenState();
}

class _BlockedUsersScreenState extends State<BlockedUsersScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.getBlockedUsers();
      if (mounted) setState(() => _users = l);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('blocked_users'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _users.isEmpty
              ? Center(child: Text(context.tr('no_blocked')))
              : ListView(children: [
                  for (final u in _users)
                    ListTile(
                      leading: Avatar(url: str(u['avatar']), name: displayName(u)),
                      title: Text(displayName(u)),
                      trailing: TextButton(
                        onPressed: () async {
                          try {
                            await Api.blockUser(str(u['user_id']), false);
                            _load();
                          } catch (_) {}
                        },
                        child: Text(context.tr('unblock_user')),
                      ),
                    ),
                ]),
    );
  }
}
