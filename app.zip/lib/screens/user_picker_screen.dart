import 'package:flutter/material.dart';
import '../api.dart';
import '../i18n.dart';
import '../utils.dart';

/// Multi-select list of people (your chats by default, search for others).
/// Pops the chosen users as a list of maps with user_id / name / avatar.
class UserPickerScreen extends StatefulWidget {
  final String title;
  const UserPickerScreen({super.key, required this.title});
  @override
  State<UserPickerScreen> createState() => _UserPickerScreenState();
}

class _UserPickerScreenState extends State<UserPickerScreen> {
  final _q = TextEditingController();
  List<Map<String, dynamic>> _users = [];
  final Map<String, Map<String, dynamic>> _picked = {};
  bool _busy = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadChats();
  }

  Map<String, dynamic> _slim(Map u) => {
        'user_id': str(u['user_id']),
        'name': displayName(u),
        'avatar': str(u['avatar']),
      };

  Future<void> _loadChats() async {
    try {
      final res = await Api.getChats();
      final list = ((res['data'] as List?) ?? [])
          .where((c) => c is Map && (str(c['chat_type']).isEmpty || c['chat_type'] == 'user'))
          .map((c) => _slim(c as Map))
          .toList();
      if (mounted) setState(() => _users = list);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _search() async {
    final q = _q.text.trim();
    if (q.isEmpty) {
      setState(() => _busy = true);
      await _loadChats();
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final res = await Api.searchUsers(q);
      final list = res.whereType<Map>().map(_slim).toList();
      if (mounted) setState(() => _users = list);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          TextButton(
            onPressed: _picked.isEmpty
                ? null
                : () => Navigator.of(context).pop(_picked.values.toList()),
            child: Text('${context.tr('done')} (${_picked.length})'),
          ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: TextField(
            controller: _q,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: context.tr('search_people'),
              prefixIcon: const Icon(Icons.search),
              border: const OutlineInputBorder(),
              isDense: true,
            ),
            onSubmitted: (_) => _search(),
          ),
        ),
        Expanded(
          child: _busy
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(child: Text(_error!))
                  : ListView.builder(
                      itemCount: _users.length,
                      itemBuilder: (_, i) {
                        final u = _users[i];
                        final id = str(u['user_id']);
                        return CheckboxListTile(
                          value: _picked.containsKey(id),
                          secondary: Avatar(url: str(u['avatar']), name: str(u['name'])),
                          title: Text(str(u['name'])),
                          onChanged: (v) => setState(() {
                            if (v == true) {
                              _picked[id] = u;
                            } else {
                              _picked.remove(id);
                            }
                          }),
                        );
                      },
                    ),
        ),
      ]),
    );
  }
}
