import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../call_native.dart';
import '../config.dart';
import '../prefs.dart';
import '../utils.dart';
import 'new_group_screen.dart';
import 'starred_screen.dart';

/// Messenger-like profile page of the person you chat with.
/// Pops with 'customize' or 'clear' when the chat screen has to do something.
class ChatInfoScreen extends StatefulWidget {
  final String userId;
  final String name;
  final String avatar;
  final String chatId;
  final bool muted;
  final List<Map<String, dynamic>> messages;
  const ChatInfoScreen({
    super.key,
    required this.userId,
    required this.name,
    required this.avatar,
    required this.chatId,
    required this.muted,
    required this.messages,
  });
  @override
  State<ChatInfoScreen> createState() => _ChatInfoScreenState();
}

class _ChatInfoScreenState extends State<ChatInfoScreen> {
  Map<String, dynamic> _user = {};
  late bool _muted = widget.muted;

  @override
  void initState() {
    super.initState();
    Api.getUserData(widget.userId).then((u) {
      if (mounted) setState(() => _user = u);
    }).catchError((Object _) {});
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  String get _username => str(_user['username']);
  String get _profileUrl => '${Config.siteUrl}/$_username';

  List<Map<String, dynamic>> get _media => widget.messages
      .where((m) => isImageUrl(str(m['media'])) || isVideoUrl(str(m['media'])))
      .toList()
      .reversed
      .toList();

  Widget _action(IconData icon, String label, VoidCallback? onTap) {
    final scheme = Theme.of(context).colorScheme;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: scheme.surfaceContainerHighest,
              child: Icon(icon, color: onTap == null ? scheme.outline : scheme.onSurface),
            ),
            const SizedBox(height: 6),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ),
    );
  }

  Widget _header(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 4),
        child: Text(text,
            style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurfaceVariant)),
      );

  Future<void> _toggleMute() async {
    if (widget.chatId.isEmpty) {
      _snack(t2(context, 'ჯერ დაწერეთ პირველი შეტყობინება', 'Send the first message first'));
      return;
    }
    try {
      await Api.muteChat(widget.chatId, notify: _muted ? 'yes' : 'no');
      if (mounted) setState(() => _muted = !_muted);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  Future<void> _openProfile() async {
    if (_username.isEmpty) return;
    await launchUrl(Uri.parse(_profileUrl), mode: LaunchMode.externalApplication);
  }

  Future<void> _block() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(t2(ctx, 'დაბლოკოთ ${widget.name}?', 'Block ${widget.name}?')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t2(ctx, 'გაუქმება', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(t2(ctx, 'დაბლოკვა', 'Block'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.blockUser(widget.userId, true);
      _snack(t2(context, 'მომხმარებელი დაიბლოკა', 'User blocked'));
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final online = str(_user['lastseen_status']) == 'on';
    final last = str(_user['lastseen_time_text']);
    final media = _media;
    final grid = media.take(6).toList();
    return Scaffold(
      appBar: AppBar(),
      body: ListView(children: [
        Center(child: Avatar(url: widget.avatar, name: widget.name, radius: 52)),
        const SizedBox(height: 12),
        Center(
          child: Text(widget.name,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall),
        ),
        if (_username.isNotEmpty)
          Center(
            child: Text('@$_username',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ),
        const SizedBox(height: 6),
        Center(
          child: Text(
            online
                ? t2(context, 'ონლაინ', 'Online')
                : (last.isNotEmpty ? last : ''),
            style: TextStyle(color: online ? Colors.green : null, fontSize: 13),
          ),
        ),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            _action(Icons.person_outline, t2(context, 'პროფილი', 'Profile'),
                _username.isEmpty ? null : _openProfile),
            _action(_muted ? Icons.notifications_off_outlined : Icons.notifications_none,
                _muted ? t2(context, 'ჩართვა', 'Unmute') : t2(context, 'გათიშვა', 'Mute'), _toggleMute),
            _action(Icons.palette_outlined, t2(context, 'მორგება', 'Customize'),
                () => Navigator.of(context).pop('customize')),
          ]),
        ),
        _header(t2(context, 'ჩატის ინფორმაცია', 'Chat info')),
        if (grid.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
              children: [for (final m in grid) _thumb(str(m['media']))],
            ),
          ),
        ListTile(
          leading: const Icon(Icons.photo_library_outlined),
          title: Text(t2(context, 'ყველა მედია, ფაილი და ბმული', 'All media, files and links')),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => MediaFilesScreen(messages: widget.messages))),
        ),
        if (widget.chatId.isNotEmpty)
          ListTile(
            leading: const Icon(Icons.star_border),
            title: Text(t2(context, 'ვარსკვლავიანი შეტყობინებები', 'Starred messages')),
            onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => StarredScreen(chatId: widget.chatId))),
          ),
        _header(t2(context, 'მოქმედებები', 'Actions')),
        SwitchListTile(
          secondary: Icon(_muted ? Icons.notifications_off_outlined : Icons.notifications_none),
          title: Text(t2(context, 'შეტყობინებები', 'Notifications')),
          subtitle: Text(_muted ? t2(context, 'გამორთულია', 'Off') : t2(context, 'ჩართულია', 'On')),
          value: !_muted,
          onChanged: (_) => _toggleMute(),
        ),
        ListTile(
          leading: const Icon(Icons.volume_up_outlined),
          title: Text(t2(context, 'შეტყობინებები და ხმები', 'Notifications and sounds')),
          onTap: CallNative.openNotificationSettings,
        ),
        ListTile(
          leading: const Icon(Icons.groups_outlined),
          title: Text(t2(context, 'ჯგუფის შექმნა ${widget.name}-თან ერთად', 'Create a group with ${widget.name}')),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => NewGroupScreen(initial: [
                    {
                      'user_id': widget.userId,
                      'name': widget.name,
                      'avatar': widget.avatar,
                      'username': _username,
                    }
                  ]))),
        ),
        ListTile(
          leading: const Icon(Icons.share_outlined),
          title: Text(t2(context, 'კონტაქტის გაზიარება', 'Share contact')),
          subtitle: _username.isEmpty ? null : Text(_profileUrl),
          onTap: _username.isEmpty
              ? null
              : () {
                  Clipboard.setData(ClipboardData(text: _profileUrl));
                  _snack(t2(context, 'ბმული დაკოპირდა', 'Link copied'));
                },
        ),
        _header(t2(context, 'კონფიდენციალურობა', 'Privacy')),
        SwitchListTile(
          secondary: const Icon(Icons.more_horiz),
          title: Text(t2(context, 'ბეჭდვის ინდიკატორი', 'Typing indicator')),
          subtitle: Text(t2(context, 'სხვა ხედავს, რომ წერთ', 'Others see when you type')),
          value: AppPrefs.typingIndicator,
          onChanged: (v) async {
            await AppPrefs.setTypingIndicator(v);
            if (mounted) setState(() {});
          },
        ),
        ListTile(
          leading: const Icon(Icons.block, color: Colors.red),
          title: Text(t2(context, 'დაბლოკვა', 'Block'), style: const TextStyle(color: Colors.red)),
          onTap: _block,
        ),
        ListTile(
          leading: const Icon(Icons.delete_outline, color: Colors.red),
          title: Text(t2(context, 'ჩატის გასუფთავება', 'Clear chat'),
              style: const TextStyle(color: Colors.red)),
          onTap: () => Navigator.of(context).pop('clear'),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }

  Widget _thumb(String url) {
    final video = isVideoUrl(url);
    return GestureDetector(
      onTap: () => _openMedia(context, url),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: video
            ? Container(
                color: Colors.black54,
                child: const Center(child: Icon(Icons.play_circle_outline, color: Colors.white, size: 36)),
              )
            : Image.network(url,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
      ),
    );
  }
}

void _openMedia(BuildContext context, String url) {
  if (isImageUrl(url)) {
    showDialog<void>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: InteractiveViewer(child: Image.network(url)),
      ),
    );
  } else {
    launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }
}

/// Media / files / links found in the loaded part of the conversation.
class MediaFilesScreen extends StatelessWidget {
  final List<Map<String, dynamic>> messages;
  const MediaFilesScreen({super.key, required this.messages});

  @override
  Widget build(BuildContext context) {
    final media = <String>[];
    final files = <String>[];
    final links = <String>[];
    final urlRe = RegExp(r'https?://[^\s]+');
    for (final m in messages.reversed) {
      final u = str(m['media']);
      if (u.isNotEmpty) {
        if (isImageUrl(u) || isVideoUrl(u)) {
          media.add(u);
        } else if (!isAudioUrl(u)) {
          files.add(u);
        }
      }
      for (final x in urlRe.allMatches(str(m['_text']))) {
        final l = x.group(0) ?? '';
        if (l.isNotEmpty && !links.contains(l)) links.add(l);
      }
    }
    String fileName(String u) {
      final p = u.split('?').first.split('/').last;
      return p.isEmpty ? u : p;
    }

    Widget empty() => Center(child: Text(t2(context, 'ცარიელია', 'Nothing here')));
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(t2(context, 'მედია, ფაილები, ბმულები', 'Media, files, links')),
          bottom: TabBar(tabs: [
            Tab(text: t2(context, 'მედია', 'Media')),
            Tab(text: t2(context, 'ფაილები', 'Files')),
            Tab(text: t2(context, 'ბმულები', 'Links')),
          ]),
        ),
        body: TabBarView(children: [
          media.isEmpty
              ? empty()
              : GridView.count(
                  crossAxisCount: 3,
                  mainAxisSpacing: 3,
                  crossAxisSpacing: 3,
                  padding: const EdgeInsets.all(3),
                  children: [
                    for (final u in media)
                      GestureDetector(
                        onTap: () => _openMedia(context, u),
                        child: isVideoUrl(u)
                            ? Container(
                                color: Colors.black54,
                                child: const Center(
                                    child: Icon(Icons.play_circle_outline, color: Colors.white, size: 36)),
                              )
                            : Image.network(u,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
                      ),
                  ],
                ),
          files.isEmpty
              ? empty()
              : ListView(children: [
                  for (final u in files)
                    ListTile(
                      leading: const Icon(Icons.insert_drive_file_outlined),
                      title: Text(fileName(u), maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication),
                    ),
                ]),
          links.isEmpty
              ? empty()
              : ListView(children: [
                  for (final u in links)
                    ListTile(
                      leading: const Icon(Icons.link),
                      title: Text(u, maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication),
                    ),
                ]),
        ]),
      ),
    );
  }
}
