/// All settings of the app are here.
class Config {
  static const String siteUrl = 'https://gacnoba.online';

  /// admin-cp > Manage API Server Keys > Server Key (API v2)
  static const String serverKey = '474efe573b1fcd0ab554996e531a6d16';

  /// OneSignal App ID (push notifications). Replace the text below with the real
  /// App ID (looks like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
  static const String oneSignalAppId = 'd14cf286-5d3a-4f03-922c-30df29fa26f1';

  /// Google "Web application" OAuth client ID (the same one the site uses for
  /// Google login, admin-cp > Social Login Settings > Google App ID).
  static const String googleWebClientId = 'PASTE_GOOGLE_WEB_CLIENT_ID_HERE';

  /// config.php > $siteEncryptKey. The API returns the site settings encrypted with it.
  static const String siteEncryptKey = 'd859e7368db243914f3a95530ba97982e9e95380';

  /// Optional. If empty the app uses the Giphy key saved in the site admin panel.
  /// Free key from https://developers.giphy.com (enables the GIF button).
  static const String giphyApiKey = '420d477a542b4287b2bf91ac134ae041';

  /// Agora App ID (public identifier, the same one that is in admin-cp). The
  /// App Certificate is a secret and stays on the server only.
  static const String agoraAppId = '267d68c8f67b405da6c170955852b946';

  static const String appName = 'GACNOBA.ONLINE';
}
