/// All settings of the app are here.
class Config {
  static const String siteUrl = 'https://gacnoba.online';

  /// admin-cp > Manage API Server Keys > Server Key (API v2)
  static const String serverKey = '474efe573b1fcd0ab554996e531a6d16';

  /// OneSignal App ID (push notifications). Replace the text below with the real
  /// App ID (looks like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx). Until then the app
  /// works without push notifications.
  static const String oneSignalAppId = 'PASTE_ONESIGNAL_APP_ID_HERE';

  static const String appName = 'Gacnoba';
}
