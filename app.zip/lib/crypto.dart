import 'dart:typed_data';
import 'dart:convert';
import 'package:encrypt/encrypt.dart';

/// The WoWonder API returns message text encrypted with
/// openssl_encrypt($text, "AES-128-ECB", $time). The key is the message time,
/// zero-padded / truncated to 16 bytes (OpenSSL behaviour).
String decryptText(dynamic text, dynamic time) {
  final raw = text == null ? '' : text.toString();
  if (raw.isEmpty) return '';
  try {
    final keyBytes = Uint8List(16);
    final t = utf8.encode(time.toString());
    for (var i = 0; i < t.length && i < 16; i++) {
      keyBytes[i] = t[i];
    }
    final encrypter = Encrypter(AES(Key(keyBytes), mode: AESMode.ecb));
    return encrypter.decrypt(Encrypted.fromBase64(raw));
  } catch (_) {
    return raw;
  }
}

/// Decrypts a base64 AES-128-ECB text with a plain string key (used for the
/// encrypted site settings returned by the API). Returns null on failure.
String? tryDecryptWithKey(String cipherB64, String key) {
  try {
    final keyBytes = Uint8List(16);
    final t = utf8.encode(key);
    for (var i = 0; i < t.length && i < 16; i++) {
      keyBytes[i] = t[i];
    }
    final encrypter = Encrypter(AES(Key(keyBytes), mode: AESMode.ecb));
    return encrypter.decrypt(Encrypted.fromBase64(cipherB64));
  } catch (_) {
    return null;
  }
}
