import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'utils.dart';

// ---------------------------------------------------------------------------
// Hidden payload inside a normal text message.
// The chat theme is shared with the other person by sending a normal message
// ("🎨 ...") that carries the theme as invisible zero-width characters. The app
// hides that message and applies the theme, so both people see the same colors.
// ---------------------------------------------------------------------------
const String _marker = '⁣';
const String _z0 = '​';
const String _z1 = '‌';

String encodeHidden(String s) {
  final sb = StringBuffer();
  for (final b in utf8.encode(s)) {
    for (var i = 7; i >= 0; i--) {
      sb.write(((b >> i) & 1) == 1 ? _z1 : _z0);
    }
  }
  return sb.toString();
}

String? decodeHidden(String text) {
  final i = text.indexOf(_marker);
  if (i < 0) return null;
  final bits = StringBuffer();
  for (final r in text.substring(i + 1).runes) {
    final c = String.fromCharCode(r);
    if (c == _z0) {
      bits.write('0');
    } else if (c == _z1) {
      bits.write('1');
    }
  }
  final b = bits.toString();
  if (b.isEmpty || b.length % 8 != 0) return null;
  final bytes = <int>[];
  for (var k = 0; k < b.length; k += 8) {
    bytes.add(int.parse(b.substring(k, k + 8), radix: 2));
  }
  try {
    return utf8.decode(bytes);
  } catch (_) {
    return null;
  }
}

/// Text without the hidden payload (what a person would read).
String stripHidden(String text) {
  final i = text.indexOf(_marker);
  final visible = i < 0 ? text : text.substring(0, i);
  return visible.replaceAll(_z0, '').replaceAll(_z1, '');
}

class ChatTheme {
  /// '' = default, 'c' = color, 'g' = gradient, 'i' = photo
  final String bgKind;
  final List<int> bg;
  final String image;

  /// my message bubbles: empty = default, 1 color = solid, 2+ = gradient
  final List<int> bubble;
  const ChatTheme({this.bgKind = '', this.bg = const [], this.image = '', this.bubble = const []});

  static const ChatTheme none = ChatTheme();

  bool get isEmpty => bgKind.isEmpty && bubble.isEmpty;

  ChatTheme copyWith({String? bgKind, List<int>? bg, String? image, List<int>? bubble}) =>
      ChatTheme(
        bgKind: bgKind ?? this.bgKind,
        bg: bg ?? this.bg,
        image: image ?? this.image,
        bubble: bubble ?? this.bubble,
      );

  Map<String, dynamic> toJson() => {'gt': 1, 'k': bgKind, 'c': bg, 'i': image, 'b': bubble};

  static ChatTheme fromJson(Map j) {
    List<int> ints(dynamic v) =>
        v is List ? v.map((e) => int.tryParse(e.toString()) ?? 0).toList() : <int>[];
    return ChatTheme(
      bgKind: str(j['k']),
      bg: ints(j['c']),
      image: str(j['i']),
      bubble: ints(j['b']),
    );
  }

  String toMessage(String visible) => '$visible$_marker${encodeHidden(jsonEncode(toJson()))}';

  /// Theme carried by a message text, or null when the message is a normal one.
  static ChatTheme? fromMessageText(String raw) {
    final s = decodeHidden(raw);
    if (s == null) return null;
    try {
      final j = jsonDecode(s);
      if (j is Map && j['gt'] != null) return fromJson(j);
    } catch (_) {}
    return null;
  }

  String get signature => jsonEncode(toJson());

  Decoration? get bgDecoration {
    switch (bgKind) {
      case 'c':
        if (bg.isEmpty) return null;
        return BoxDecoration(color: Color(bg.first));
      case 'g':
        if (bg.length < 2) return null;
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: bg.map((e) => Color(e)).toList(),
          ),
        );
      case 'i':
        if (image.isEmpty) return null;
        return BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(image),
            fit: BoxFit.cover,
            colorFilter: const ColorFilter.mode(Colors.black26, BlendMode.darken),
          ),
        );
    }
    return null;
  }

  // ---- local cache (one theme per chat) ----
  Future<void> save(String chatKey) async {
    final p = await SharedPreferences.getInstance();
    if (isEmpty) {
      await p.remove('chat_theme_$chatKey');
    } else {
      await p.setString('chat_theme_$chatKey', jsonEncode(toJson()));
    }
  }

  static Future<ChatTheme> load(String chatKey) async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString('chat_theme_$chatKey');
      if (raw == null || raw.isEmpty) return none;
      final j = jsonDecode(raw);
      if (j is Map) return fromJson(j);
    } catch (_) {}
    return none;
  }
}

const List<int> kSolidColors = [
  0xFFA52729,
  0xFF1E88E5,
  0xFF43A047,
  0xFF8E24AA,
  0xFFFB8C00,
  0xFF00897B,
  0xFF3949AB,
  0xFFE91E63,
  0xFF6D4C41,
  0xFF212121,
  0xFF000000,
  0xFFFFFFFF,
];

const List<List<int>> kGradients = [
  [0xFFFF512F, 0xFFDD2476],
  [0xFF4776E6, 0xFF8E54E9],
  [0xFF11998E, 0xFF38EF7D],
  [0xFFFC466B, 0xFF3F5EFB],
  [0xFFF7971E, 0xFFFFD200],
  [0xFF00C6FF, 0xFF0072FF],
  [0xFFDA22FF, 0xFF9733EE],
  [0xFF232526, 0xFF414345],
];

class ChatThemeResult {
  final ChatTheme theme;
  final bool pickImage;
  const ChatThemeResult(this.theme, {this.pickImage = false});
}

Widget _swatch({
  required List<int> colors,
  required bool selected,
  required VoidCallback onTap,
}) {
  final deco = colors.length == 1
      ? BoxDecoration(color: Color(colors.first), shape: BoxShape.circle)
      : BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: colors.map((e) => Color(e)).toList(),
          ),
          shape: BoxShape.circle,
        );
  return GestureDetector(
    onTap: onTap,
    child: Container(
      width: 44,
      height: 44,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: selected ? Colors.blueAccent : Colors.grey.shade500, width: selected ? 3 : 1),
      ),
      child: DecoratedBox(decoration: deco),
    ),
  );
}

bool _sameColors(List<int> a, List<int> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

/// Bottom sheet to choose the chat background and the color of my bubbles.
Future<ChatThemeResult?> showChatThemeSheet(BuildContext context, ChatTheme current) {
  var t = current;
  return showModalBottomSheet<ChatThemeResult>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) {
        Widget title(String s) => Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: Text(s, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            );
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.85),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  title(t2(ctx, 'ჩატის ფონი', 'Chat background')),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Wrap(spacing: 10, runSpacing: 10, children: [
                      for (final c in kSolidColors)
                        _swatch(
                          colors: [c],
                          selected: t.bgKind == 'c' && t.bg.isNotEmpty && t.bg.first == c,
                          onTap: () => setS(() => t = t.copyWith(bgKind: 'c', bg: [c])),
                        ),
                      for (final g in kGradients)
                        _swatch(
                          colors: g,
                          selected: t.bgKind == 'g' && _sameColors(t.bg, g),
                          onTap: () => setS(() => t = t.copyWith(bgKind: 'g', bg: g)),
                        ),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.photo_library_outlined),
                      label: Text(t2(ctx, 'ფოტოს ატვირთვა ფონად', 'Upload a photo as background')),
                      onPressed: () => Navigator.pop(ctx, ChatThemeResult(t, pickImage: true)),
                    ),
                  ),
                  title(t2(ctx, 'ჩემი შეტყობინებების ფერი', 'My message color')),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Wrap(spacing: 10, runSpacing: 10, children: [
                      for (final c in kSolidColors)
                        _swatch(
                          colors: [c],
                          selected: t.bubble.length == 1 && t.bubble.first == c,
                          onTap: () => setS(() => t = t.copyWith(bubble: [c])),
                        ),
                      for (final g in kGradients)
                        _swatch(
                          colors: g,
                          selected: _sameColors(t.bubble, g),
                          onTap: () => setS(() => t = t.copyWith(bubble: g)),
                        ),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(ctx, const ChatThemeResult(ChatTheme.none)),
                          child: Text(t2(ctx, 'ნაგულისხმევი', 'Reset')),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton(
                          onPressed: () => Navigator.pop(ctx, ChatThemeResult(t)),
                          child: Text(t2(ctx, 'შენახვა', 'Apply')),
                        ),
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );
}
