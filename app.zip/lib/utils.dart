import 'package:flutter/material.dart';
import 'i18n.dart';

String str(dynamic v) => v == null ? '' : v.toString();

String cleanText(String s) {
  final t = s
      .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
      .replaceAll(RegExp(r'<[^>]*>'), '');
  return t
      .replaceAll('&amp;', '&')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&#039;', "'")
      .replaceAll('&#39;', "'");
}

String displayName(Map c) {
  final n = str(c['name']);
  if (n.isNotEmpty) return n;
  final fl = '${str(c['first_name'])} ${str(c['last_name'])}'.trim();
  if (fl.isNotEmpty) return fl;
  return str(c['username']);
}

bool isImageUrl(String url) {
  final u = url.toLowerCase().split('?').first;
  return u.endsWith('.jpg') ||
      u.endsWith('.jpeg') ||
      u.endsWith('.png') ||
      u.endsWith('.gif') ||
      u.endsWith('.webp');
}

bool isAudioUrl(String url) {
  final u = url.toLowerCase().split('?').first;
  return u.endsWith('.mp3') ||
      u.endsWith('.wav') ||
      u.endsWith('.m4a') ||
      u.endsWith('.aac') ||
      u.endsWith('.ogg') ||
      u.endsWith('.opus');
}

bool isVideoUrl(String url) {
  final u = url.toLowerCase().split('?').first;
  return u.endsWith('.mp4') ||
      u.endsWith('.mov') ||
      u.endsWith('.webm') ||
      u.endsWith('.mkv') ||
      u.endsWith('.avi') ||
      u.endsWith('.3gp');
}

class Avatar extends StatelessWidget {
  final String url;
  final String name;
  final double radius;
  const Avatar({super.key, required this.url, required this.name, this.radius = 22});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundImage: url.isNotEmpty ? NetworkImage(url) : null,
      child: url.isEmpty
          ? Text(name.isEmpty ? '?' : name.substring(0, 1).toUpperCase())
          : null,
    );
  }
}

/// Short helper for new texts: Georgian when the app language is Georgian, else English.
String t2(BuildContext c, String ka, String en) =>
    LangScope.codeOf(c) == 'ka' ? ka : en;
