import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api.dart';
import 'call_native.dart';
import 'utils.dart';

/// Unread count shown as a badge on the bottom navigation.
final ValueNotifier<int> notificationBadge = ValueNotifier<int>(0);

/// Notifications the user already read inside the app (kept on the phone).
class NotifRead {
  static final Set<String> _ids = {};
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    final p = await SharedPreferences.getInstance();
    _ids.addAll(p.getStringList('notif_read') ?? const []);
    _loaded = true;
  }

  static bool isRead(Map<String, dynamic> n) => _ids.contains(str(n['id']));

  static Future<void> markAll(Iterable<Map<String, dynamic>> list) async {
    await load();
    for (final n in list) {
      final id = str(n['id']);
      if (id.isNotEmpty) _ids.add(id);
    }
    await _save();
  }

  static Future<void> mark(Map<String, dynamic> n) async {
    await load();
    final id = str(n['id']);
    if (id.isEmpty) return;
    _ids.add(id);
    await _save();
  }

  static Future<void> _save() async {
    var l = _ids.toList();
    if (l.length > 400) {
      l = l.sublist(l.length - 400);
      _ids
        ..clear()
        ..addAll(l);
    }
    final p = await SharedPreferences.getInstance();
    await p.setStringList('notif_read', l);
  }

  static int unreadCount(List<Map<String, dynamic>> n, int requests) =>
      n.where((e) => str(e['seen']) == '0' && !isRead(e)).length + requests;
}

/// Polls the site for new notifications (likes, reactions, comments, follows)
/// and shows them as normal phone notifications while the app is not on screen.
class NotifyWatcher {
  static Timer? _timer;
  static bool _busy = false;
  static int _lastNotified = -1;

  static void start() {
    if (_timer != null) return;
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => pollNow());
    pollNow();
  }

  static void stop() {
    _timer?.cancel();
    _timer = null;
    _lastNotified = -1;
  }

  static List<Map<String, dynamic>> _maps(dynamic l) =>
      l is List ? l.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];

  static String _text(Map<String, dynamic> n) {
    final story = notificationText(n);
    if (story.isNotEmpty) return story;
    for (final k in const ['type_text', 'text']) {
      final v = cleanText(str(n[k])).trim();
      if (v.isNotEmpty) return v;
    }
    switch (str(n['type'])) {
      case 'following':
        return 'გამოგყვათ';
      case 'liked_post':
      case 'reaction':
        return 'რეაქცია დაუსვა თქვენს პოსტს';
      case 'comment':
        return 'დაგიკომენტარათ';
      case 'visited_profile':
        return 'ეწვია თქვენს პროფილს';
      default:
        return str(n['type']).replaceAll('_', ' ');
    }
  }

  static Future<void> pollNow() async {
    if (_busy || Api.accessToken == null) return;
    _busy = true;
    try {
      await NotifRead.load();
      final res = await Api.getNotifications();
      final n = _maps(res['notifications']);
      final r = _maps(res['friend_requests']);
      notificationBadge.value = NotifRead.unreadCount(n, r.length);

      final p = await SharedPreferences.getInstance();
      if (_lastNotified < 0) _lastNotified = p.getInt('notif_last_pushed') ?? -1;
      var maxId = 0;
      final fresh = <Map<String, dynamic>>[];
      for (final e in n) {
        final id = int.tryParse(str(e['id'])) ?? 0;
        if (id > maxId) maxId = id;
        if (id > _lastNotified && str(e['seen']) == '0' && !NotifRead.isRead(e)) fresh.add(e);
      }
      if (_lastNotified < 0) {
        // first run on this phone: do not spam old notifications
        _lastNotified = maxId;
        await p.setInt('notif_last_pushed', maxId);
        return;
      }
      if (maxId > _lastNotified) {
        _lastNotified = maxId;
        await p.setInt('notif_last_pushed', maxId);
      }
      final state = WidgetsBinding.instance.lifecycleState;
      final onScreen = state == null || state == AppLifecycleState.resumed;
      if (onScreen) return; // the badge is enough while the app is open
      fresh.sort((a, b) => (int.tryParse(str(a['id'])) ?? 0).compareTo(int.tryParse(str(b['id'])) ?? 0));
      for (final e in fresh.length > 5 ? fresh.sublist(fresh.length - 5) : fresh) {
        final u = e['notifier'] is Map ? Map<String, dynamic>.from(e['notifier'] as Map) : e;
        await CallNative.notify(int.tryParse(str(e['id'])) ?? 0, displayName(u), _text(e));
      }
    } catch (_) {
    } finally {
      _busy = false;
    }
  }
}
