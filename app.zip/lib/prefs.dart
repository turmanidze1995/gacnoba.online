import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Small local settings of the app (theme, privacy switches, call "seen" marks).
class AppPrefs {
  static final ValueNotifier<ThemeMode> themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);
  static bool typingIndicator = true;
  static bool hideOnline = false;
  static Map<String, int> callSeen = {};
  static final ValueNotifier<int> callSeenChanges = ValueNotifier<int>(0);

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString('theme_mode');
    themeMode.value =
        t == 'dark' ? ThemeMode.dark : (t == 'light' ? ThemeMode.light : ThemeMode.system);
    typingIndicator = p.getBool('typing_indicator') ?? true;
    hideOnline = p.getBool('hide_online') ?? false;
    final raw = p.getString('call_seen');
    if (raw != null && raw.isNotEmpty) {
      try {
        final j = jsonDecode(raw);
        if (j is Map) {
          callSeen = j.map((k, v) => MapEntry(k.toString(), int.tryParse(v.toString()) ?? 0));
        }
      } catch (_) {}
    }
  }

  static Future<void> setThemeMode(ThemeMode m) async {
    themeMode.value = m;
    final p = await SharedPreferences.getInstance();
    await p.setString('theme_mode', m == ThemeMode.dark ? 'dark' : (m == ThemeMode.light ? 'light' : 'system'));
  }

  static Future<void> setTypingIndicator(bool v) async {
    typingIndicator = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool('typing_indicator', v);
  }

  static Future<void> setHideOnline(bool v) async {
    hideOnline = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool('hide_online', v);
  }

  /// Marks the missed calls of this user as seen (the red "missed call" row turns normal).
  static Future<void> markCallsSeen(String userId) async {
    if (userId.isEmpty) return;
    callSeen[userId] = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final p = await SharedPreferences.getInstance();
    await p.setString('call_seen', jsonEncode(callSeen));
    callSeenChanges.value++;
  }
}
