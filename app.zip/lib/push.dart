import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'config.dart';

/// Push notifications through OneSignal. The site sends the pushes itself
/// (messages and calls) to the id we register at login (android_m_device_id).
class Push {
  static bool _ready = false;

  static Future<void> init() async {
    if (Config.oneSignalAppId.isEmpty || Config.oneSignalAppId.startsWith('PASTE')) return;
    try {
      OneSignal.initialize(Config.oneSignalAppId);
      await OneSignal.Notifications.requestPermission(true);
      _ready = true;
    } catch (_) {}
  }

  /// OneSignal needs a few seconds after first start to create the subscription id.
  static Future<String?> playerId() async {
    if (!_ready) return null;
    for (var i = 0; i < 20; i++) {
      try {
        final id = OneSignal.User.pushSubscription.id;
        if (id != null && id.isNotEmpty) return id;
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 500));
    }
    return null;
  }
}
