import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'api.dart';
import 'call_native.dart';
import 'config.dart';
import 'nav.dart';
import 'package:url_launcher/url_launcher.dart';
import 'screens/chat_screen.dart';
import 'screens/live_screens.dart';
import 'package:flutter/material.dart';

/// Push notifications through OneSignal. The site sends the pushes itself
/// (messages and calls) to the id we register at login (android_m_device_id).
class Push {
  static bool _ready = false;

  static Future<void> init() async {
    if (Config.oneSignalAppId.isEmpty || Config.oneSignalAppId.startsWith('PASTE')) return;
    try {
      OneSignal.initialize(Config.oneSignalAppId);
      await OneSignal.Notifications.requestPermission(true);
      // While the app is open nothing pops up on top of the screen.
      OneSignal.Notifications.addForegroundWillDisplayListener((event) {
        event.preventDefault();
      });
      OneSignal.Notifications.addClickListener((event) {
        _onClick(event.notification);
      });
      _ready = true;
    } catch (_) {}
  }

  static bool get ready => _ready;

  static Future<NavigatorState?> _waitNav() async {
    for (var i = 0; i < 30; i++) {
      final n = navigatorKey.currentState;
      if (n != null && Api.accessToken != null) return n;
      await Future<void>.delayed(const Duration(milliseconds: 200));
    }
    return null;
  }

  /// Tap on a push: chats open in the app, live videos open in the app (not on
  /// the website), everything else opens its link.
  static Future<void> _onClick(OSNotification n) async {
    try {
      final data = n.additionalData ?? const {};
      final uid = (data['user_id'] ?? '').toString();
      final type = (data['type'] ?? '').toString();
      final url = n.launchUrl ?? (data['url'] ?? '').toString();
      final text = '${n.title ?? ''} ${n.body ?? ''} $type $url'.toLowerCase();
      final isLive = text.contains('live') || text.contains('ლაივ') || text.contains('ეთერ');
      final nav = await _waitNav();
      if (nav == null) return;
      if (isLive) {
        final lives = await Api.liveList();
        if (lives.isNotEmpty) {
          var pick = lives.first;
          if (uid.isNotEmpty) {
            for (final l in lives) {
              if ('${l['user_id']}' == uid) pick = l;
            }
          }
          nav.push(MaterialPageRoute<void>(builder: (_) => LiveWatchScreen(live: pick)));
        }
        return;
      }
      if (uid.isNotEmpty && (type.isEmpty || type == 'user')) {
        nav.push(MaterialPageRoute<void>(
            builder: (_) => ChatScreen(userId: uid, name: n.title ?? '', avatar: '')));
        return;
      }
      if (url.startsWith('http')) {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      }
    } catch (_) {}
  }

  /// Opens the chat of a tapped floating bubble (native side keeps it until we ask).
  static Future<void> openPendingChat() async {
    if (Api.accessToken == null) return;
    final m = await CallNative.takePendingChat();
    if (m == null) return;
    final uid = m['user_id'] ?? '';
    final nav = navigatorKey.currentState;
    if (uid.isEmpty || nav == null) return;
    nav.push(MaterialPageRoute<void>(
        builder: (_) => ChatScreen(userId: uid, name: m['name'] ?? '', avatar: m['avatar'] ?? '')));
  }

  /// OneSignal needs a few seconds after first start to create the subscription id.
  static Future<String?> playerId() async {
    if (!_ready) return null;
    for (var i = 0; i < 20; i++) {
      try {
        final id = OneSignal.User.pushSubscription.id;
        if (id != null && id.isNotEmpty) return id;
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 500));
    }
    return null;
  }
}
