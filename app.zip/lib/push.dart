import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'api.dart';
import 'call_native.dart';
import 'config.dart';
import 'nav.dart';
import 'screens/chat_screen.dart';
import 'package:flutter/material.dart';

/// Push notifications through OneSignal. The site sends the pushes itself
/// (messages and calls) to the id we register at login (android_m_device_id).
class Push {
  static bool _ready = false;

  static Future<void> init() async {
    if (Config.oneSignalAppId.isEmpty || Config.oneSignalAppId.startsWith('PASTE')) return;
    try {
      OneSignal.initialize(Config.oneSignalAppId);
      await OneSignal.Notifications.requestPermission(true);
      OneSignal.Notifications.addClickListener((event) {
        try {
          if (Api.accessToken == null) return;
          final data = event.notification.additionalData;
          if (data == null) return;
          final uid = (data['user_id'] ?? '').toString();
          final type = (data['type'] ?? 'user').toString();
          if (uid.isEmpty || type != 'user') return;
          final nav = navigatorKey.currentState;
          if (nav == null) return;
          nav.push(MaterialPageRoute(
              builder: (_) => ChatScreen(
                  userId: uid, name: event.notification.title ?? '', avatar: '')));
        } catch (_) {}
      });
      _ready = true;
    } catch (_) {}
  }

  static bool get ready => _ready;

  /// Opens the chat of a tapped floating bubble (native side keeps it until we ask).
  static Future<void> openPendingChat() async {
    if (Api.accessToken == null) return;
    final m = await CallNative.takePendingChat();
    if (m == null) return;
    final uid = m['user_id'] ?? '';
    final nav = navigatorKey.currentState;
    if (uid.isEmpty || nav == null) return;
    nav.push(MaterialPageRoute<void>(
        builder: (_) => ChatScreen(userId: uid, name: m['name'] ?? '', avatar: m['avatar'] ?? '')));
  }

  /// OneSignal needs a few seconds after first start to create the subscription id.
  static Future<String?> playerId() async {
    if (!_ready) return null;
    for (var i = 0; i < 20; i++) {
      try {
        final id = OneSignal.User.pushSubscription.id;
        if (id != null && id.isNotEmpty) return id;
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 500));
    }
    return null;
  }
}
