import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'i18n_data.dart';

class I18n {
  static final ValueNotifier<String> current = ValueNotifier<String>('ka');
  static const Set<String> _rtl = {'ar', 'he', 'fa', 'ur'};

  static bool isRtl(String code) => _rtl.contains(code);

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getString('lang');
    if (saved != null && kTranslations.containsKey(saved)) {
      current.value = saved;
    }
  }

  static Future<void> set(String code) async {
    if (!kTranslations.containsKey(code)) return;
    current.value = code;
    final p = await SharedPreferences.getInstance();
    await p.setString('lang', code);
  }

  static String get(String code, String key) {
    final idx = kI18nKeys.indexOf(key);
    if (idx < 0) return key;
    final list = kTranslations[code] ?? kTranslations['en']!;
    return list[idx];
  }
}

/// Rebuilds everything below it when the language changes.
class LangScope extends InheritedNotifier<ValueNotifier<String>> {
  const LangScope({super.key, super.notifier, required super.child});

  static String codeOf(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<LangScope>();
    return scope?.notifier?.value ?? I18n.current.value;
  }
}

extension TrContext on BuildContext {
  String tr(String key) => I18n.get(LangScope.codeOf(this), key);
}
