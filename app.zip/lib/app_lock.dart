import 'dart:convert';
import 'dart:math' as math;
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'utils.dart';

/// App lock: PIN code or drawn pattern, optionally fingerprint / face.
class AppLockService {
  static String mode = 'none'; // none | pin | pattern
  static bool biometric = false;
  static int delaySeconds = 60;
  static String _hash = '';
  static String _salt = '';

  static bool get enabled => mode != 'none' && _hash.isNotEmpty;

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    mode = p.getString('lock_mode') ?? 'none';
    biometric = p.getBool('lock_bio') ?? false;
    delaySeconds = p.getInt('lock_delay') ?? 60;
    _hash = p.getString('lock_hash') ?? '';
    _salt = p.getString('lock_salt') ?? '';
  }

  static String _h(String secret, String salt) =>
      sha256.convert(utf8.encode('$salt|$secret')).toString();

  static Future<void> setSecret(String newMode, String secret) async {
    final rnd = math.Random.secure();
    _salt = List<String>.generate(12, (_) => rnd.nextInt(36).toRadixString(36)).join();
    _hash = _h(secret, _salt);
    mode = newMode;
    final p = await SharedPreferences.getInstance();
    await p.setString('lock_mode', mode);
    await p.setString('lock_hash', _hash);
    await p.setString('lock_salt', _salt);
  }

  static Future<void> disable() async {
    mode = 'none';
    biometric = false;
    _hash = '';
    _salt = '';
    final p = await SharedPreferences.getInstance();
    await p.setString('lock_mode', 'none');
    await p.remove('lock_hash');
    await p.remove('lock_salt');
    await p.setBool('lock_bio', false);
  }

  static bool verify(String secret) => _hash.isNotEmpty && _h(secret, _salt) == _hash;

  static Future<void> setBiometric(bool v) async {
    biometric = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool('lock_bio', v);
  }

  static Future<void> setDelay(int seconds) async {
    delaySeconds = seconds;
    final p = await SharedPreferences.getInstance();
    await p.setInt('lock_delay', seconds);
  }

  static Future<bool> biometricAvailable() async {
    try {
      final a = LocalAuthentication();
      return await a.canCheckBiometrics && await a.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  static Future<bool> authBiometric(String reason) async {
    try {
      return await LocalAuthentication().authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
    } catch (_) {
      return false;
    }
  }
}

/// Puts the lock screen on top of the whole app when the app is opened or when
/// it comes back from the background after the chosen delay.
class LockGate extends StatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});
  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  bool _locked = AppLockService.enabled;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt ??= DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final t = _pausedAt;
      _pausedAt = null;
      if (t != null &&
          !_locked &&
          AppLockService.enabled &&
          DateTime.now().difference(t).inSeconds >= AppLockService.delaySeconds) {
        setState(() => _locked = true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      widget.child,
      if (_locked)
        Positioned.fill(child: LockScreen(onUnlock: () => setState(() => _locked = false))),
    ]);
  }
}

// ---------------------------------------------------------------------------
// Lock screen
// ---------------------------------------------------------------------------
class LockScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _pin = '';
  bool _wrong = false;

  @override
  void initState() {
    super.initState();
    if (AppLockService.biometric) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
    }
  }

  Future<void> _bio() async {
    final ok = await AppLockService.authBiometric('GACNOBA.ONLINE');
    if (ok && mounted) widget.onUnlock();
  }

  void _digit(String d) {
    if (_pin.length >= 8) return;
    setState(() {
      _pin += d;
      _wrong = false;
    });
    if (_pin.length >= 4 && AppLockService.verify(_pin)) {
      HapticFeedback.lightImpact();
      widget.onUnlock();
    } else if (_pin.length == 8) {
      HapticFeedback.heavyImpact();
      setState(() {
        _pin = '';
        _wrong = true;
      });
    }
  }

  void _pattern(List<int> p) {
    if (p.isEmpty) return;
    if (AppLockService.verify(p.join('-'))) {
      widget.onUnlock();
    } else {
      HapticFeedback.heavyImpact();
      setState(() => _wrong = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isPin = AppLockService.mode == 'pin';
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.lock_outline, size: 40),
              const SizedBox(height: 12),
              Text(
                isPin
                    ? t2(context, 'შეიყვანეთ PIN კოდი', 'Enter your PIN')
                    : t2(context, 'დახაზეთ პატერნი', 'Draw your pattern'),
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 6),
              SizedBox(
                height: 20,
                child: _wrong
                    ? Text(t2(context, 'არასწორია, სცადეთ თავიდან', 'Wrong, try again'),
                        style: const TextStyle(color: Colors.red))
                    : null,
              ),
              const SizedBox(height: 12),
              if (isPin) ...[
                PinDots(length: _pin.length),
                const SizedBox(height: 20),
                Keypad(
                  onDigit: _digit,
                  onBack: () => setState(() {
                    if (_pin.isNotEmpty) _pin = _pin.substring(0, _pin.length - 1);
                  }),
                ),
              ] else
                PatternPad(onComplete: _pattern),
              if (AppLockService.biometric) ...[
                const SizedBox(height: 16),
                TextButton.icon(
                  onPressed: _bio,
                  icon: const Icon(Icons.fingerprint),
                  label: Text(t2(context, 'თითის ანაბეჭდი', 'Fingerprint')),
                ),
              ],
            ]),
          ),
        ),
      ),
    );
  }
}

class PinDots extends StatelessWidget {
  final int length;
  const PinDots({super.key, required this.length});
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme.primary;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      for (var i = 0; i < math.max(4, length); i++)
        Container(
          width: 14,
          height: 14,
          margin: const EdgeInsets.symmetric(horizontal: 6),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: i < length ? c : Colors.transparent,
            border: Border.all(color: c, width: 1.5),
          ),
        ),
    ]);
  }
}

class Keypad extends StatelessWidget {
  final void Function(String) onDigit;
  final VoidCallback onBack;
  final VoidCallback? onOk;
  const Keypad({super.key, required this.onDigit, required this.onBack, this.onOk});

  Widget _key(Widget child, VoidCallback? onTap) => SizedBox(
        width: 84,
        height: 64,
        child: InkResponse(
          onTap: onTap,
          radius: 36,
          child: Center(child: child),
        ),
      );

  Widget _num(String d) => _key(Text(d, style: const TextStyle(fontSize: 28)), () => onDigit(d));

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      for (final row in const [
        ['1', '2', '3'],
        ['4', '5', '6'],
        ['7', '8', '9'],
      ])
        Row(mainAxisSize: MainAxisSize.min, children: [for (final d in row) _num(d)]),
      Row(mainAxisSize: MainAxisSize.min, children: [
        _key(const Icon(Icons.backspace_outlined), onBack),
        _num('0'),
        _key(Icon(Icons.check_circle_outline, color: onOk == null ? Colors.transparent : null), onOk),
      ]),
    ]);
  }
}

/// 3x3 dots, draw a pattern with the finger. Calls onComplete with the dot indexes (0..8).
class PatternPad extends StatefulWidget {
  final ValueChanged<List<int>> onComplete;
  final double size;
  const PatternPad({super.key, required this.onComplete, this.size = 280});
  @override
  State<PatternPad> createState() => _PatternPadState();
}

class _PatternPadState extends State<PatternPad> {
  final List<int> _sel = [];
  Offset? _cur;

  Offset _center(int i) {
    final cell = widget.size / 3;
    return Offset((i % 3 + 0.5) * cell, (i ~/ 3 + 0.5) * cell);
  }

  void _hit(Offset p) {
    for (var i = 0; i < 9; i++) {
      if (!_sel.contains(i) && (p - _center(i)).distance < widget.size / 3 * 0.38) {
        _sel.add(i);
        HapticFeedback.selectionClick();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    final dim = Theme.of(context).colorScheme.outline;
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanStart: (d) => setState(() {
          _sel.clear();
          _cur = d.localPosition;
          _hit(d.localPosition);
        }),
        onPanUpdate: (d) => setState(() {
          _cur = d.localPosition;
          _hit(d.localPosition);
        }),
        onPanEnd: (_) {
          final r = List<int>.from(_sel);
          setState(() {
            _sel.clear();
            _cur = null;
          });
          widget.onComplete(r);
        },
        child: CustomPaint(
          painter: _PatternPainter(
            sel: List<int>.from(_sel),
            cur: _cur,
            size: widget.size,
            color: color,
            dim: dim,
          ),
        ),
      ),
    );
  }
}

class _PatternPainter extends CustomPainter {
  final List<int> sel;
  final Offset? cur;
  final double size;
  final Color color;
  final Color dim;
  _PatternPainter(
      {required this.sel, required this.cur, required this.size, required this.color, required this.dim});

  Offset _c(int i) {
    final cell = size / 3;
    return Offset((i % 3 + 0.5) * cell, (i ~/ 3 + 0.5) * cell);
  }

  @override
  void paint(Canvas canvas, Size s) {
    final line = Paint()
      ..color = color
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i + 1 < sel.length; i++) {
      canvas.drawLine(_c(sel[i]), _c(sel[i + 1]), line);
    }
    if (sel.isNotEmpty && cur != null) canvas.drawLine(_c(sel.last), cur!, line);
    for (var i = 0; i < 9; i++) {
      final on = sel.contains(i);
      canvas.drawCircle(_c(i), on ? 14 : 9, Paint()..color = on ? color : dim);
    }
  }

  @override
  bool shouldRepaint(covariant _PatternPainter old) => true;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
class LockSettingsScreen extends StatefulWidget {
  const LockSettingsScreen({super.key});
  @override
  State<LockSettingsScreen> createState() => _LockSettingsScreenState();
}

class _LockSettingsScreenState extends State<LockSettingsScreen> {
  bool _bioAvail = false;

  @override
  void initState() {
    super.initState();
    AppLockService.biometricAvailable().then((v) {
      if (mounted) setState(() => _bioAvail = v);
    });
  }

  /// When a lock is already set, ask for it before changing it.
  Future<bool> _confirmCurrent() async {
    if (!AppLockService.enabled) return true;
    final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (ctx) => Stack(children: [
        LockScreen(onUnlock: () => Navigator.of(ctx).pop(true)),
        Positioned(
          top: 8,
          left: 4,
          child: SafeArea(
            child: IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.of(ctx).pop(false)),
          ),
        ),
      ]),
    ));
    return ok == true;
  }

  Future<void> _choose(String mode) async {
    if (mode == AppLockService.mode) return;
    if (!await _confirmCurrent()) return;
    if (mode == 'none') {
      await AppLockService.disable();
      if (mounted) setState(() {});
      return;
    }
    if (!mounted) return;
    final secret = await Navigator.of(context).push<String>(
        MaterialPageRoute(builder: (_) => SetSecretScreen(kind: mode)));
    if (secret == null) return;
    await AppLockService.setSecret(mode, secret);
    if (mounted) setState(() {});
  }

  Future<void> _toggleBio(bool v) async {
    if (v) {
      final ok = await AppLockService.authBiometric(t2(context, 'დაადასტურეთ', 'Confirm'));
      if (!ok) return;
    }
    await AppLockService.setBiometric(v);
    if (mounted) setState(() {});
  }

  String _delayLabel(int s) {
    if (s == 0) return t2(context, 'დაუყოვნებლივ', 'Immediately');
    if (s < 60) return t2(context, '$s წამი', '$s seconds');
    return t2(context, '${s ~/ 60} წუთი', '${s ~/ 60} min');
  }

  Future<void> _pickDelay() async {
    final v = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          for (final s in const [0, 30, 60, 300])
            ListTile(
              title: Text(_delayLabel(s)),
              trailing: s == AppLockService.delaySeconds ? const Icon(Icons.check) : null,
              onTap: () => Navigator.pop(ctx, s),
            ),
        ]),
      ),
    );
    if (v == null) return;
    await AppLockService.setDelay(v);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final mode = AppLockService.enabled ? AppLockService.mode : 'none';
    Widget item(String m, IconData icon, String label) => ListTile(
          leading: Icon(icon),
          title: Text(label),
          trailing: mode == m ? const Icon(Icons.check_circle) : null,
          onTap: () => _choose(m),
        );
    return Scaffold(
      appBar: AppBar(title: Text(t2(context, 'აპის დაცვა', 'App lock'))),
      body: ListView(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Text(t2(context, 'აპის გახსნისას მოითხოვოს:', 'Ask when the app is opened:'),
              style: Theme.of(context).textTheme.bodyMedium),
        ),
        item('none', Icons.lock_open, t2(context, 'გამორთულია', 'Off')),
        item('pin', Icons.pin_outlined, t2(context, 'PIN კოდი', 'PIN code')),
        item('pattern', Icons.pattern, t2(context, 'პატერნი (დახაზული პაროლი)', 'Pattern')),
        const Divider(),
        SwitchListTile(
          secondary: const Icon(Icons.fingerprint),
          title: Text(t2(context, 'თითის ანაბეჭდი / სახე', 'Fingerprint / face')),
          subtitle: Text(_bioAvail
              ? t2(context, 'PIN-ის ან პატერნის ნაცვლად', 'Instead of PIN or pattern')
              : t2(context, 'ტელეფონზე არ არის ჩართული', 'Not set up on this phone')),
          value: AppLockService.biometric && mode != 'none',
          onChanged: (_bioAvail && mode != 'none') ? _toggleBio : null,
        ),
        ListTile(
          leading: const Icon(Icons.timer_outlined),
          title: Text(t2(context, 'ჩაკეტვა დაბრუნებისას', 'Lock when coming back after')),
          subtitle: Text(_delayLabel(AppLockService.delaySeconds)),
          enabled: mode != 'none',
          onTap: mode == 'none' ? null : _pickDelay,
        ),
      ]),
    );
  }
}

/// Asks for a new PIN or pattern twice. Pops with the secret (PIN digits or "0-1-2-5").
class SetSecretScreen extends StatefulWidget {
  final String kind; // pin | pattern
  const SetSecretScreen({super.key, required this.kind});
  @override
  State<SetSecretScreen> createState() => _SetSecretScreenState();
}

class _SetSecretScreenState extends State<SetSecretScreen> {
  String _pin = '';
  String? _first;
  String? _msg;

  void _next(String secret) {
    if (_first == null) {
      setState(() {
        _first = secret;
        _pin = '';
        _msg = null;
      });
    } else if (_first == secret) {
      Navigator.of(context).pop(secret);
    } else {
      setState(() {
        _first = null;
        _pin = '';
        _msg = t2(context, 'არ ემთხვევა, თავიდან სცადეთ', 'Does not match, try again');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isPin = widget.kind == 'pin';
    final step = _first == null
        ? (isPin
            ? t2(context, 'ახალი PIN (მინ. 4 ციფრი)', 'New PIN (min. 4 digits)')
            : t2(context, 'დახაზეთ ახალი პატერნი (მინ. 4 წერტილი)', 'Draw a new pattern (min. 4 dots)'))
        : t2(context, 'გაიმეორეთ დასადასტურებლად', 'Repeat to confirm');
    return Scaffold(
      appBar: AppBar(title: Text(isPin ? t2(context, 'PIN კოდი', 'PIN code') : t2(context, 'პატერნი', 'Pattern'))),
      body: Center(
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(step, style: Theme.of(context).textTheme.titleMedium),
            SizedBox(
              height: 28,
              child: _msg == null ? null : Text(_msg!, style: const TextStyle(color: Colors.red)),
            ),
            if (isPin) ...[
              PinDots(length: _pin.length),
              const SizedBox(height: 20),
              Keypad(
                onDigit: (d) => setState(() {
                  if (_pin.length < 8) _pin += d;
                }),
                onBack: () => setState(() {
                  if (_pin.isNotEmpty) _pin = _pin.substring(0, _pin.length - 1);
                }),
                onOk: _pin.length >= 4 ? () => _next(_pin) : null,
              ),
            ] else
              PatternPad(onComplete: (p) {
                if (p.length < 4) {
                  setState(() => _msg = t2(context, 'მინიმუმ 4 წერტილი', 'At least 4 dots'));
                } else {
                  _next(p.join('-'));
                }
              }),
          ]),
        ),
      ),
    );
  }
}
