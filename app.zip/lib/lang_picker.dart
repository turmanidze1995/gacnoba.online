import 'package:flutter/material.dart';
import 'i18n.dart';
import 'i18n_data.dart';

Future<void> showLanguagePicker(BuildContext context) async {
  await showDialog<void>(
    context: context,
    builder: (ctx) => SimpleDialog(
      title: Text(ctx.tr('language')),
      children: [
        SizedBox(
          width: double.maxFinite,
          height: 420,
          child: ListView(
            children: [
              for (final e in kLanguageNames.entries)
                ListTile(
                  title: Text(e.value),
                  trailing: e.key == I18n.current.value ? const Icon(Icons.check) : null,
                  onTap: () {
                    I18n.set(e.key);
                    Navigator.of(ctx).pop();
                  },
                ),
            ],
          ),
        ),
      ],
    ),
  );
}
