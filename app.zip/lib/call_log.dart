import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Text of the message that tells the other person about a call they missed.
const String kUnansweredAudio = '📞 უპასუხო ზარი';
const String kUnansweredVideo = '📹 უპასუხო ვიდეო ზარი';

class CallEntry {
  final String userId;
  final String name;
  final String avatar;
  final String type; // audio | video
  final String direction; // in | out | missed
  final int time; // unix seconds
  final int seconds;
  const CallEntry({
    required this.userId,
    required this.name,
    required this.avatar,
    required this.type,
    required this.direction,
    required this.time,
    required this.seconds,
  });

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'name': name,
        'avatar': avatar,
        'type': type,
        'direction': direction,
        'time': time,
        'seconds': seconds,
      };

  factory CallEntry.fromJson(Map<String, dynamic> j) => CallEntry(
        userId: (j['userId'] ?? '').toString(),
        name: (j['name'] ?? '').toString(),
        avatar: (j['avatar'] ?? '').toString(),
        type: (j['type'] ?? 'audio').toString(),
        direction: (j['direction'] ?? 'out').toString(),
        time: int.tryParse((j['time'] ?? '0').toString()) ?? 0,
        seconds: int.tryParse((j['seconds'] ?? '0').toString()) ?? 0,
      );
}

/// Call history stored on the phone (the site has no call-history API).
class CallLog {
  static final ValueNotifier<int> changes = ValueNotifier<int>(0);

  static Future<List<CallEntry>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('call_log');
    if (raw == null || raw.isEmpty) return [];
    try {
      final l = jsonDecode(raw);
      if (l is List) {
        return l
            .whereType<Map>()
            .map((e) => CallEntry.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {}
    return [];
  }

  static Future<void> add(CallEntry e) async {
    final list = await load();
    list.insert(0, e);
    if (list.length > 100) list.removeRange(100, list.length);
    final p = await SharedPreferences.getInstance();
    await p.setString('call_log', jsonEncode(list.map((x) => x.toJson()).toList()));
    changes.value++;
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('call_log');
    changes.value++;
  }
}
