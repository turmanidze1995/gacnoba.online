import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Talks to the native Android side (call ringtone / full screen call notification).
class CallNative {
  static const MethodChannel _ch = MethodChannel('gacnoba/call');

  /// True while the call screen is shown in the small picture-in-picture window.
  static final ValueNotifier<bool> inPip = ValueNotifier<bool>(false);
  static bool _handlerSet = false;

  static void _ensureHandler() {
    if (_handlerSet) return;
    _handlerSet = true;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'pip') inPip.value = call.arguments == true;
      return null;
    });
  }

  /// Starts / stops the ongoing-call service (keeps the call alive in the background
  /// and lets the call go to a small window when the app is minimized).
  static Future<void> setCallActive(bool active, {String name = '', bool video = false}) async {
    _ensureHandler();
    if (!active) inPip.value = false;
    try {
      await _ch.invokeMethod<void>('callActive', {'active': active, 'name': name, 'video': video});
    } catch (_) {}
  }

  /// Version code (build number) of the installed app.
  static Future<int> versionCode() async {
    try {
      return (await _ch.invokeMethod<int>('versionCode')) ?? 0;
    } catch (_) {
      return 0;
    }
  }

  /// Opens the Android installer for the downloaded APK: 'ok', 'need_permission' or 'error:...'.
  static Future<String> installApk(String path) async {
    try {
      return (await _ch.invokeMethod<String>('installApk', {'path': path})) ?? 'error';
    } catch (e) {
      return 'error:$e';
    }
  }

  static Future<bool> canOverlay() async {
    try {
      return (await _ch.invokeMethod<bool>('canOverlay')) == true;
    } catch (_) {
      return false;
    }
  }

  /// Opens the system page where "Display over other apps" is allowed (floating bubble).
  static Future<void> requestOverlay() async {
    try {
      await _ch.invokeMethod<void>('requestOverlay');
    } catch (_) {}
  }

  /// Chat that was opened by tapping the floating bubble: {user_id, name, avatar} or null.
  static Future<Map<String, String>?> takePendingChat() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('takePendingChat');
      if (r == null) return null;
      return r.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return null;
    }
  }

  /// Rings like a phone call (full screen notification + ringtone) while the
  /// app is minimized or the phone is locked.
  static Future<void> ring(String title, String text) async {
    try {
      await _ch.invokeMethod<void>('ring', {'title': title, 'text': text});
    } catch (_) {}
  }

  /// Shows a normal phone notification (likes, comments, ... of the site).
  static Future<void> notify(int id, String title, String body) async {
    try {
      await _ch.invokeMethod<void>('notify', {'id': id, 'title': title, 'body': body});
    } catch (_) {}
  }

  /// Stops the ringing notification (call answered, declined or ended).
  static Future<void> stopRing() async {
    try {
      await _ch.invokeMethod<void>('stopRing');
    } catch (_) {}
  }

  /// Opens the system ringtone picker. Returns {uri, title} or null when cancelled.
  static Future<Map<String, String>?> pickRingtone() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('pickRingtone');
      if (r == null) return null;
      return r.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return null;
    }
  }

  /// Currently chosen call ringtone: {uri, title} (empty strings = system default).
  static Future<Map<String, String>> getRingtone() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getRingtone');
      if (r != null) return r.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {}
    return {'uri': '', 'title': ''};
  }

  static Future<void> resetRingtone() async {
    try {
      await _ch.invokeMethod<void>('resetRingtone');
    } catch (_) {}
  }

  static Future<void> previewRingtone() async {
    try {
      await _ch.invokeMethod<void>('previewRingtone');
    } catch (_) {}
  }

  static Future<void> stopPreview() async {
    try {
      await _ch.invokeMethod<void>('stopPreview');
    } catch (_) {}
  }

  /// System settings page of this app's notifications (message sound per channel).
  static Future<void> openNotificationSettings() async {
    try {
      await _ch.invokeMethod<void>('openNotificationSettings');
    } catch (_) {}
  }
}
