import 'package:flutter/services.dart';

/// Talks to the native Android side (call ringtone / full screen call notification).
class CallNative {
  static const MethodChannel _ch = MethodChannel('gacnoba/call');

  /// Stops the ringing notification (call answered, declined or ended).
  static Future<void> stopRing() async {
    try {
      await _ch.invokeMethod<void>('stopRing');
    } catch (_) {}
  }
}
