import 'package:flutter/services.dart';

/// Talks to the native Android side (call ringtone / full screen call notification).
class CallNative {
  static const MethodChannel _ch = MethodChannel('gacnoba/call');

  /// Stops the ringing notification (call answered, declined or ended).
  static Future<void> stopRing() async {
    try {
      await _ch.invokeMethod<void>('stopRing');
    } catch (_) {}
  }

  /// Opens the system ringtone picker. Returns {uri, title} or null when cancelled.
  static Future<Map<String, String>?> pickRingtone() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('pickRingtone');
      if (r == null) return null;
      return r.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return null;
    }
  }

  /// Currently chosen call ringtone: {uri, title} (empty strings = system default).
  static Future<Map<String, String>> getRingtone() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getRingtone');
      if (r != null) return r.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {}
    return {'uri': '', 'title': ''};
  }

  static Future<void> resetRingtone() async {
    try {
      await _ch.invokeMethod<void>('resetRingtone');
    } catch (_) {}
  }

  static Future<void> previewRingtone() async {
    try {
      await _ch.invokeMethod<void>('previewRingtone');
    } catch (_) {}
  }

  static Future<void> stopPreview() async {
    try {
      await _ch.invokeMethod<void>('stopPreview');
    } catch (_) {}
  }

  /// System settings page of this app's notifications (message sound per channel).
  static Future<void> openNotificationSettings() async {
    try {
      await _ch.invokeMethod<void>('openNotificationSettings');
    } catch (_) {}
  }
}
