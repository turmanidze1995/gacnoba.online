<?php
// Upload test for the GACNOBA.ONLINE app. Put this file next to index.php (site root).
// The app (Admin > Diagnostics > "Upload test") sends a small photo here and shows
// exactly what the server received. Delete the file when you are done testing.
header('Content-Type: application/json; charset=utf-8');
$files = array();
foreach ($_FILES as $k => $f) {
    $files[$k] = array(
        'name' => isset($f['name']) ? $f['name'] : null,
        'type' => isset($f['type']) ? $f['type'] : null,
        'size' => isset($f['size']) ? $f['size'] : null,
        'error' => isset($f['error']) ? $f['error'] : null,
        'tmp_exists' => (isset($f['tmp_name']) && is_string($f['tmp_name'])) ? file_exists($f['tmp_name']) : false,
    );
}
$up = __DIR__ . '/upload';
echo json_encode(array(
    'api_status' => '200',
    'content_type' => isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '',
    'content_length' => isset($_SERVER['CONTENT_LENGTH']) ? $_SERVER['CONTENT_LENGTH'] : '',
    'post_keys' => array_keys($_POST),
    'files' => $files,
    'php' => array(
        'version' => PHP_VERSION,
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'post_max_size' => ini_get('post_max_size'),
        'max_execution_time' => ini_get('max_execution_time'),
        'file_uploads' => ini_get('file_uploads'),
    ),
    'upload_dir_writable' => is_dir($up) ? is_writable($up) : 'no upload dir here',
));
