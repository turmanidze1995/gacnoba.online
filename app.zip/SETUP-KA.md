# GACNOBA.ONLINE მესენჯერი: დაყენების სრული ინსტრუქცია

## 0. რა არის ახალი ამ ვერსიაში
- 25 ენა (იგივე, რაც საიტზეა): ქართული, English, Русский, Türkçe, Español, Français, Deutsch, Italiano, Português, العربية, עברית, فارسی, اردو, हिन्दी, বাংলা, 中文, 日本語, 한국어, Tiếng Việt, Bahasa Indonesia, Nederlands, Svenska, Dansk, Hrvatski, Filipino. არაბული, ებრაული, სპარსული და ურდუ მარჯვნიდან მარცხნივ იწერება. ენის ღილაკი (🌐) ლოგინის ეკრანზე და ჩატების სიის ზემოთაა.
- საიტის ლოგო ლოგინის ეკრანზე (მოძრავი) და ზედა ზოლში.
- აპის სახელი: **GACNOBA.ONLINE**, ახალი ხატულა ლოგოთი.
- **Google-ით შესვლა** და **რეგისტრაცია**.
- ახალი APK ყოველთვის ერთი და იმავე გასაღებით ხელმოწერილია, ამიტომ შემდეგი ვერსიები ძველზე დაინსტალირდება.

⚠️ **პირველად ძველი აპი წაშალეთ ტელეფონიდან** და მერე დააყენეთ ახალი, რადგან ძველი სხვა გასაღებით იყო ხელმოწერილი.

---

## 1. რატომ არ მოდის შეტყობინებები ტელეფონზე (გარეთ)
ახლა სამი რამ აკლია:
1. აპში არ არის OneSignal App ID (ის ჯერ `PASTE_...` ტექსტია).
2. საიტზე (admin-cp) OneSignal-ის გასაღებები არ არის ჩაწერილი.
3. ტელეფონი საიტზე "არ არის რეგისტრირებული" შეტყობინებებისთვის. რეგისტრაცია მხოლოდ **შესვლისას** ხდება.

როგორ მუშაობს: ვინმე გწერთ → საიტის სერვერი OneSignal-ს ეუბნება → OneSignal Firebase-ის (Google FCM) გავლით ტელეფონს უგზავნის შეტყობინებას → ტელეფონზე ჩანს, აპი ღია არ უნდა იყოს.

### ნაბიჯი A. Firebase (უფასოა)
1. გახსენით https://console.firebase.google.com → **Add project** → სახელი `gacnoba` → გააგრძელეთ (Analytics არ არის საჭირო).
2. პროექტის მთავარ გვერდზე დააჭირეთ Android-ის ხატულას (**Add app**) → Package name: `com.gacnoba.gacnoba_messenger` → Register app. `google-services.json` ჩამოტვირთვა **არ არის საჭირო**, გააგრძელეთ.
3. ზევით ⚙️ → **Project settings** → ჩანართი **Service accounts** → **Generate new private key** → ჩამოიტვირთება `.json` ფაილი. ეს ფაილი ინახეთ, ვის არავის გაუგზავნოთ.

### ნაბიჯი B. OneSignal (უფასოა)
1. https://onesignal.com → დარეგისტრირდით → **New App/Website** → სახელი `Gacnoba` → აირჩიეთ **Push** → პლატფორმა **Google Android (FCM)**.
2. ატვირთეთ ნაბიჯი A-ში ჩამოტვირთული service account `.json` ფაილი.
3. SDK-ს არჩევისას აირჩიეთ **Flutter** (ან Native Android) → გააგრძელეთ.
4. მოგცემთ **App ID** (UUID: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`). დააკოპირეთ.
5. **Settings → Keys & IDs** → იქ ნახავთ **REST API Key** (ან შექმენით ახალი API key). დააკოპირეთ.

### ნაბიჯი C. admin-cp (საიტზე)
1. შედით `https://gacnoba.online/admin-cp` → **Mobile & API Settings** (ან Settings → Push Notifications Settings).
2. ჩართეთ **Push Notifications** და **Android Messenger** (შეტყობინებები მესენჯერისთვის).
3. ველებში **Android Messenger App ID** ჩაწერეთ OneSignal **App ID**, ველში **Android Messenger Key / REST API Key** ჩაწერეთ **REST API Key**.
4. შეინახეთ.

### ნაბიჯი D. აპში
GitHub repository-ში შექმენით ფაილი `app-settings.txt` (შაბლონი მოყვება) და ჩაწერეთ:
```
ONESIGNAL_APP_ID=თქვენი-App-ID
```
შემდეგ Actions → **Build APK** → Run workflow → ახალი APK.

### ნაბიჯი E. ტესტი
1. წაშალეთ ძველი აპი, დააყენეთ ახალი, **შედით ანგარიშში** (შეტყობინებების ნებართვას დაეთანხმეთ).
2. OneSignal-ში: **Audience → Subscriptions** უნდა გამოჩნდეს თქვენი ტელეფონი სტატუსით **Subscribed**.
3. მეორე ანგარიშიდან დაუწერეთ შეტყობინება, როცა თქვენი აპი **დახურულია**. უნდა მოვიდეს შეტყობინება.
4. Samsung/Xiaomi ტელეფონზე: Settings → Apps → GACNOBA.ONLINE → Battery → **Unrestricted** (წინააღმდეგ შემთხვევაში სისტემა აპს ფონზე ასუსტებს).

### თუ მაინც არ მოდის
- OneSignal → Messages → **New Push** → გაუგზავნეთ ტესტი თქვენს ტელეფონს. თუ **ეს** მოვიდა, აპი სწორია, პრობლემა საიტის admin-cp პარამეტრებშია (App ID / REST Key / ჩართვა).
- თუ ტესტიც არ მოდის, პრობლემა Firebase/OneSignal კავშირშია (service account JSON, package name).
- ახალი APK-ს დაყენების შემდეგ აპი ზევით გაჩვენებთ ყვითელ ზოლს "თავიდან შედით". დააჭირეთ გამოსვლას და შედით თავიდან.
- შენიშვნა: წერილის push-ს სერვერი აგზავნის, როცა წერილის გამგზავნი აპი ან საიტი ჩატს განაახლებს (გამგზავნის ჩატი ღიაა). ეს WoWonder-ის მუშაობის წესია.

---

## 2. Google-ით შესვლა
აპი Google-ის ანგარიშით შედის და საიტს უგზავნის Google-ის დადასტურებას (`social-login`). ამისთვის საჭიროა ორი ID.

1. გახსენით https://console.cloud.google.com და აირჩიეთ **იგივე პროექტი**, რომელსაც საიტზე Google-ით შესვლა იყენებს (ან შექმენით ახალი).
2. **APIs & Services → OAuth consent screen**: აპი უნდა იყოს **In production** (ან დაამატეთ თქვენი Gmail Test users-ში).
3. **APIs & Services → Credentials → Create credentials → OAuth client ID**:
   - Application type: **Android**
   - Package name: `com.gacnoba.gacnoba_messenger`
   - SHA-1 certificate fingerprint: `82:8B:42:0D:E8:E4:D8:2B:7E:EB:2C:80:BC:1B:9C:A4:E2:6C:49:CF`
   - Create.
4. **Web client ID:** იგივე პროექტის **Web application** ტიპის OAuth client (ის, რომელიც საიტის admin-cp-ში **Google App ID**-ად წერია). დააკოპირეთ მისი Client ID (`...apps.googleusercontent.com`).
5. ჩაწერეთ `app-settings.txt`-ში:
```
GOOGLE_WEB_CLIENT_ID=თქვენი-Web-Client-ID.apps.googleusercontent.com
```
6. Build ისევ გაუშვით. ცვლილებები Google-ში რამდენიმე წუთში იწყებს მუშაობას.

---

## 3. app-settings.txt
ფაილი ჩვეულებრივი ტექსტია repository-ს ძირში (იქ, სადაც `app.zip` დევს). ორივე ID საჯარო ტიპისაა, საიდუმლო არ არის. REST API Key და Google-ის Client Secret აქ **არ ჩაწეროთ**.

## 4. GitHub-ზე ახალი ვერსიის დაყენება
1. Upload files → `app.zip` (ჩაანაცვლებს ძველს) და `app-settings.txt`.
2. Actions → **Build APK** → Run workflow → Artifacts → `gacnoba-messenger-apk`.
