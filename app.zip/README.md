# GACNOBA.ONLINE Messenger

სრული ინსტრუქცია: `SETUP-KA.md`.

1. GitHub: ატვირთეთ `app.zip` (ჩაანაცვლებს ძველს), Actions → Build APK → Run workflow.
2. არასავალდებულო პარამეტრები: `app-settings.txt` (GIPHY_API_KEY, GOOGLE_WEB_CLIENT_ID).
3. შეტყობინებებისთვის: admin-cp-ში "Android Messenger" ველები + სწორი OneSignal REST API Key + `gacnoba-push.php` cron.

Android ხელმოწერის გასაღები: `tool/gacnoba.p12` (SHA-1: 82:8B:42:0D:E8:E4:D8:2B:7E:EB:2C:80:BC:1B:9C:A4:E2:6C:49:CF).
Repository აუცილებლად Private უნდა იყოს.
