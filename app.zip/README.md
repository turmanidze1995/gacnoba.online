# Gacnoba Messenger (Flutter)

საიტი: https://gacnoba.online (WoWonder API v2). Server Key უკვე ჩასმულია `lib/config.dart`-ში.

## რა გასაღებები სჭირდება
| გასაღები | სად ჩაიწერება | სტატუსი |
|---|---|---|
| Server Key (API v2) | `lib/config.dart` | ჩასმულია |
| OneSignal App ID | `lib/config.dart` (ველი `oneSignalAppId`) + admin-cp | თქვენგან მჭირდება |
| OneSignal REST API Key | admin-cp (Android Messenger Key) | თქვენგან |
| Agora App ID + Certificate | admin-cp (Agora პარამეტრები) | თქვენგან |
| Firebase (FCM) service account JSON | მხოლოდ OneSignal-ის პანელში | თქვენგან |

## GitHub
1. Private repository → ატვირთეთ `app.zip` (გახსნა არ სჭირდება).
2. შექმენით ფაილი `.github/workflows/build-apk.yml` და ჩასვით `build-apk.yml`-ის ტექსტი.
3. Actions → Build APK → Run workflow → Artifacts-იდან გადმოწერეთ APK.
