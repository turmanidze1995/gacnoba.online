# GACNOBA.ONLINE Messenger

დეტალური ინსტრუქცია (push შეტყობინებები, Google-ით შესვლა) იხილეთ ფაილში `SETUP-KA.md`.

## მოკლედ
1. GitHub-ზე ატვირთეთ `app.zip` (ძველს ჩაანაცვლებს).
2. შექმენით ფაილი `app-settings.txt` (შაბლონი მოყვება) და ჩაწერეთ:
   ONESIGNAL_APP_ID=...
   GOOGLE_WEB_CLIENT_ID=...
3. Actions → Build APK → Run workflow.

Android ხელმოწერის გასაღები: `tool/gacnoba.p12` (SHA-1: 82:8B:42:0D:E8:E4:D8:2B:7E:EB:2C:80:BC:1B:9C:A4:E2:6C:49:CF).
Repository აუცილებლად Private უნდა იყოს.
