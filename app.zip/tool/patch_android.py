"""Patch the generated Android project (run after `flutter create`)."""
import pathlib
import re
import shutil

root = pathlib.Path('android/app')
manifest = root / 'src/main/AndroidManifest.xml'
s = manifest.read_text()

perms = [
    'INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO',
    'MODIFY_AUDIO_SETTINGS', 'BLUETOOTH_CONNECT', 'POST_NOTIFICATIONS',
    'WAKE_LOCK', 'VIBRATE', 'USE_FULL_SCREEN_INTENT',
    'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'USE_BIOMETRIC',
    'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MICROPHONE', 'FOREGROUND_SERVICE_CAMERA',
    'SYSTEM_ALERT_WINDOW', 'REQUEST_INSTALL_PACKAGES',
]
add = ''.join(
    f'    <uses-permission android:name="android.permission.{p}"/>\n'
    for p in perms if f'android.permission.{p}"' not in s
)
s = s.replace('<application', add + '    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="GACNOBA.ONLINE"', s, count=1)
# OneSignal service extension: rings like a phone call when a call push arrives
kt_files = list(root.glob('src/main/kotlin/**/MainActivity.kt'))
if kt_files:
    kt_dir = kt_files[0].parent
    first = kt_files[0].read_text().splitlines()[0]
    pkg = first.replace('package', '').strip()
    for src in pathlib.Path('tool/native').glob('*.kt'):
        (kt_dir / src.name).write_text(src.read_text().replace('__PKG__', pkg))
    ext = '<meta-data android:name="com.onesignal.NotificationServiceExtension" android:value="%s.CallNotificationExtension"/>' % pkg
    if 'NotificationServiceExtension' not in s:
        s = s.replace('</application>', '        ' + ext + '\n    </application>', 1)
    if 'CallService' not in s:
        svc = '<service android:name="%s.CallService" android:exported="false" android:foregroundServiceType="microphone|camera"/>' % pkg
        s = s.replace('</application>', '        ' + svc + '\n    </application>', 1)
    if 'gacnobafiles' not in s:
        prov = ('<provider android:name="androidx.core.content.FileProvider" '
                'android:authorities="${applicationId}.gacnobafiles" android:exported="false" '
                'android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" '
                'android:resource="@xml/gacnoba_paths"/></provider>')
        s = s.replace('</application>', '        ' + prov + '\n    </application>', 1)
    xml_dir = root / 'src/main/res/xml'
    xml_dir.mkdir(parents=True, exist_ok=True)
    (xml_dir / 'gacnoba_paths.xml').write_text('<?xml version="1.0" encoding="utf-8"?>\n<paths>\n    <cache-path name="gacnoba_cache" path="."/>\n</paths>\n')
    if 'supportsPictureInPicture' not in s:
        s = s.replace('<activity ', '<activity android:supportsPictureInPicture="true" ', 1)
    print('native call ring installed in', kt_dir, 'package', pkg)
else:
    print('WARNING: MainActivity.kt not found, call ring not installed')
manifest.write_text(s)

# ---- launcher icon + notification icon ----
icons = pathlib.Path('tool/icons')
res = root / 'src/main/res'
if icons.exists():
    for src in icons.glob('*/*.png'):
        dst_dir = res / src.parent.name
        dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy(src, dst_dir / src.name)
    # remove adaptive-icon xml if a template ever created one (would hide our png)
    for p in res.glob('mipmap-anydpi*/ic_launcher*.xml'):
        p.unlink()
    print('icons copied')

# ---- minSdk + stable signing key ----
signing = '''
    signingConfigs {
        create("gacnoba") {
            storeFile = file("../../tool/gacnoba.p12")
            storePassword = "gacnoba123456"
            keyAlias = "gacnoba"
            keyPassword = "gacnoba123456"
            storeType = "pkcs12"
        }
    }
'''
for name in ('build.gradle', 'build.gradle.kts'):
    p = root / name
    if not p.exists():
        continue
    t = p.read_text()
    t = re.sub(r'minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)', 'minSdk = 24', t)
    if name.endswith('.kts'):
        if 'create("gacnoba")' not in t:
            t = t.replace('android {', 'android {' + signing, 1)
        t = re.sub(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
                   'signingConfig = signingConfigs.getByName("gacnoba")', t)
    else:
        groovy = '''
    signingConfigs {
        gacnoba {
            storeFile file("../../tool/gacnoba.p12")
            storePassword "gacnoba123456"
            keyAlias "gacnoba"
            keyPassword "gacnoba123456"
            storeType "pkcs12"
        }
    }
'''
        if 'gacnoba {' not in t:
            t = t.replace('android {', 'android {' + groovy, 1)
        t = re.sub(r'signingConfig\s+signingConfigs\.debug', 'signingConfig signingConfigs.gacnoba', t)
    # The Kotlin push extension needs the OneSignal Android classes at compile time.
    # Use the full umbrella artifact (as in OneSignal's docs) so core + notifications are on the classpath.
    if 'com.onesignal:OneSignal' not in t:
        if name.endswith('.kts'):
            t += '\ndependencies {\n    implementation("com.onesignal:OneSignal:[5.1.0,5.1.99]")\n}\n'
        else:
            t += "\ndependencies {\n    implementation 'com.onesignal:OneSignal:[5.1.0,5.1.99]'\n}\n"
    p.write_text(t)
    print('patched', p)
print('manifest patched')

# Agora's native libraries share one namespace (io.agora.rtc); newer Android Gradle
# Plugin versions reject that unless the uniqueness check is switched off.
props = pathlib.Path('android/gradle.properties')
txt = props.read_text() if props.exists() else ''
if 'android.uniquePackageNames' not in txt:
    if txt and not txt.endswith('\n'):
        txt += '\n'
    txt += 'android.uniquePackageNames=false\n'
    props.write_text(txt)
print('gradle.properties patched')
