"""Patch the generated Android project (run after `flutter create`)."""
import pathlib
import re

root = pathlib.Path('android/app')
manifest = root / 'src/main/AndroidManifest.xml'
s = manifest.read_text()

perms = [
    'INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO',
    'MODIFY_AUDIO_SETTINGS', 'BLUETOOTH_CONNECT', 'POST_NOTIFICATIONS',
    'WAKE_LOCK', 'VIBRATE',
]
add = ''.join(
    f'    <uses-permission android:name="android.permission.{p}"/>\n'
    for p in perms if f'android.permission.{p}"' not in s
)
s = s.replace('<application', add + '    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Gacnoba"', s, count=1)
manifest.write_text(s)

# Agora / OneSignal need a minimum SDK of 24 to be safe.
for name in ('build.gradle', 'build.gradle.kts'):
    p = root / name
    if p.exists():
        t = p.read_text()
        t = re.sub(r'minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)', 'minSdk = 24', t)
        p.write_text(t)
        print('patched', p)
print('manifest patched')
