"""Raise compileSdk of old plugins (e.g. agora_rtc_engine uses 31) to 36.
Run after `flutter pub get`."""
import os
import pathlib
import re

TARGET = 36
cache = pathlib.Path(os.environ.get('PUB_CACHE') or (pathlib.Path.home() / '.pub-cache'))
pat = re.compile(r'(compileSdk(?:Version)?\s*=?\s*)(\d+)')

def bump(m):
    return m.group(1) + str(TARGET) if int(m.group(2)) < TARGET else m.group(0)

count = 0
for gradle in cache.glob('hosted/*/*/android/build.gradle*'):
    text = gradle.read_text()
    new = pat.sub(bump, text)
    if new != text:
        gradle.write_text(new)
        count += 1
        print('patched', gradle)
print('plugins patched:', count)
