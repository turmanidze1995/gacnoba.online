package __PKG__

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Starts the background connection again after the phone was restarted. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        try {
            val p = ctx.getSharedPreferences("gacnoba_native", Context.MODE_PRIVATE)
            if ((p.getString("token", "") ?: "").isEmpty()) return
            val svc = Intent(ctx, PollService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(svc) else ctx.startService(svc)
        } catch (_: Throwable) {
        }
    }
}
