package __PKG__

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.util.Rational
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    private var pendingPick: MethodChannel.Result? = null
    private var preview: Ringtone? = null
    private var channel: MethodChannel? = null
    private var callActive = false
    private var pendingChat: Map<String, String>? = null

    private fun captureChat(i: Intent?) {
        val u = i?.getStringExtra("gacnoba_open_user") ?: ""
        if (u.isNotEmpty()) {
            pendingChat = mapOf(
                "user_id" to u,
                "name" to (i?.getStringExtra("gacnoba_open_name") ?: ""),
                "avatar" to (i?.getStringExtra("gacnoba_open_avatar") ?: "")
            )
        }
    }

    override fun onResume() {
        super.onResume()
        AppState.foreground = true
        FloatingBubble.removeAll(this)
    }

    override fun onPause() {
        AppState.foreground = false
        super.onPause()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (callActive && Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(9, 16)).build()
                )
            } catch (_: Throwable) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        channel?.invokeMethod("pip", isInPictureInPictureMode)
    }

    private fun nativePrefs() = getSharedPreferences("gacnoba_native", MODE_PRIVATE)

    private fun ringtoneUri(): Uri {
        val s = nativePrefs().getString("ring_uri", null)
        return if (!s.isNullOrEmpty()) Uri.parse(s)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
    }

    private fun applyCallFlags(i: Intent?) {
        // Only a call notification may show the app over the lock screen.
        val c = i?.getBooleanExtra("gacnoba_call", false) == true
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(c)
            setTurnScreenOn(c)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyCallFlags(intent)
        captureChat(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        applyCallFlags(intent)
        captureChat(intent)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_RING) {
            val res = pendingPick
            pendingPick = null
            if (resultCode == Activity.RESULT_OK && data != null) {
                val uri = data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                val str = uri?.toString() ?: ""
                var title = ""
                try {
                    if (uri != null) title = RingtoneManager.getRingtone(this, uri).getTitle(this)
                } catch (_: Throwable) {
                }
                nativePrefs().edit().putString("ring_uri", str).putString("ring_title", title).apply()
                res?.success(mapOf("uri" to str, "title" to title))
            } else {
                res?.success(null)
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "gacnoba/call")
        channel = ch
        ch.setMethodCallHandler { call, result ->
                when (call.method) {
                    "stopRing" -> {
                        CallRing.cancel(this)
                        result.success(null)
                    }
                    "getRingtone" -> {
                        val p = nativePrefs()
                        result.success(
                            mapOf(
                                "uri" to (p.getString("ring_uri", "") ?: ""),
                                "title" to (p.getString("ring_title", "") ?: "")
                            )
                        )
                    }
                    "resetRingtone" -> {
                        nativePrefs().edit().remove("ring_uri").remove("ring_title").apply()
                        result.success(null)
                    }
                    "pickRingtone" -> {
                        if (pendingPick != null) {
                            result.success(null)
                        } else {
                            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtoneUri())
                            pendingPick = result
                            try {
                                startActivityForResult(i, REQ_RING)
                            } catch (e: Throwable) {
                                pendingPick = null
                                result.success(null)
                            }
                        }
                    }
                    "previewRingtone" -> {
                        try {
                            preview?.stop()
                            val r = RingtoneManager.getRingtone(this, ringtoneUri())
                            preview = r
                            r.play()
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "stopPreview" -> {
                        try {
                            preview?.stop()
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "openNotificationSettings" -> {
                        try {
                            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            startActivity(i)
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "callActive" -> {
                        val active = call.argument<Boolean>("active") == true
                        callActive = active
                        val svc = Intent(this, CallService::class.java)
                        if (active) {
                            svc.putExtra("name", call.argument<String>("name") ?: "")
                            svc.putExtra("video", call.argument<Boolean>("video") == true)
                            try {
                                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
                            } catch (_: Throwable) {
                            }
                        } else {
                            try {
                                stopService(svc)
                            } catch (_: Throwable) {
                            }
                        }
                        result.success(null)
                    }
                    "canOverlay" -> result.success(FloatingBubble.canDraw(this))
                    "requestOverlay" -> {
                        try {
                            startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            )
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "takePendingChat" -> {
                        val p = pendingChat
                        pendingChat = null
                        result.success(p)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    companion object {
        private const val REQ_RING = 4711
    }
}
