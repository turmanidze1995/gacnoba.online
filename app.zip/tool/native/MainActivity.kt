package __PKG__

import android.content.Intent
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private fun applyCallFlags(i: Intent?) {
        // Only a call notification may show the app over the lock screen.
        val c = i?.getBooleanExtra("gacnoba_call", false) == true
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(c)
            setTurnScreenOn(c)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyCallFlags(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        applyCallFlags(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "gacnoba/call")
            .setMethodCallHandler { call, result ->
                if (call.method == "stopRing") {
                    CallRing.cancel(this)
                    result.success(null)
                } else {
                    result.notImplemented()
                }
            }
    }
}
