package __PKG__

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.util.Rational
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    private var pendingPick: MethodChannel.Result? = null
    private var preview: Ringtone? = null
    private var channel: MethodChannel? = null
    private var callActive = false
    private var pendingChat: Map<String, String>? = null

    private fun captureAnswer(i: Intent?) {
        if (i?.getBooleanExtra("gacnoba_answer", false) == true) {
            AppState.answerAt = System.currentTimeMillis()
            i?.removeExtra("gacnoba_answer")
        }
    }

    private fun captureChat(i: Intent?) {
        val u = i?.getStringExtra("gacnoba_open_user") ?: ""
        if (u.isNotEmpty()) {
            pendingChat = mapOf(
                "user_id" to u,
                "name" to (i?.getStringExtra("gacnoba_open_name") ?: ""),
                "avatar" to (i?.getStringExtra("gacnoba_open_avatar") ?: "")
            )
        }
    }

    override fun onResume() {
        super.onResume()
        AppState.foreground = true
        FloatingBubble.removeAll(this)
    }

    override fun onPause() {
        AppState.foreground = false
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !callActive) FloatingBubble.reshow(this)
    }

    /** Small picture-in-picture window parameters. On Android 12+ the window opens by itself
     *  (home gesture / home button / app switch) as long as a call is running. */
    private fun pipParams(): PictureInPictureParams {
        val b = PictureInPictureParams.Builder().setAspectRatio(Rational(9, 16))
        if (Build.VERSION.SDK_INT >= 31) {
            b.setAutoEnterEnabled(callActive)
            b.setSeamlessResizeEnabled(true)
        }
        return b.build()
    }

    private fun refreshPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                setPictureInPictureParams(pipParams())
            } catch (_: Throwable) {
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (callActive && Build.VERSION.SDK_INT >= 26 && !(Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode)) {
            try {
                enterPictureInPictureMode(pipParams())
            } catch (_: Throwable) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        channel?.invokeMethod("pip", isInPictureInPictureMode)
    }

    private fun nativePrefs() = getSharedPreferences("gacnoba_native", MODE_PRIVATE)

    private fun ringtoneUri(): Uri {
        val s = nativePrefs().getString("ring_uri", null)
        return if (!s.isNullOrEmpty()) Uri.parse(s)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
    }

    private fun applyCallFlags(i: Intent?) {
        // Only a call notification may show the app over the lock screen.
        val c = i?.getBooleanExtra("gacnoba_call", false) == true
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(c)
            setTurnScreenOn(c)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyCallFlags(intent)
        captureChat(intent)
        captureAnswer(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyCallFlags(intent)
        captureChat(intent)
        captureAnswer(intent)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_RING) {
            val res = pendingPick
            pendingPick = null
            if (resultCode == Activity.RESULT_OK && data != null) {
                val uri = data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                val str = uri?.toString() ?: ""
                var title = ""
                try {
                    if (uri != null) title = RingtoneManager.getRingtone(this, uri).getTitle(this)
                } catch (_: Throwable) {
                }
                nativePrefs().edit().putString("ring_uri", str).putString("ring_title", title).apply()
                res?.success(mapOf("uri" to str, "title" to title))
            } else {
                res?.success(null)
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "gacnoba/call")
        channel = ch
        ch.setMethodCallHandler { call, result ->
                when (call.method) {
                    "stopRing" -> {
                        CallRing.cancel(this)
                        result.success(null)
                    }
                    "getRingtone" -> {
                        val p = nativePrefs()
                        result.success(
                            mapOf(
                                "uri" to (p.getString("ring_uri", "") ?: ""),
                                "title" to (p.getString("ring_title", "") ?: "")
                            )
                        )
                    }
                    "resetRingtone" -> {
                        nativePrefs().edit().remove("ring_uri").remove("ring_title").apply()
                        result.success(null)
                    }
                    "pickRingtone" -> {
                        if (pendingPick != null) {
                            result.success(null)
                        } else {
                            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtoneUri())
                            pendingPick = result
                            try {
                                startActivityForResult(i, REQ_RING)
                            } catch (e: Throwable) {
                                pendingPick = null
                                result.success(null)
                            }
                        }
                    }
                    "previewRingtone" -> {
                        try {
                            preview?.stop()
                            val r = RingtoneManager.getRingtone(this, ringtoneUri())
                            preview = r
                            r.play()
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "stopPreview" -> {
                        try {
                            preview?.stop()
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "openNotificationSettings" -> {
                        try {
                            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            startActivity(i)
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "openBgChannelSettings" -> {
                        try {
                            val i = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            i.putExtra(Settings.EXTRA_CHANNEL_ID, "gacnoba_bg")
                            startActivity(i)
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "callActive" -> {
                        val active = call.argument<Boolean>("active") == true
                        callActive = active
                        refreshPip()
                        val svc = Intent(this, CallService::class.java)
                        if (active) {
                            svc.putExtra("name", call.argument<String>("name") ?: "")
                            svc.putExtra("video", call.argument<Boolean>("video") == true)
                            try {
                                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
                            } catch (_: Throwable) {
                            }
                        } else {
                            try {
                                stopService(svc)
                            } catch (_: Throwable) {
                            }
                        }
                        result.success(null)
                    }
                    "versionCode" -> {
                        try {
                            val info = packageManager.getPackageInfo(packageName, 0)
                            @Suppress("DEPRECATION")
                            val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
                            result.success(code.toInt())
                        } catch (_: Throwable) {
                            result.success(0)
                        }
                    }
                    "installApk" -> {
                        try {
                            if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                                startActivity(
                                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                                )
                                result.success("need_permission")
                            } else {
                                // FileProvider only serves files from the cache folder; the
                                // downloaded APK is in code_cache, so copy it first.
                                val src = java.io.File(call.argument<String>("path") ?: "")
                                val dir = java.io.File(cacheDir, "updates")
                                dir.mkdirs()
                                val f = java.io.File(dir, "gacnoba_update.apk")
                                src.copyTo(f, overwrite = true)
                                val uri = androidx.core.content.FileProvider.getUriForFile(
                                    this, "$packageName.gacnobafiles", f
                                )
                                val i = Intent(Intent.ACTION_VIEW)
                                i.setDataAndType(uri, "application/vnd.android.package-archive")
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(i)
                                result.success("ok")
                            }
                        } catch (e: Throwable) {
                            result.success("error:" + e.message)
                        }
                    }
                    "canOverlay" -> result.success(FloatingBubble.canDraw(this))
                    "requestOverlay" -> {
                        try {
                            startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            )
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "startBackground" -> {
                        try {
                            nativePrefs().edit()
                                .putString("site", call.argument<String>("site") ?: "")
                                .putString("server_key", call.argument<String>("serverKey") ?: "")
                                .putString("token", call.argument<String>("token") ?: "")
                                .putString("set_online", if (call.argument<Boolean>("online") == false) "0" else "1")
                                .apply()
                            val svc = Intent(this, PollService::class.java)
                            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "stopBackground" -> {
                        try {
                            nativePrefs().edit().remove("token").remove("last_alert").apply()
                            stopService(Intent(this, PollService::class.java))
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "batteryExempt" -> {
                        try {
                            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                            if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(packageName)) {
                                startActivity(
                                    Intent(
                                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                        Uri.parse("package:$packageName")
                                    )
                                )
                            }
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "ring" -> {
                        try {
                            CallRing.show(
                                this,
                                call.argument<String>("title") ?: "",
                                call.argument<String>("text") ?: "",
                                call.argument<String>("id") ?: "",
                                call.argument<String>("kind") ?: "video"
                            )
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "notify" -> {
                        try {
                            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                            if (Build.VERSION.SDK_INT >= 26) {
                                nm.createNotificationChannel(
                                    android.app.NotificationChannel(
                                        "gacnoba_alerts", "Notifications",
                                        android.app.NotificationManager.IMPORTANCE_HIGH
                                    )
                                )
                            }
                            val launch = packageManager.getLaunchIntentForPackage(packageName)
                            val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                                (if (Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0)
                            val nid = call.argument<Int>("id") ?: 0
                            var icon = resources.getIdentifier("ic_stat_onesignal_default", "drawable", packageName)
                            if (icon == 0) icon = android.R.drawable.ic_dialog_info
                            val b: android.app.Notification.Builder =
                                if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, "gacnoba_alerts")
                                else android.app.Notification.Builder(this)
                            b.setSmallIcon(icon)
                                .setContentTitle(call.argument<String>("title") ?: "")
                                .setContentText(call.argument<String>("body") ?: "")
                                .setAutoCancel(true)
                                .setOnlyAlertOnce(true)
                            if (launch != null) {
                                b.setContentIntent(android.app.PendingIntent.getActivity(this, nid, launch, flags))
                            }
                            nm.notify(10000 + (nid % 50000), b.build())
                        } catch (_: Throwable) {
                        }
                        result.success(null)
                    }
                    "takeAnswerRequest" -> {
                        val t = AppState.answerAt
                        AppState.answerAt = 0L
                        result.success(t > 0L && System.currentTimeMillis() - t < 90000L)
                    }
                    "takePendingChat" -> {
                        val p = pendingChat
                        pendingChat = null
                        result.success(p)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    companion object {
        private const val REQ_RING = 4711
    }
}
