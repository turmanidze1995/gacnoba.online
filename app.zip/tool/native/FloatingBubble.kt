package __PKG__

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.sqrt

object AppState {
    @Volatile
    var foreground = false
}

/** Messenger-style floating chat bubble: drag it, tap to open the chat, drop it on the X to remove. */
object FloatingBubble {
    private val main = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var badge: TextView? = null
    private var closeView: TextView? = null
    private var count = 0
    private var curUser = ""
    private var curName = ""
    private var curAvatar = ""

    // The bubble stays on the screen after the chat was opened and left again,
    // until the person drops it on the X (like Messenger).
    @Volatile
    private var keepUser = ""
    private var keepName = ""
    private var keepAvatar = ""

    fun canDraw(ctx: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    private fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    fun show(ctx0: Context, userId: String, name: String, avatar: String?) {
        val ctx = ctx0.applicationContext
        if (userId.isEmpty() || AppState.foreground || !canDraw(ctx)) return
        main.post {
            try {
                showOnMain(ctx, userId, name, avatar ?: "")
            } catch (_: Throwable) {
            }
        }
    }

    fun removeAll(ctx0: Context) {
        val ctx = ctx0.applicationContext
        main.post {
            try {
                hideClose(ctx)
                removeBubble(ctx)
            } catch (_: Throwable) {
            }
        }
    }

    private fun removeBubble(ctx: Context) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Throwable) {
            }
        }
        root = null
        badge = null
        count = 0
        curUser = ""
        MiniChat.hide(ctx)
    }

    private fun showClose(ctx: Context) {
        if (closeView != null) return
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val tv = TextView(ctx)
        tv.text = "✕"
        tv.setTextColor(Color.WHITE)
        tv.textSize = 24f
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xCC222222.toInt())
        tv.background = bg
        val s = dp(ctx, 64)
        val p = WindowManager.LayoutParams(
            s, s, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        p.y = dp(ctx, 48)
        wm.addView(tv, p)
        closeView = tv
    }

    private fun hideClose(ctx: Context) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        closeView?.let {
            try {
                wm.removeView(it)
            } catch (_: Throwable) {
            }
        }
        closeView = null
    }

    private fun overClose(ctx: Context, p: WindowManager.LayoutParams, size: Int): Boolean {
        val dm = ctx.resources.displayMetrics
        val bx = p.x + size / 2f
        val by = p.y + size / 2f
        val cx = dm.widthPixels / 2f
        val cy = dm.heightPixels - dp(ctx, 48) - dp(ctx, 32).toFloat()
        val dx = bx - cx
        val dy = by - cy
        return sqrt(dx * dx + dy * dy) < dp(ctx, 76)
    }

    /** Called when the app goes to the background: brings the bubble back. */
    fun reshow(ctx0: Context) {
        if (keepUser.isEmpty()) return
        val ctx = ctx0.applicationContext
        if (!canDraw(ctx) || AppState.foreground) return
        main.post {
            try {
                showOnMain(ctx, keepUser, keepName, keepAvatar)
                count = 0
                badge?.visibility = View.GONE
            } catch (_: Throwable) {
            }
        }
    }

    /** Tap on the bubble: small chat window first, "↗" in it opens the full chat. */
    private fun toggleMini(ctx: Context) {
        if (MiniChat.isOpen()) {
            MiniChat.hide(ctx)
            return
        }
        count = 0
        badge?.visibility = View.GONE
        try {
            MiniChat.show(ctx, curUser, curName) { openChat(ctx) }
        } catch (_: Throwable) {
            openChat(ctx)
        }
    }

    private fun openChat(ctx: Context) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            launch.putExtra("gacnoba_open_user", curUser)
            launch.putExtra("gacnoba_open_name", curName)
            launch.putExtra("gacnoba_open_avatar", curAvatar)
            keepUser = curUser
            keepName = curName
            keepAvatar = curAvatar
            try {
                ctx.startActivity(launch)
            } catch (_: Throwable) {
            }
        }
        removeBubble(ctx)
    }

    private fun showOnMain(ctx: Context, userId: String, name: String, avatar: String) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (root != null && curUser == userId) {
            if (!MiniChat.isOpen()) {
                count++
                badge?.text = count.toString()
                badge?.visibility = View.VISIBLE
            }
            return
        }
        removeBubble(ctx)
        curUser = userId
        curName = name
        curAvatar = avatar
        keepUser = userId
        keepName = name
        keepAvatar = avatar
        count = 1

        val size = dp(ctx, 60)
        val r = FrameLayout(ctx)
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xFF8B4A4A.toInt())
        iv.background = bg
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        iv.clipToOutline = true
        iv.setImageResource(android.R.drawable.sym_action_chat)
        iv.setPadding(dp(ctx, 14), dp(ctx, 14), dp(ctx, 14), dp(ctx, 14))
        r.addView(iv, FrameLayout.LayoutParams(size, size))

        val bd = TextView(ctx)
        bd.setTextColor(Color.WHITE)
        bd.textSize = 11f
        bd.gravity = Gravity.CENTER
        val bbg = GradientDrawable()
        bbg.shape = GradientDrawable.OVAL
        bbg.setColor(0xFFE53935.toInt())
        bd.background = bbg
        bd.text = "1"
        r.addView(bd, FrameLayout.LayoutParams(dp(ctx, 20), dp(ctx, 20), Gravity.TOP or Gravity.END))
        badge = bd

        val dm = ctx.resources.displayMetrics
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dm.widthPixels - size
        p.y = dm.heightPixels / 3

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x
                    sy = p.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (!moved && (abs(dx) > dp(ctx, 8) || abs(dy) > dp(ctx, 8))) {
                        moved = true
                        showClose(ctx)
                    }
                    if (moved) {
                        p.x = (sx + dx).toInt()
                        p.y = (sy + dy).toInt()
                        try {
                            wm.updateViewLayout(r, p)
                        } catch (_: Throwable) {
                        }
                        val hot = overClose(ctx, p, size)
                        closeView?.scaleX = if (hot) 1.3f else 1f
                        closeView?.scaleY = if (hot) 1.3f else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        toggleMini(ctx)
                    } else {
                        val over = overClose(ctx, p, size)
                        hideClose(ctx)
                        if (over) {
                            keepUser = ""
                            removeBubble(ctx)
                        } else {
                            p.x = if (p.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
                            try {
                                wm.updateViewLayout(r, p)
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    hideClose(ctx)
                    true
                }
                else -> false
            }
        }
        wm.addView(r, p)
        root = r

        if (avatar.startsWith("http")) {
            Thread {
                try {
                    val c = URL(avatar).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000
                    c.readTimeout = 8000
                    val bmp = BitmapFactory.decodeStream(c.inputStream)
                    if (bmp != null) {
                        main.post {
                            iv.setPadding(0, 0, 0, 0)
                            iv.setImageBitmap(bmp)
                        }
                    }
                } catch (_: Throwable) {
                }
            }.start()
        }
    }
}
