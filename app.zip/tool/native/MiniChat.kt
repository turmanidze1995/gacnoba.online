package __PKG__

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Small chat window that opens when the floating bubble is tapped: the last
 * messages, a text box and a button that opens the full chat inside the app.
 */
object MiniChat {
    private class Msg(val mine: Boolean, val text: String)

    private val main = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var list: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null
    private var appCtx: Context? = null
    private var user = ""
    private var lastSig = ""

    private val ticker = object : Runnable {
        override fun run() {
            if (panel == null) return
            refresh()
            main.postDelayed(this, 4000)
        }
    }

    fun isOpen(): Boolean = panel != null

    private fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun iconButton(ctx: Context, label: String, action: () -> Unit): TextView {
        val tv = TextView(ctx)
        tv.text = label
        tv.textSize = 20f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(0xFF8B4A4A.toInt())
        tv.setOnClickListener { action() }
        return tv
    }

    fun show(ctx0: Context, userId: String, name: String, onFull: () -> Unit) {
        val ctx = ctx0.applicationContext
        hide(ctx)
        appCtx = ctx
        user = userId
        lastSig = ""
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = ctx.resources.displayMetrics

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xFFFFF8F7.toInt())
        bg.cornerRadius = dp(ctx, 18).toFloat()
        bg.setStroke(dp(ctx, 1), 0x33000000)
        box.background = bg

        // header: name, "open full chat", close
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(ctx, 14), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4))
        val title = TextView(ctx)
        title.text = name
        title.textSize = 16f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(0xFF3B2323.toInt())
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val s = dp(ctx, 44)
        head.addView(iconButton(ctx, "↗") {
            hide(ctx)
            onFull()
        }, LinearLayout.LayoutParams(s, s))
        head.addView(iconButton(ctx, "✕") { hide(ctx) }, LinearLayout.LayoutParams(s, s))
        box.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // messages
        val sc = ScrollView(ctx)
        val ls = LinearLayout(ctx)
        ls.orientation = LinearLayout.VERTICAL
        ls.setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 10), dp(ctx, 4))
        sc.addView(ls, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // text box + send
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(ctx, 8), dp(ctx, 4), dp(ctx, 4), dp(ctx, 8))
        val et = EditText(ctx)
        et.hint = "შეტყობინება"
        et.textSize = 15f
        et.setTextColor(0xFF3B2323.toInt())
        et.maxLines = 3
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        val ebg = GradientDrawable()
        ebg.setColor(0xFFF3E3E1.toInt())
        ebg.cornerRadius = dp(ctx, 20).toFloat()
        et.background = ebg
        et.setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(iconButton(ctx, "➤") { sendNow() }, LinearLayout.LayoutParams(s, s))
        box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val w = minOf(dm.widthPixels - dp(ctx, 24), dp(ctx, 400))
        val h = (dm.heightPixels * 0.55f).toInt()
        val p = WindowManager.LayoutParams(
            w, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(ctx, 56)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(box, p)

        panel = box
        list = ls
        scroll = sc
        input = et
        main.post(ticker)
    }

    fun hide(ctx0: Context) {
        main.removeCallbacks(ticker)
        val ctx = ctx0.applicationContext
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = panel
        if (v != null) {
            try {
                wm.removeView(v)
            } catch (_: Throwable) {
            }
        }
        panel = null
        list = null
        scroll = null
        input = null
    }

    private fun refresh() {
        val ctx = appCtx ?: return
        val uid = user
        Thread {
            val msgs = fetch(ctx, uid)
            if (msgs != null) {
                main.post { render(ctx, msgs) }
            }
        }.start()
    }

    private fun render(ctx: Context, msgs: List<Msg>) {
        val ls = list ?: return
        val sc = scroll ?: return
        val sig = msgs.joinToString("|") { (if (it.mine) "1" else "0") + it.text }
        if (sig == lastSig) return
        lastSig = sig
        ls.removeAllViews()
        for (m in msgs) addBubble(ctx, ls, m)
        sc.post { sc.scrollTo(0, ls.height) }
    }

    private fun addBubble(ctx: Context, ls: LinearLayout, m: Msg) {
        val tv = TextView(ctx)
        tv.text = m.text
        tv.textSize = 15f
        tv.maxWidth = dp(ctx, 270)
        tv.setPadding(dp(ctx, 12), dp(ctx, 7), dp(ctx, 12), dp(ctx, 7))
        val b = GradientDrawable()
        b.cornerRadius = dp(ctx, 14).toFloat()
        if (m.mine) {
            b.setColor(0xFF8B4A4A.toInt())
            tv.setTextColor(Color.WHITE)
        } else {
            b.setColor(0xFFEFE0DE.toInt())
            tv.setTextColor(0xFF3B2323.toInt())
        }
        tv.background = b
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (m.mine) Gravity.END else Gravity.START
        lp.topMargin = dp(ctx, 3)
        lp.bottomMargin = dp(ctx, 3)
        ls.addView(tv, lp)
    }

    private fun sendNow() {
        val et = input ?: return
        val ctx = appCtx ?: return
        val txt = et.text.toString().trim()
        if (txt.isEmpty()) return
        et.setText("")
        val ls = list
        if (ls != null) {
            addBubble(ctx, ls, Msg(true, txt))
            scroll?.post { scroll?.scrollTo(0, ls.height) }
        }
        lastSig = ""
        val uid = user
        Thread {
            post(ctx, "send-message", mapOf("user_id" to uid, "text" to txt, "message_hash_id" to System.nanoTime().toString()))
            main.post { refresh() }
        }.start()
    }

    // ---------- network ----------
    private fun clean(s: String): String =
        s.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#039;", "'").replace("&#39;", "'").trim()

    /** The site sends message text as AES-128-ECB, key = the message time (zero padded to 16 bytes). */
    private fun decrypt(text: String, time: String): String {
        if (text.isEmpty()) return ""
        return try {
            val key = ByteArray(16)
            val t = time.toByteArray(Charsets.UTF_8)
            for (i in 0 until minOf(16, t.size)) key[i] = t[i]
            val c = Cipher.getInstance("AES/ECB/PKCS5Padding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"))
            String(c.doFinal(android.util.Base64.decode(text, android.util.Base64.DEFAULT)), Charsets.UTF_8)
        } catch (_: Throwable) {
            text
        }
    }

    private fun fetch(ctx: Context, uid: String): List<Msg>? {
        val res = post(ctx, "get_user_messages", mapOf("recipient_id" to uid, "limit" to "25")) ?: return null
        val arr = res.optJSONArray("messages") ?: return null
        val out = ArrayList<Msg>()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            val from = m.optString("from_id", "")
            var t = clean(decrypt(m.optString("text", ""), m.optString("time", "")))
            if (t.isEmpty()) {
                val lat = m.optString("lat", "")
                if (m.optString("media", "").isNotEmpty()) t = "📎"
                else if (lat.isNotEmpty() && lat != "0") t = "📍"
            }
            if (t.isEmpty()) continue
            out.add(Msg(from != uid, t))
        }
        return out
    }

    private fun post(ctx: Context, endpoint: String, f: Map<String, String>): JSONObject? {
        var c: HttpURLConnection? = null
        try {
            val p = ctx.getSharedPreferences("gacnoba_native", Context.MODE_PRIVATE)
            val site = p.getString("site", "") ?: ""
            val token = p.getString("token", "") ?: ""
            val key = p.getString("server_key", "") ?: ""
            if (site.isEmpty() || token.isEmpty()) return null
            val url = URL("$site/api/$endpoint?access_token=" + URLEncoder.encode(token, "UTF-8"))
            c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.doOutput = true
            val all = HashMap<String, String>()
            all["server_key"] = key
            all.putAll(f)
            val body = all.entries.joinToString("&") {
                URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
            }
            c.outputStream.use { it.write(body.toByteArray()) }
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(txt)
        } catch (_: Throwable) {
            return null
        } finally {
            try {
                c?.disconnect()
            } catch (_: Throwable) {
            }
        }
    }
}
