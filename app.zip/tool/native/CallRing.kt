package __PKG__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build

/** Rings like a phone call (full screen notification + ringtone) when a call push arrives. */
object CallRing {
    const val CHANNEL_ID = "gacnoba_calls_v1"
    const val NOTIF_ID = 7771
    private val pattern = longArrayOf(0, 800, 600, 800, 600)

    fun show(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // ringtone chosen in the app (Settings > Sounds); a new channel id per ringtone,
        // because Android does not allow changing the sound of an existing channel
        val saved = ctx.getSharedPreferences("gacnoba_native", Context.MODE_PRIVATE)
            .getString("ring_uri", null)
        val uri: Uri = if (!saved.isNullOrEmpty()) Uri.parse(saved)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val chId = if (saved.isNullOrEmpty()) CHANNEL_ID else CHANNEL_ID + "_" + Integer.toHexString(saved.hashCode())
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(chId, "Calls", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                uri,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ch.enableVibration(true)
            ch.vibrationPattern = pattern
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return
        launch.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        launch.putExtra("gacnoba_call", true)
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val pi = PendingIntent.getActivity(ctx, NOTIF_ID, launch, piFlags)

        var icon = ctx.resources.getIdentifier("ic_stat_onesignal_default", "drawable", ctx.packageName)
        if (icon == 0) icon = android.R.drawable.sym_call_incoming

        @Suppress("DEPRECATION")
        val b: Notification.Builder =
            if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, chId)
            else Notification.Builder(ctx)
        b.setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (Build.VERSION.SDK_INT < 26) {
            @Suppress("DEPRECATION")
            b.setSound(uri).setVibrate(pattern).setPriority(Notification.PRIORITY_MAX)
        } else {
            b.setTimeoutAfter(40000)
        }
        val n = b.build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(NOTIF_ID, n)
    }

    fun cancel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIF_ID)
    }
}
