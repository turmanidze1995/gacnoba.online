package __PKG__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.Person

/**
 * Rings like a phone call. The notification is shown at the top of the screen
 * (also over the lock screen) with a green "answer" and a red "decline" handset button.
 */
object CallRing {
    const val CHANNEL_ID = "gacnoba_calls_v1"
    const val NOTIF_ID = 7771
    private val pattern = longArrayOf(0, 800, 600, 800, 600)

    fun show(ctx: Context, title: String, text: String, callId: String = "", kind: String = "video") {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // ringtone chosen in the app (Settings > Sounds); a new channel id per ringtone,
        // because Android does not allow changing the sound of an existing channel
        val saved = ctx.getSharedPreferences("gacnoba_native", Context.MODE_PRIVATE)
            .getString("ring_uri", null)
        val uri: Uri = if (!saved.isNullOrEmpty()) Uri.parse(saved)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val chId = if (saved.isNullOrEmpty()) CHANNEL_ID else CHANNEL_ID + "_" + Integer.toHexString(saved.hashCode())
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(chId, "Calls", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                uri,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ch.enableVibration(true)
            ch.vibrationPattern = pattern
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        val base = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return
        val flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

        // tap on the notification / full screen: opens the ringing screen
        val open = Intent(base).addFlags(flags).putExtra("gacnoba_call", true)
        val openPi = PendingIntent.getActivity(ctx, NOTIF_ID, open, piFlags)
        // green button: opens the app and answers at once
        val answer = Intent(base).addFlags(flags).putExtra("gacnoba_call", true).putExtra("gacnoba_answer", true)
        val answerPi = PendingIntent.getActivity(ctx, NOTIF_ID + 1, answer, piFlags)
        // red button: declines in the background, the app does not open
        val decline = Intent(ctx, CallActionReceiver::class.java)
            .setAction(CallActionReceiver.ACTION_DECLINE)
            .putExtra("call_id", callId)
            .putExtra("kind", kind)
        val declinePi = PendingIntent.getBroadcast(ctx, NOTIF_ID + 2, decline, piFlags)

        var icon = ctx.resources.getIdentifier("ic_stat_onesignal_default", "drawable", ctx.packageName)
        if (icon == 0) icon = android.R.drawable.sym_call_incoming

        val n = build(ctx, chId, icon, title, text, openPi, answerPi, declinePi, uri, true)
            ?: build(ctx, chId, icon, title, text, openPi, answerPi, declinePi, uri, false)
            ?: return
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(NOTIF_ID, n)
    }

    private fun build(
        ctx: Context, chId: String, icon: Int, title: String, text: String,
        openPi: PendingIntent, answerPi: PendingIntent, declinePi: PendingIntent,
        uri: Uri, callStyle: Boolean
    ): Notification? {
        return try {
            val b = NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setTimeoutAfter(40000)
            if (Build.VERSION.SDK_INT < 26) {
                b.setSound(uri).setVibrate(pattern)
            }
            if (callStyle) {
                val person = Person.Builder().setName(if (title.isEmpty()) "GACNOBA" else title).setImportant(true).build()
                b.setStyle(NotificationCompat.CallStyle.forIncomingCall(person, declinePi, answerPi))
            } else {
                b.addAction(android.R.drawable.sym_action_call, "✆ პასუხი", answerPi)
                b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "✖ გათიშვა", declinePi)
            }
            b.build()
        } catch (_: Throwable) {
            null
        }
    }

    fun cancel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIF_ID)
    }
}
