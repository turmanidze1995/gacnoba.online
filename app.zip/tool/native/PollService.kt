package __PKG__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Keeps running when the app is closed: asks the site every few seconds for
 * incoming calls (rings like a phone call) and for new notifications
 * (likes, reactions, comments ...) and shows them as phone notifications.
 */
class PollService : Service() {
    @Volatile
    private var running = false
    private var worker: Thread? = null
    private val lastCall = HashMap<String, String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Background connection", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        var icon = resources.getIdentifier("ic_stat_onesignal_default", "drawable", packageName)
        if (icon == 0) icon = android.R.drawable.ic_dialog_info
        @Suppress("DEPRECATION")
        val b: Notification.Builder =
            if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        b.setSmallIcon(icon)
            .setContentTitle("GACNOBA.ONLINE")
            .setContentText("ზარები და შეტყობინებები ჩართულია")
            .setOngoing(true)
        if (launch != null) b.setContentIntent(PendingIntent.getActivity(this, ID, launch, piFlags))
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID, b.build())
            }
        } catch (_: Throwable) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            worker = Thread { loop() }.also {
                it.isDaemon = true
                it.start()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    private fun loop() {
        var tick = 0
        while (running) {
            try {
                val p = getSharedPreferences("gacnoba_native", MODE_PRIVATE)
                val site = p.getString("site", "") ?: ""
                val token = p.getString("token", "") ?: ""
                val key = p.getString("server_key", "") ?: ""
                if (site.isEmpty() || token.isEmpty()) {
                    stopSelf()
                    return
                }
                val online = p.getString("set_online", "1") ?: "1"
                // while the app is on screen it does this itself
                if (!AppState.foreground) {
                    checkCalls(site, token, key, online)
                    if (tick % 3 == 0) checkAlerts(p, site, token, key)
                }
            } catch (_: Throwable) {
            }
            tick++
            try {
                Thread.sleep(5000)
            } catch (_: InterruptedException) {
                return
            }
        }
    }

    private fun post(site: String, endpoint: String, token: String, key: String, f: Map<String, String>): JSONObject? {
        var c: HttpURLConnection? = null
        try {
            val url = URL("$site/api/$endpoint?access_token=" + URLEncoder.encode(token, "UTF-8"))
            c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.doOutput = true
            val all = HashMap<String, String>()
            all["server_key"] = key
            all.putAll(f)
            val body = all.entries.joinToString("&") {
                URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
            }
            c.outputStream.use { it.write(body.toByteArray()) }
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(txt)
        } catch (_: Throwable) {
            return null
        } finally {
            try {
                c?.disconnect()
            } catch (_: Throwable) {
            }
        }
    }

    private fun checkCalls(site: String, token: String, key: String, online: String) {
        val res = post(
            site, "get_chats", token, key,
            mapOf("data_type" to "users", "user_limit" to "1", "SetOnline" to online)
        ) ?: return
        for (kind in listOf("video", "audio")) {
            if (!res.optBoolean("${kind}_call", false)) continue
            val d = res.optJSONObject("${kind}_call_user") ?: continue
            val id = d.optJSONObject("data")?.optString("id", "") ?: ""
            if (id.isEmpty() || lastCall[kind] == id) continue
            lastCall[kind] = id
            val name = d.optString("name", "").ifEmpty { "GACNOBA" }
            CallRing.show(this, name, if (kind == "video") "შემომავალი ვიდეო ზარი" else "შემომავალი ზარი")
            return
        }
    }

    private fun clean(s: String): String =
        s.replace(Regex("<[^>]*>"), "").replace("&amp;", "&").replace("&quot;", "\"").trim()

    private fun checkAlerts(p: android.content.SharedPreferences, site: String, token: String, key: String) {
        val res = post(site, "get-general-data", token, key, mapOf("fetch" to "notifications")) ?: return
        val arr = res.optJSONArray("notifications") ?: return
        var maxId = 0L
        val last = p.getLong("last_alert", -1L)
        val fresh = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) {
            val n = arr.optJSONObject(i) ?: continue
            val id = n.optString("id", "0").toLongOrNull() ?: 0L
            if (id > maxId) maxId = id
            if (last >= 0 && id > last && n.optString("seen", "0") == "0") fresh.add(n)
        }
        if (last < 0 || maxId > last) p.edit().putLong("last_alert", maxId).apply()
        if (last < 0) return // first run: do not show old notifications
        val show = if (fresh.size > 5) fresh.subList(fresh.size - 5, fresh.size) else fresh
        for (n in show) {
            val u = n.optJSONObject("notifier")
            var who = u?.optString("name", "") ?: ""
            if (who.isEmpty()) who = ((u?.optString("first_name", "") ?: "") + " " + (u?.optString("last_name", "") ?: "")).trim()
            if (who.isEmpty()) who = u?.optString("username", "") ?: ""
            var text = clean(n.optString("type_text", ""))
            if (text.isEmpty()) text = clean(n.optString("text", ""))
            if (text.isEmpty()) text = n.optString("type", "").replace('_', ' ')
            val id = (n.optString("id", "0").toLongOrNull() ?: 0L).toInt()
            alert(this, id, who.ifEmpty { "GACNOBA.ONLINE" }, text)
        }
    }

    companion object {
        const val CH = "gacnoba_bg"
        const val ID = 7773
        const val ALERT_CH = "gacnoba_alerts"

        fun alert(ctx: Context, id: Int, title: String, body: String) {
            val nm = ctx.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(ALERT_CH, "Notifications", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            var icon = ctx.resources.getIdentifier("ic_stat_onesignal_default", "drawable", ctx.packageName)
            if (icon == 0) icon = android.R.drawable.ic_dialog_info
            @Suppress("DEPRECATION")
            val b: Notification.Builder =
                if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, ALERT_CH) else Notification.Builder(ctx)
            b.setSmallIcon(icon).setContentTitle(title).setContentText(body)
                .setAutoCancel(true).setOnlyAlertOnce(true)
            if (launch != null) b.setContentIntent(PendingIntent.getActivity(ctx, id, launch, flags))
            nm.notify(10000 + (id % 50000), b.build())
        }
    }
}
