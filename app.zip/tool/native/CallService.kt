package __PKG__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Keeps a running call alive (microphone / camera) while the app is minimized. */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra("name") ?: ""
        val video = intent?.getBooleanExtra("video", false) == true
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Ongoing call", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        var icon = resources.getIdentifier("ic_stat_onesignal_default", "drawable", packageName)
        if (icon == 0) icon = android.R.drawable.sym_call_incoming
        val b: Notification.Builder =
            if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH)
            else Notification.Builder(this)
        b.setSmallIcon(icon)
            .setContentTitle(name)
            .setContentText(if (video) "Video call" else "Call")
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_CALL)
            .setUsesChronometer(true)
            .setWhen(System.currentTimeMillis())
        if (launch != null) {
            b.setContentIntent(PendingIntent.getActivity(this, ID, launch, piFlags))
        }
        val n = b.build()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (video) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                startForeground(ID, n, t)
            } else {
                startForeground(ID, n)
            }
        } catch (_: Throwable) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        try {
            stopForeground(true)
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    companion object {
        const val CH = "gacnoba_ongoing_call"
        const val ID = 7772
    }
}
