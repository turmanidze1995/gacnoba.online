package __PKG__

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Red handset button of the incoming call notification: declines the call without opening the app. */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != ACTION_DECLINE) return
        CallRing.cancel(ctx)
        val callId = intent.getStringExtra("call_id") ?: ""
        val kind = intent.getStringExtra("kind") ?: "video"
        if (callId.isEmpty()) return
        val p = ctx.getSharedPreferences("gacnoba_native", Context.MODE_PRIVATE)
        val site = p.getString("site", "") ?: ""
        val token = p.getString("token", "") ?: ""
        val key = p.getString("server_key", "") ?: ""
        if (site.isEmpty() || token.isEmpty()) return
        val pending = goAsync()
        Thread {
            var c: HttpURLConnection? = null
            try {
                val url = URL("$site/api/twilio?access_token=" + URLEncoder.encode(token, "UTF-8"))
                c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.doOutput = true
                val f = linkedMapOf(
                    "server_key" to key, "type" to "action", "call_id" to callId,
                    "call_type" to kind, "action" to "decline"
                )
                val body = f.entries.joinToString("&") {
                    URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                }
                c.outputStream.use { it.write(body.toByteArray()) }
                c.inputStream.bufferedReader().use { it.readText() }
            } catch (_: Throwable) {
            } finally {
                try {
                    c?.disconnect()
                } catch (_: Throwable) {
                }
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_DECLINE = "__PKG__.CALL_DECLINE"
    }
}
