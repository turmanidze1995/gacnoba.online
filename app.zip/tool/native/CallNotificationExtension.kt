package __PKG__

import com.onesignal.notifications.INotificationReceivedEvent
import com.onesignal.notifications.INotificationServiceExtension

/** Runs for every OneSignal push, also when the app is closed. Call pushes ring like a phone call. */
class CallNotificationExtension : INotificationServiceExtension {
    override fun onNotificationReceived(event: INotificationReceivedEvent) {
        try {
            val n = event.notification
            val data = n.additionalData
            if (data != null && (data.has("call_id") || data.has("room_name"))) {
                event.preventDefault()
                CallRing.show(event.context, n.title ?: "", n.body ?: "")
            }
        } catch (_: Throwable) {
        }
    }
}
