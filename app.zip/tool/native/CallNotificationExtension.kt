package __PKG__

import com.onesignal.notifications.INotificationReceivedEvent
import com.onesignal.notifications.INotificationServiceExtension

/**
 * Runs for every OneSignal push, also when the app is closed.
 * Call pushes ring like a phone call, message pushes also show the floating bubble.
 */
class CallNotificationExtension : INotificationServiceExtension {
    override fun onNotificationReceived(event: INotificationReceivedEvent) {
        try {
            val n = event.notification
            val data = n.additionalData
            if (data != null && (data.has("call_id") || data.has("room_name"))) {
                event.preventDefault()
                val kind = (data.optString("call_type", data.optString("type", "video"))).let {
                    if (it.contains("audio")) "audio" else "video"
                }
                CallRing.show(event.context, n.title ?: "", n.body ?: "", data.optString("call_id", ""), kind)
            } else if (data != null) {
                val uid = data.optString("user_id", "")
                val type = data.optString("type", "user")
                if (uid.isNotEmpty() && (type.isEmpty() || type == "user")) {
                    FloatingBubble.show(event.context, uid, n.title ?: "", n.largeIcon)
                }
            }
        } catch (_: Throwable) {
        }
    }
}
