#!/usr/bin/env bash
set -e
flutter create --platforms=android --org com.gacnoba --project-name gacnoba_messenger .
python3 tool/patch_android.py
flutter pub get
python3 tool/patch_plugins.py

# Force compileSdk 36 for every Gradle module (global init script)
mkdir -p "$HOME/.gradle/init.d"
cp tool/force_compile_sdk.gradle "$HOME/.gradle/init.d/force_compile_sdk.gradle"

# diagnostics for the log
PC="${PUB_CACHE:-$HOME/.pub-cache}"
echo "--- agora gradle compileSdk lines ---"
grep -rn "compileSdk" "$PC"/hosted/*/agora_rtc_engine-*/android/build.gradle* || true

flutter build apk --release
