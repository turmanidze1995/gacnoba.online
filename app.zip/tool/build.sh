#!/usr/bin/env bash
set -e
flutter create --platforms=android --org com.gacnoba --project-name gacnoba_messenger .
python3 tool/patch_android.py
flutter pub get
python3 tool/patch_plugins.py
flutter build apk --release
