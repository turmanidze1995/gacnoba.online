#!/usr/bin/env bash
set -e

# Optional settings file in the repository root (app-settings.txt), for example:
#   ONESIGNAL_APP_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
#   GOOGLE_WEB_CLIENT_ID=123456789-abc.apps.googleusercontent.com
if [ -f app-settings.txt ]; then
  while IFS='=' read -r key value || [ -n "$key" ]; do
    value="$(echo "$value" | tr -d '\r' | xargs)"
    key="$(echo "$key" | tr -d '\r' | xargs)"
    case "$key" in
      ONESIGNAL_APP_ID)
        [ -n "$value" ] && sed -i "s|PASTE_ONESIGNAL_APP_ID_HERE|$value|" lib/config.dart && echo "OneSignal App ID applied" ;;
      GOOGLE_WEB_CLIENT_ID)
        [ -n "$value" ] && sed -i "s|PASTE_GOOGLE_WEB_CLIENT_ID_HERE|$value|" lib/config.dart && echo "Google Web Client ID applied" ;;
    esac
  done < app-settings.txt
fi

flutter create --platforms=android --org com.gacnoba --project-name gacnoba_messenger .
python3 tool/patch_android.py
flutter pub get
python3 tool/patch_plugins.py

# Force compileSdk 36 for every Gradle module (global init script)
mkdir -p "$HOME/.gradle/init.d"
cp tool/force_compile_sdk.gradle "$HOME/.gradle/init.d/force_compile_sdk.gradle"

flutter build apk --release
